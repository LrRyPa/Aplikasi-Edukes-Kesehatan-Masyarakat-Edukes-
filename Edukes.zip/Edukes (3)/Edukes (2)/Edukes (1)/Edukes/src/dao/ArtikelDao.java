package dao;

import jakarta.persistence.EntityManager;
import jakarta.persistence.NoResultException;
import jakarta.persistence.TypedQuery;
import jakarta.persistence.EntityTransaction;
import java.util.List;

import model.Artikel;
import util.JpaUtil;

public class ArtikelDao extends BaseDao<Artikel, Integer> {

    public ArtikelDao() {
        super(Artikel.class);
    }

    public Artikel findById(Integer id) {
        return super.find(id);
    }
    
    public List<Artikel> findPublished() {
        var em = JpaUtil.getEmf().createEntityManager();
        try {
            return em.createQuery(
                "SELECT a FROM Artikel a " +
                "LEFT JOIN FETCH a.admin " +
                "LEFT JOIN FETCH a.penyakit " +
                "WHERE a.statusReview = 'PUBLISHED' " +
                "ORDER BY a.id", Artikel.class
            ).getResultList();
        } finally { em.close(); }
    }
    
    public Artikel findByExactJudul(String judul) {
        EntityManager em = JpaUtil.getEmf().createEntityManager();
        try {
            TypedQuery<Artikel> q = em.createQuery(
                "SELECT a FROM Artikel a WHERE a.judul = :j", Artikel.class);
            q.setParameter("j", judul);
            return q.getSingleResult();
        } catch (NoResultException e) {
            return null;
        } finally { em.close(); }
    }

    public boolean existsByJudul(String judul) {
        EntityManager em = JpaUtil.getEmf().createEntityManager();
        try {
            Long cnt = em.createQuery(
                "SELECT COUNT(a) FROM Artikel a WHERE a.judul = :j", Long.class)
                .setParameter("j", judul)
                .getSingleResult();
            return cnt != null && cnt > 0;
        } finally { em.close(); }
    }

    public List<Artikel> findByJudulContains(String keyword) {
        EntityManager em = JpaUtil.getEmf().createEntityManager();
        try {
            return em.createQuery(
                "SELECT a FROM Artikel a " +
                "WHERE LOWER(a.judul) LIKE :kw " +
                "ORDER BY a.tanggalUpload DESC", Artikel.class)
                .setParameter("kw", "%" + (keyword == null ? "" : keyword.toLowerCase()) + "%")
                .getResultList();
        } finally { em.close(); }
    }

    public List<Artikel> findByAdmin(Integer idAdmin) {
        EntityManager em = JpaUtil.getEmf().createEntityManager();
        try {
            return em.createQuery(
                "SELECT a FROM Artikel a WHERE a.admin.id = :id " +
                "ORDER BY a.tanggalUpload DESC", Artikel.class)
                .setParameter("id", idAdmin)
                .getResultList();
        } finally { em.close(); }
    }

    public List<Artikel> findByPenyakit(Integer idPenyakit) {
        EntityManager em = JpaUtil.getEmf().createEntityManager();
        try {
            return em.createQuery(
                "SELECT a FROM Artikel a WHERE a.penyakit.id = :id " +
                "ORDER BY a.tanggalUpload DESC", Artikel.class)
                .setParameter("id", idPenyakit)
                .getResultList();
        } finally { em.close(); }
    }

    public List<Artikel> findByStatus(String status) {
        EntityManager em = JpaUtil.getEmf().createEntityManager();
        try {
            return em.createQuery(
                "SELECT a FROM Artikel a WHERE a.statusReview = :st " +
                "ORDER BY a.tanggalUpload DESC", Artikel.class)
                .setParameter("st", status)
                .getResultList();
        } finally { em.close(); }
    }

    public List<Artikel> latest(int max) {
        EntityManager em = JpaUtil.getEmf().createEntityManager();
        try {
            return em.createQuery(
                "SELECT a FROM Artikel a ORDER BY a.tanggalUpload DESC", Artikel.class)
                .setMaxResults(Math.max(0, max))
                .getResultList();
        } finally { em.close(); }
    }

    public List<Artikel> page(int offset, int limit) {
        EntityManager em = JpaUtil.getEmf().createEntityManager();
        try {
            return em.createQuery(
                "SELECT a FROM Artikel a ORDER BY a.tanggalUpload DESC", Artikel.class)
                .setFirstResult(Math.max(0, offset))
                .setMaxResults(Math.max(0, limit))
                .getResultList();
        } finally { em.close(); }
    }

    public long countAll() {
        EntityManager em = JpaUtil.getEmf().createEntityManager();
        try {
            Long cnt = em.createQuery("SELECT COUNT(a) FROM Artikel a", Long.class)
                         .getSingleResult();
            return cnt == null ? 0L : cnt;
        } finally { em.close(); }
    }

    public long countByAdminAndStatus(Integer idAdmin, String status) {
        EntityManager em = JpaUtil.getEmf().createEntityManager();
        try {
            Long cnt = em.createQuery(
                "SELECT COUNT(a) FROM Artikel a " +
                "WHERE a.admin.id = :id AND a.statusReview = :st", Long.class)
                .setParameter("id", idAdmin)
                .setParameter("st", status)
                .getSingleResult();
            return cnt == null ? 0L : cnt;
        } finally { em.close(); }
    }

    public boolean updateStatus(Integer idArtikel, String statusBaru) {
        EntityManager em = JpaUtil.getEmf().createEntityManager();
        var tx = em.getTransaction();
        try {
            tx.begin();
            Artikel a = em.find(Artikel.class, idArtikel);
            if (a == null) { tx.rollback(); return false; }
            a.setStatusReview(statusBaru);
            em.merge(a);
            tx.commit();
            return true;
        } catch (RuntimeException ex) {
            if (tx.isActive()) tx.rollback();
            throw ex;
        } finally { em.close(); }
    }

    public boolean updateContent(Integer idArtikel, String judulBaru, String kontenBaru) {
        EntityManager em = JpaUtil.getEmf().createEntityManager();
        var tx = em.getTransaction();
        try {
            tx.begin();
            Artikel a = em.find(Artikel.class, idArtikel);
            if (a == null) { tx.rollback(); return false; }
            if (judulBaru != null && !judulBaru.isBlank()) a.setJudul(judulBaru);
            if (kontenBaru != null && !kontenBaru.isBlank()) a.setKonten(kontenBaru);
            em.merge(a);
            tx.commit();
            return true;
        } catch (RuntimeException ex) {
            if (tx.isActive()) tx.rollback();
            throw ex;
        } finally { em.close(); }
    }
    
    public Artikel save(Artikel a) {
        EntityManager em = JpaUtil.getEmf().createEntityManager();
        EntityTransaction tx = em.getTransaction();
        try {
            tx.begin();

            Artikel result;
            if (a.getId() == null) {
                em.persist(a);       
                em.flush();          
                em.refresh(a);       
                result = a;         
            } else {
                Artikel m = em.merge(a); 
                em.flush();
                em.refresh(m);           
                result = m;
            }

            tx.commit();
            return result;

        } catch (RuntimeException ex) {
            if (tx.isActive()) tx.rollback();
            throw ex;
        } finally {
            em.close();
        }
    }
    
    public void deleteForceMySql(Integer id) {
        EntityManager em = JpaUtil.getEmf().createEntityManager();
        EntityTransaction tx = em.getTransaction();
        try {
            tx.begin();
            em.createNativeQuery("SET FOREIGN_KEY_CHECKS=0").executeUpdate();
            em.createNativeQuery("DELETE FROM artikel WHERE id_artikel = :id")
              .setParameter("id", id)
              .executeUpdate();
            em.createNativeQuery("SET FOREIGN_KEY_CHECKS=1").executeUpdate();
            tx.commit();
        } catch (RuntimeException ex) {
            if (tx.isActive()) tx.rollback();
            throw ex;
        } finally {
            em.close();
        }
    }
}

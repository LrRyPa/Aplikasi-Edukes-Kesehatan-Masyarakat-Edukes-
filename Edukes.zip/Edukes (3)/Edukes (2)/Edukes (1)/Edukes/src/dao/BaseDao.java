package dao;

import jakarta.persistence.EntityManager;
import jakarta.persistence.criteria.CriteriaQuery;
import java.util.List;
import util.JpaUtil;

public abstract class BaseDao<T, ID> implements InterfaceDao<T, ID> {
    protected final Class<T> entityClass;

    public BaseDao(Class<T> entityClass) {
        this.entityClass = entityClass;
    }

    protected EntityManager em() {
        return JpaUtil.getEmf().createEntityManager();
    }

    @Override
    public T save(T entity) {
        var em = em();
        var tx = em.getTransaction();
        try {
            tx.begin();
            T merged = em.merge(entity);
            tx.commit();
            return merged;
        } catch (RuntimeException ex) {
            if (tx.isActive()) tx.rollback();
            throw ex;
        } finally { em.close(); }
    }

    @Override
    public T find(ID id) {
        var em = em();
        try { return em.find(entityClass, id); }
        finally { em.close(); }
    }

    @Override
    public List<T> findAll() {
        var em = em();
        try {
            var cb = em.getCriteriaBuilder();
            CriteriaQuery<T> cq = cb.createQuery(entityClass);
            cq.select(cq.from(entityClass));
            return em.createQuery(cq).getResultList();
        } finally { em.close(); }
    }
    
    @Override 
    public void delete(ID id) { 
        deleteById(id); 
    }

    public void deleteById(ID id) {
        var em = em();
        var tx = em.getTransaction();
        try {
            tx.begin();
            T ref = em.find(entityClass, id);
            if (ref != null) em.remove(ref);
            tx.commit();
        } catch (RuntimeException ex) {
            if (tx.isActive()) tx.rollback();
            throw ex;
        } finally { em.close(); }
    }
}

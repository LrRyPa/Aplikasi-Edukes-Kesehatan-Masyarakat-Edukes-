package dao;

import jakarta.persistence.EntityManager;
import jakarta.persistence.NoResultException;
import jakarta.persistence.TypedQuery;
import java.time.LocalDateTime;
import java.util.List;

import model.Akun;
import model.User;
import util.JpaUtil;


public class UserDao extends BaseDao<User, Integer> {

    public UserDao() {
        super(User.class);
    }

    public User findById(Integer idUser) {
        return super.find(idUser);
    }

    public User findByEmail(String email) {
        EntityManager em = JpaUtil.getEmf().createEntityManager();
        try {
            TypedQuery<User> q = em.createQuery(
                "SELECT u FROM User u WHERE u.email = :email", User.class);
            q.setParameter("email", email);
            return q.getSingleResult();
        } catch (NoResultException e) {
            return null;
        } finally {
            em.close();
        }
    }

    public boolean existsEmailOnAkun(String email) {
        EntityManager em = JpaUtil.getEmf().createEntityManager();
        try {
            Long cnt = em.createQuery(
                "SELECT COUNT(a) FROM Akun a WHERE a.email = :email", Long.class)
                .setParameter("email", email)
                .getSingleResult();
            return cnt != null && cnt > 0;
        } finally {
            em.close();
        }
    }
    
    public boolean existsEmailOnAkunExceptId(String email, Integer excludeId) {
        var em = JpaUtil.getEmf().createEntityManager();
        try {
            Long cnt = em.createQuery(
                "select count(a) from Akun a " +
                "where lower(a.email) = :email and a.id <> :id", Long.class)
                .setParameter("email", email.toLowerCase())
                .setParameter("id", excludeId)
                .getSingleResult();
            return cnt != null && cnt > 0;
        } finally {
            em.close();
        }
    }
    public List<User> searchByNama(String keyword) {
        EntityManager em = JpaUtil.getEmf().createEntityManager();
        try {
            return em.createQuery(
                "SELECT u FROM User u WHERE LOWER(u.nama) LIKE :kw ORDER BY u.nama", User.class)
                .setParameter("kw", "%" + (keyword == null ? "" : keyword.toLowerCase()) + "%")
                .getResultList();
        } finally {
            em.close();
        }
    }

    public List<User> findByTanggalRegistrasiBetween(LocalDateTime start, LocalDateTime end) {
        EntityManager em = JpaUtil.getEmf().createEntityManager();
        try {
            return em.createQuery(
                "SELECT u FROM User u WHERE u.tanggalRegistrasi BETWEEN :s AND :e ORDER BY u.tanggalRegistrasi",
                User.class)
                .setParameter("s", start)
                .setParameter("e", end)
                .getResultList();
        } finally {
            em.close();
        }
    }

    public List<User> latestRegistered(int max) {
        EntityManager em = JpaUtil.getEmf().createEntityManager();
        try {
            return em.createQuery(
                "SELECT u FROM User u ORDER BY u.tanggalRegistrasi DESC", User.class)
                .setMaxResults(Math.max(0, max))
                .getResultList();
        } finally {
            em.close();
        }
    }

    public boolean updatePassword(Integer idUser, String passwordBaru) {
        EntityManager em = JpaUtil.getEmf().createEntityManager();
        var tx = em.getTransaction();
        try {
            tx.begin();
            // karena User extends Akun, find di Akun juga valid
            Akun akun = em.find(Akun.class, idUser);
            if (akun == null) { tx.rollback(); return false; }
            akun.setPassword(passwordBaru);
            em.merge(akun);
            tx.commit();
            return true;
        } catch (RuntimeException ex) {
            if (tx.isActive()) tx.rollback();
            throw ex;
        } finally {
            em.close();
        }
    }
}

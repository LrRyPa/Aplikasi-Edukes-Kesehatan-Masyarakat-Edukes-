package dao;

import jakarta.persistence.EntityManager;
import jakarta.persistence.NoResultException;
import jakarta.persistence.TypedQuery;
import java.util.List;
import model.Akun;
import util.JpaUtil;

public class AkunDao extends BaseDao<Akun, Integer> {

    public AkunDao() {
        super(Akun.class);
    }

    @Override
    public Akun save(Akun entity) {
        if (existsByEmail(entity.getEmail())) {
            throw new IllegalArgumentException("Email sudah terdaftar");
        }
        return super.save(entity);
    }
    
    public Akun findByEmail(String email) {
        EntityManager em = JpaUtil.getEmf().createEntityManager();
        try {
            TypedQuery<Akun> q = em.createQuery(
                "SELECT a FROM Akun a WHERE a.email = :email", Akun.class);
            q.setParameter("email", email);
            return q.getSingleResult();
        } catch (NoResultException e) {
            return null;
        } finally {
            em.close();
        }
    }

    public Akun findByIdNative(Integer id) {
    var em = util.JpaUtil.getEmf().createEntityManager();
    try {
        return (Akun) em.createNativeQuery(
            "SELECT id_akun, email, nama, password FROM akun WHERE id_akun = ?",
            model.Akun.class
        ).setParameter(1, id)
         .getSingleResult();
    } catch (jakarta.persistence.NoResultException ex) {
        return null;
    } finally { em.close(); }
}

    
    public boolean existsByEmail(String email) {
        EntityManager em = JpaUtil.getEmf().createEntityManager();
        try {
            Long cnt = em.createQuery(
                "SELECT COUNT(a) FROM Akun a WHERE a.email = :email", Long.class)
                .setParameter("email", email)
                .getSingleResult();
            return cnt != null && cnt > 0;
        } finally {
            em.close();
        }
    }

    public Akun authenticate(String email, String password) {
        var em = util.JpaUtil.getEmf().createEntityManager();
        try {
            Object idObj = em.createNativeQuery(
                "SELECT id_akun FROM akun WHERE email=? AND password=? LIMIT 1")
                .setParameter(1, email)
                .setParameter(2, password)
                .getSingleResult();
            Integer id = ((Number) idObj).intValue();
            return em.find(model.Akun.class, id);   
        } catch (jakarta.persistence.NoResultException ex) {
            return null;
        } finally { em.close(); }
    }

    public List<Akun> searchByNama(String keyword) {
        EntityManager em = JpaUtil.getEmf().createEntityManager();
        try {
            return em.createQuery(
                "SELECT a FROM Akun a WHERE LOWER(a.nama) LIKE :kw ORDER BY a.nama", Akun.class)
                .setParameter("kw", "%" + (keyword == null ? "" : keyword.toLowerCase()) + "%")
                .getResultList();
        } finally {
            em.close();
        }
    }

    public boolean updatePassword(Integer idAkun, String passwordBaru) {
        EntityManager em = JpaUtil.getEmf().createEntityManager();
        var tx = em.getTransaction();
        try {
            tx.begin();
            Akun a = em.find(Akun.class, idAkun);
            if (a == null) { tx.rollback(); return false; }
            a.setPassword(passwordBaru);
            em.merge(a);
            tx.commit();
            return true;
        } catch (RuntimeException ex) {
            if (tx.isActive()) tx.rollback();
            throw ex;
        } finally {
            em.close();
        }
    }
}

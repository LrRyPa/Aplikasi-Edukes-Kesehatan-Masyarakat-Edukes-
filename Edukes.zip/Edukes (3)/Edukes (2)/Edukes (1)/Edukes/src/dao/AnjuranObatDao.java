package dao;

import jakarta.persistence.EntityManager;
import java.util.List;

import model.AnjuranObat;
import util.JpaUtil;


public class AnjuranObatDao extends BaseDao<AnjuranObat, Integer> {

    public AnjuranObatDao() {
        super(AnjuranObat.class);
    }

    public AnjuranObat findById(Integer id) {
        return super.find(id);
    }
    
    public AnjuranObat findByIdWithJoins(Integer id) {
        EntityManager em = JpaUtil.getEmf().createEntityManager();
        try {
            List<AnjuranObat> list = em.createQuery(
                "SELECT a FROM AnjuranObat a " +
                "LEFT JOIN FETCH a.penyakit " +
                "LEFT JOIN FETCH a.obat " +
                "WHERE a.id = :id", AnjuranObat.class)
                .setParameter("id", id)
                .getResultList();
            return list.isEmpty() ? null : list.get(0);
        } finally { em.close(); }
    }


    public List<AnjuranObat> findByPenyakit(Integer idPenyakit) {
        EntityManager em = JpaUtil.getEmf().createEntityManager();
        try {
            return em.createQuery(
                "SELECT a FROM AnjuranObat a " +
                "LEFT JOIN FETCH a.penyakit " +
                "LEFT JOIN FETCH a.obat " +
                "WHERE a.penyakit.id = :pid " +
                "ORDER BY a.id ASC", AnjuranObat.class)
                .setParameter("pid", idPenyakit)
                .getResultList();
        } finally { em.close(); }
    }

    public List<AnjuranObat> findByObat(Integer idObat) {
        EntityManager em = JpaUtil.getEmf().createEntityManager();
        try {
            return em.createQuery(
                "SELECT a FROM AnjuranObat a " +
                "LEFT JOIN FETCH a.penyakit " +
                "LEFT JOIN FETCH a.obat " +
                "WHERE a.obat.id = :oid " +
                "ORDER BY a.id ASC", AnjuranObat.class)
                .setParameter("oid", idObat)
                .getResultList();
        } finally { em.close(); }
    }

    public AnjuranObat findByPenyakitAndObat(Integer idPenyakit, Integer idObat) {
        EntityManager em = JpaUtil.getEmf().createEntityManager();
        try {
            List<AnjuranObat> list = em.createQuery(
                "SELECT a FROM AnjuranObat a " +
                "LEFT JOIN FETCH a.penyakit " +
                "LEFT JOIN FETCH a.obat " +
                "WHERE a.penyakit.id = :pid AND a.obat.id = :oid",
                AnjuranObat.class)
                .setParameter("pid", idPenyakit)
                .setParameter("oid", idObat)
                .getResultList();
            return list.isEmpty() ? null : list.get(0);
        } finally { em.close(); }
    }

    public boolean existsByPenyakitAndObat(Integer idPenyakit, Integer idObat) {
        EntityManager em = JpaUtil.getEmf().createEntityManager();
        try {
            Long cnt = em.createQuery(
                "SELECT COUNT(a) FROM AnjuranObat a " +
                "WHERE a.penyakit.id = :pid AND a.obat.id = :oid", Long.class)
                .setParameter("pid", idPenyakit)
                .setParameter("oid", idObat)
                .getSingleResult();
            return cnt != null && cnt > 0;
        } finally { em.close(); }
    }

    public List<AnjuranObat> searchInDosisOrAturan(String keyword) {
        String kw = "%" + (keyword == null ? "" : keyword.toLowerCase()) + "%";
        EntityManager em = JpaUtil.getEmf().createEntityManager();
        try {
            return em.createQuery(
                "SELECT a FROM AnjuranObat a " +
                "LEFT JOIN FETCH a.penyakit " +
                "LEFT JOIN FETCH a.obat " +
                "WHERE LOWER(COALESCE(a.dosisAnjuran,'')) LIKE :kw " +
                "   OR LOWER(COALESCE(a.aturanPakai,'')) LIKE :kw " +
                "ORDER BY a.id ASC", AnjuranObat.class)
                .setParameter("kw", kw)
                .getResultList();
        } finally { em.close(); }
    }

    public boolean updateDosisDanAturan(Integer idAnjuran, String dosisBaru, String aturanBaru) {
        EntityManager em = JpaUtil.getEmf().createEntityManager();
        var tx = em.getTransaction();
        try {
            tx.begin();
            AnjuranObat a = em.find(AnjuranObat.class, idAnjuran);
            if (a == null) { tx.rollback(); return false; }
            if (dosisBaru != null && !dosisBaru.isBlank()) a.setDosisAnjuran(dosisBaru);
            if (aturanBaru != null && !aturanBaru.isBlank()) a.setAturanPakai(aturanBaru);
            tx.commit();
            return true;
        } catch (RuntimeException ex) {
            if (tx.isActive()) tx.rollback();
            throw ex;
        } finally { em.close(); }
    }

    public int deleteByPenyakit(Integer idPenyakit) {
        EntityManager em = JpaUtil.getEmf().createEntityManager();
        var tx = em.getTransaction();
        try {
            tx.begin();
            int rows = em.createQuery(
                "DELETE FROM AnjuranObat a WHERE a.penyakit.id = :pid")
                .setParameter("pid", idPenyakit)
                .executeUpdate();
            tx.commit();
            return rows;
        } catch (RuntimeException ex) {
            if (tx.isActive()) tx.rollback();
            throw ex;
        } finally { em.close(); }
    }

    public int deleteByObat(Integer idObat) {
        EntityManager em = JpaUtil.getEmf().createEntityManager();
        var tx = em.getTransaction();
        try {
            tx.begin();
            int rows = em.createQuery(
                "DELETE FROM AnjuranObat a WHERE a.obat.id = :oid")
                .setParameter("oid", idObat)
                .executeUpdate();
            tx.commit();
            return rows;
        } catch (RuntimeException ex) {
            if (tx.isActive()) tx.rollback();
            throw ex;
        } finally { em.close(); }
    }

    public List<AnjuranObat> page(int offset, int limit) {
        EntityManager em = JpaUtil.getEmf().createEntityManager();
        try {
            return em.createQuery(
                "SELECT a FROM AnjuranObat a " +
                "LEFT JOIN FETCH a.penyakit " +
                "LEFT JOIN FETCH a.obat " +
                "ORDER BY a.id ASC", AnjuranObat.class)
                .setFirstResult(Math.max(0, offset))
                .setMaxResults(Math.max(0, limit))
                .getResultList();
        } finally { em.close(); }
    }

     public long countAll() {
        EntityManager em = JpaUtil.getEmf().createEntityManager();
        try {
            Long cnt = em.createQuery(
                "SELECT COUNT(a) FROM AnjuranObat a", Long.class).getSingleResult();
            return cnt == null ? 0L : cnt;
        } finally { em.close(); }
    }
    
    public List<AnjuranObat> findAll() {
        EntityManager em = JpaUtil.getEmf().createEntityManager();
        try {
            return em.createQuery(
                "SELECT a FROM AnjuranObat a ORDER BY a.id ASC", AnjuranObat.class
            ).getResultList();
        } finally { em.close(); }
    }
}

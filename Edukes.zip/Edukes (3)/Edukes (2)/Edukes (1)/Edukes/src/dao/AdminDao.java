package dao;

import jakarta.persistence.EntityManager;
import jakarta.persistence.NoResultException;
import jakarta.persistence.TypedQuery;
import java.util.List;

import model.Admin;
import model.Akun;
import model.Artikel;
import util.JpaUtil;

public class AdminDao extends BaseDao<Admin, Integer> {

    public AdminDao() {
        super(Admin.class);
    }

    public Admin findById(Integer idAdmin) {
        return super.find(idAdmin);
    }

    public Admin findByEmail(String email) {
        EntityManager em = JpaUtil.getEmf().createEntityManager();
        try {
            TypedQuery<Admin> q = em.createQuery(
                "SELECT a FROM Admin a WHERE a.email = :email", Admin.class);
            q.setParameter("email", email);
            return q.getSingleResult();
        } catch (NoResultException e) {
            return null;
        } finally {
            em.close();
        }
    }

    public boolean existsEmailOnAkun(String email) {
        EntityManager em = JpaUtil.getEmf().createEntityManager();
        try {
            Long cnt = em.createQuery(
                "SELECT COUNT(x) FROM Akun x WHERE x.email = :email", Long.class)
                .setParameter("email", email)
                .getSingleResult();
            return cnt != null && cnt > 0;
        } finally {
            em.close();
        }
    }

    public Admin authenticate(String email, String password) {
        EntityManager em = JpaUtil.getEmf().createEntityManager();
        try {
            TypedQuery<Admin> q = em.createQuery(
                "SELECT a FROM Admin a WHERE a.email = :email AND a.password = :pw", Admin.class);
            q.setParameter("email", email);
            q.setParameter("pw", password);
            return q.getSingleResult();
        } catch (NoResultException e) {
            return null;
        } finally {
            em.close();
        }
    }

    public List<Admin> searchByNama(String keyword) {
        EntityManager em = JpaUtil.getEmf().createEntityManager();
        try {
            return em.createQuery(
                "SELECT a FROM Admin a WHERE LOWER(a.nama) LIKE :kw ORDER BY a.nama", Admin.class)
                .setParameter("kw", "%" + (keyword == null ? "" : keyword.toLowerCase()) + "%")
                .getResultList();
        } finally {
            em.close();
        }
    }

    public boolean updateKontak(Integer idAdmin, String kontakBaru) {
        EntityManager em = JpaUtil.getEmf().createEntityManager();
        var tx = em.getTransaction();
        try {
            tx.begin();
            Admin a = em.find(Admin.class, idAdmin);
            if (a == null) { tx.rollback(); return false; }
            a.setKontak(kontakBaru);
            em.merge(a);
            tx.commit();
            return true;
        } catch (RuntimeException ex) {
            if (tx.isActive()) tx.rollback();
            throw ex;
        } finally {
            em.close();
        }
    }

    public List<Artikel> listArtikelByAdmin(Integer idAdmin) {
        EntityManager em = JpaUtil.getEmf().createEntityManager();
        try {
            return em.createQuery(
                "SELECT ar FROM Artikel ar WHERE ar.admin.id = :id ORDER BY ar.tanggalUpload DESC",
                Artikel.class)
                .setParameter("id", idAdmin)
                .getResultList();
        } finally {
            em.close();
        }
    }

    public long countArtikelByStatus(Integer idAdmin, String status) {
        EntityManager em = JpaUtil.getEmf().createEntityManager();
        try {
            Long cnt = em.createQuery(
                "SELECT COUNT(ar) FROM Artikel ar WHERE ar.admin.id = :id AND ar.statusReview = :st",
                Long.class)
                .setParameter("id", idAdmin)
                .setParameter("st", status)
                .getSingleResult();
            return cnt == null ? 0L : cnt;
        } finally {
            em.close();
        }
    }

    public List<Admin> findAdminsWithoutArtikel() {
        EntityManager em = JpaUtil.getEmf().createEntityManager();
        try {
            return em.createQuery(
                "SELECT a FROM Admin a LEFT JOIN Artikel ar ON ar.admin = a " +
                "WHERE ar.id IS NULL ORDER BY a.nama", Admin.class)
                .getResultList();
        } finally {
            em.close();
        }
    }
}

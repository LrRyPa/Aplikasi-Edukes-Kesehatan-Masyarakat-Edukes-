package dao;
import java.util.List;
public interface InterfaceDao<T,ID> {
  T find(ID id);
  List<T> findAll();
  T save(T entity);       
  void delete(ID id);
}
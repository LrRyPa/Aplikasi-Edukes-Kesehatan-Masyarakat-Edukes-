package dao;

import jakarta.persistence.EntityManager;
import jakarta.persistence.NoResultException;
import jakarta.persistence.TypedQuery;
import java.util.List;

import model.Kategori;
import model.Penyakit;
import util.JpaUtil;

public class KategoriDao extends BaseDao<Kategori, Integer> {

    public KategoriDao() {
        super(Kategori.class);
    }

    public Kategori findById(Integer id) {
        return super.find(id);
    }

    public Kategori findByNamaExact(String namaKategori) {
        EntityManager em = JpaUtil.getEmf().createEntityManager();
        try {
            TypedQuery<Kategori> q = em.createQuery(
                "SELECT k FROM Kategori k WHERE k.namaKategori = :n", Kategori.class);
            q.setParameter("n", namaKategori);
            return q.getSingleResult();
        } catch (NoResultException e) {
            return null;
        } finally { em.close(); }
    }

    public boolean existsByNama(String namaKategori) {
        EntityManager em = JpaUtil.getEmf().createEntityManager();
        try {
            Long cnt = em.createQuery(
                "SELECT COUNT(k) FROM Kategori k WHERE k.namaKategori = :n", Long.class)
                .setParameter("n", namaKategori)
                .getSingleResult();
            return cnt != null && cnt > 0;
        } finally { em.close(); }
    }

    public List<Kategori> findByNamaContains(String keyword) {
        EntityManager em = JpaUtil.getEmf().createEntityManager();
        try {
            return em.createQuery(
                "SELECT k FROM Kategori k " +
                "WHERE LOWER(k.namaKategori) LIKE :kw " +
                "ORDER BY k.namaKategori", Kategori.class)
                .setParameter("kw", "%" + (keyword == null ? "" : keyword.toLowerCase()) + "%")
                .getResultList();
        } finally { em.close(); }
    }

    public List<Penyakit> listPenyakit(Integer idKategori) {
        EntityManager em = JpaUtil.getEmf().createEntityManager();
        try {
            return em.createQuery(
                "SELECT p FROM Penyakit p WHERE p.kategori.id = :id ORDER BY p.namaPenyakit",
                Penyakit.class)
                .setParameter("id", idKategori)
                .getResultList();
        } finally { em.close(); }
    }

    public long countPenyakit(Integer idKategori) {
        EntityManager em = JpaUtil.getEmf().createEntityManager();
        try {
            Long cnt = em.createQuery(
                "SELECT COUNT(p) FROM Penyakit p WHERE p.kategori.id = :id", Long.class)
                .setParameter("id", idKategori)
                .getSingleResult();
            return cnt == null ? 0L : cnt;
        } finally { em.close(); }
    }

    public List<Kategori> latest(int max) {
        EntityManager em = JpaUtil.getEmf().createEntityManager();
        try {
            return em.createQuery(
                "SELECT k FROM Kategori k ORDER BY k.id DESC", Kategori.class)
                .setMaxResults(Math.max(0, max))
                .getResultList();
        } finally { em.close(); }
    }

    public List<Kategori> page(int offset, int limit) {
        EntityManager em = JpaUtil.getEmf().createEntityManager();
        try {
            return em.createQuery(
                "SELECT k FROM Kategori k ORDER BY k.namaKategori", Kategori.class)
                .setFirstResult(Math.max(0, offset))
                .setMaxResults(Math.max(0, limit))
                .getResultList();
        } finally { em.close(); }
    }

    public long countAll() {
        EntityManager em = JpaUtil.getEmf().createEntityManager();
        try {
            Long cnt = em.createQuery("SELECT COUNT(k) FROM Kategori k", Long.class)
                         .getSingleResult();
            return cnt == null ? 0L : cnt;
        } finally { em.close(); }
    }
}

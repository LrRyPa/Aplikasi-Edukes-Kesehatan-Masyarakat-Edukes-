package dao;

import com.sun.jdi.connect.spi.Connection;
import jakarta.persistence.EntityManager;
import jakarta.persistence.NoResultException;
import jakarta.persistence.TypedQuery;
import java.math.BigDecimal;
import java.util.List;

import model.Obat;
import model.AnjuranObat;
import util.JpaUtil;

public class ObatDao extends BaseDao<Obat, Integer> {

    public ObatDao() {
        super(Obat.class);
    }

    public Obat findById(Integer id) {
        return super.find(id);
    }

    public Obat findByNamaExact(String namaObat) {
        EntityManager em = JpaUtil.getEmf().createEntityManager();
        try {
            TypedQuery<Obat> q = em.createQuery(
                "SELECT o FROM Obat o WHERE o.namaObat = :n", Obat.class);
            q.setParameter("n", namaObat);
            return q.getSingleResult();
        } catch (NoResultException e) {
            return null;
        } finally { em.close(); }
    }

    public boolean existsByNama(String namaObat) {
        EntityManager em = JpaUtil.getEmf().createEntityManager();
        try {
            Long cnt = em.createQuery(
                "SELECT COUNT(o) FROM Obat o WHERE o.namaObat = :n", Long.class)
                .setParameter("n", namaObat)
                .getSingleResult();
            return cnt != null && cnt > 0;
        } finally { em.close(); }
    }

    public List<Obat> findByNamaContains(String keyword) {
        EntityManager em = JpaUtil.getEmf().createEntityManager();
        try {
            return em.createQuery(
                "SELECT o FROM Obat o " +
                "WHERE LOWER(o.namaObat) LIKE :kw " +
                "ORDER BY o.namaObat", Obat.class)
                .setParameter("kw", "%" + (keyword == null ? "" : keyword.toLowerCase()) + "%")
                .getResultList();
        } finally { em.close(); }
    }

    public List<Obat> findByGolongan(String golongan) {
        EntityManager em = JpaUtil.getEmf().createEntityManager();
        try {
            return em.createQuery(
                "SELECT o FROM Obat o WHERE o.golongan = :g ORDER BY o.namaObat", Obat.class)
                .setParameter("g", golongan)
                .getResultList();
        } finally { em.close(); }
    }

    public List<Obat> findByHargaBetween(BigDecimal min, BigDecimal max) {
        EntityManager em = JpaUtil.getEmf().createEntityManager();
        try {
            return em.createQuery(
                "SELECT o FROM Obat o WHERE o.harga BETWEEN :min AND :max ORDER BY o.harga", Obat.class)
                .setParameter("min", min)
                .setParameter("max", max)
                .getResultList();
        } finally { em.close(); }
    }

    public List<Obat> searchInIndikasiOrEfek(String keyword) {
        String kw = "%" + (keyword == null ? "" : keyword.toLowerCase()) + "%";
        EntityManager em = JpaUtil.getEmf().createEntityManager();
        try {
            return em.createQuery(
                "SELECT o FROM Obat o " +
                "WHERE LOWER(o.indikasiUmum) LIKE :kw OR LOWER(o.efekSamping) LIKE :kw " +
                "ORDER BY o.namaObat", Obat.class)
                .setParameter("kw", kw)
                .getResultList();
        } finally { em.close(); }
    }

    public List<AnjuranObat> listAnjuran(Integer idObat) {
        EntityManager em = JpaUtil.getEmf().createEntityManager();
        try {
            return em.createQuery(
                "SELECT a FROM AnjuranObat a WHERE a.obat.id = :id", AnjuranObat.class)
                .setParameter("id", idObat)
                .getResultList();
        } finally { em.close(); }
    }

    public boolean updateHarga(Integer idObat, BigDecimal hargaBaru) {
        EntityManager em = JpaUtil.getEmf().createEntityManager();
        var tx = em.getTransaction();
        try {
            tx.begin();
            Obat o = em.find(Obat.class, idObat);
            if (o == null) { tx.rollback(); return false; }
            o.setHarga(hargaBaru);
            em.merge(o);
            tx.commit();
            return true;
        } catch (RuntimeException ex) {
            if (tx.isActive()) tx.rollback();
            throw ex;
        } finally { em.close(); }
    }

    public List<Obat> latest(int max) {
        EntityManager em = JpaUtil.getEmf().createEntityManager();
        try {
            return em.createQuery(
                "SELECT o FROM Obat o ORDER BY o.id DESC", Obat.class)
                .setMaxResults(Math.max(0, max))
                .getResultList();
        } finally { em.close(); }
    }

    public List<Obat> page(int offset, int limit) {
        EntityManager em = JpaUtil.getEmf().createEntityManager();
        try {
            return em.createQuery(
                "SELECT o FROM Obat o ORDER BY o.namaObat", Obat.class)
                .setFirstResult(Math.max(0, offset))
                .setMaxResults(Math.max(0, limit))
                .getResultList();
        } finally { em.close(); }
    }

    public long countAll() {
        EntityManager em = JpaUtil.getEmf().createEntityManager();
        try {
            Long cnt = em.createQuery("SELECT COUNT(o) FROM Obat o", Long.class)
                         .getSingleResult();
            return cnt == null ? 0L : cnt;
        } finally { em.close(); }
    }
    public void deleteById(Integer id) {
        var em = JpaUtil.getEmf().createEntityManager();
        var tx = em.getTransaction();
        try {
            tx.begin();
            Obat o = em.find(Obat.class, id);
            if (o == null) throw new jakarta.persistence.EntityNotFoundException("Obat tidak ditemukan");

            em.remove(o);                         
            tx.commit();
        } catch (jakarta.persistence.PersistenceException pe) {
            if (tx.isActive()) tx.rollback();
            throw new ReferentialIntegrityException("Obat masih dipakai (FK).", pe);
        } catch (RuntimeException ex) {
            if (tx.isActive()) tx.rollback();
            throw ex;
        } finally { em.close(); }
    }
    public class ReferentialIntegrityException extends RuntimeException {
        public ReferentialIntegrityException(String msg, Throwable cause) { super(msg, cause); }
    }
    public void deleteForce(Integer idObat) {
        var em = JpaUtil.getEmf().createEntityManager();
        var tx = em.getTransaction();
        try {
            tx.begin();

            em.createQuery("DELETE FROM AnjuranObat a WHERE a.obat.id = :id")
              .setParameter("id", idObat)
              .executeUpdate();

            em.createQuery("DELETE FROM Obat o WHERE o.id = :id")
              .setParameter("id", idObat)
              .executeUpdate();

            tx.commit();
        } catch (RuntimeException ex) {
            if (tx.isActive()) tx.rollback();
            throw ex;
        } finally {
            em.close();
        }
    }

}

package dao;

import jakarta.persistence.EntityManager;
import jakarta.persistence.NoResultException;
import jakarta.persistence.TypedQuery;
import java.util.List;

import model.Penyakit;
import util.JpaUtil;

public class PenyakitDao extends BaseDao<Penyakit, Integer> {

    public PenyakitDao() {
        super(Penyakit.class);
    }

    public boolean existsByNama(String nama, Integer exceptId) {
        String norm = nama == null ? "" : nama.trim().toLowerCase();
        var em = JpaUtil.getEmf().createEntityManager();
        try {
            String jpql = """
                SELECT COUNT(p) FROM Penyakit p
                WHERE LOWER(TRIM(p.namaPenyakit)) = :n
                  AND (:id IS NULL OR p.id <> :id)
            """;
            Long cnt = em.createQuery(jpql, Long.class)
                    .setParameter("n", norm)
                    .setParameter("id", exceptId)
                    .getSingleResult();
            return cnt != null && cnt > 0;
        } finally { em.close(); }
    }
    
    public Penyakit findById(Integer id) {
        return super.find(id);
    }

    public Penyakit findByNamaExact(String namaPenyakit) {
        EntityManager em = JpaUtil.getEmf().createEntityManager();
        try {
            TypedQuery<Penyakit> q = em.createQuery(
                "SELECT p FROM Penyakit p WHERE p.namaPenyakit = :n", Penyakit.class);
            q.setParameter("n", namaPenyakit);
            return q.getSingleResult();
        } catch (NoResultException e) {
            return null;
        } finally { em.close(); }
    }

    public List<Penyakit> findByNamaContains(String keyword) {
        EntityManager em = JpaUtil.getEmf().createEntityManager();
        try {
            return em.createQuery(
                "SELECT p FROM Penyakit p " +
                "WHERE LOWER(p.namaPenyakit) LIKE :kw " +
                "ORDER BY p.namaPenyakit", Penyakit.class)
                .setParameter("kw", "%" + (keyword == null ? "" : keyword.toLowerCase()) + "%")
                .getResultList();
        } finally { em.close(); }
    }

    public List<Penyakit> findByKategori(Integer idKategori) {
        EntityManager em = JpaUtil.getEmf().createEntityManager();
        try {
            return em.createQuery(
                "SELECT p FROM Penyakit p WHERE p.kategori.id = :id ORDER BY p.namaPenyakit",
                Penyakit.class)
                .setParameter("id", idKategori)
                .getResultList();
        } finally { em.close(); }
    }

    public long countByKategori(Integer idKategori) {
        EntityManager em = JpaUtil.getEmf().createEntityManager();
        try {
            Long cnt = em.createQuery(
                "SELECT COUNT(p) FROM Penyakit p WHERE p.kategori.id = :id", Long.class)
                .setParameter("id", idKategori)
                .getSingleResult();
            return cnt == null ? 0L : cnt;
        } finally { em.close(); }
    }

    public List<Penyakit> latest(int max) {
        EntityManager em = JpaUtil.getEmf().createEntityManager();
        try {
            return em.createQuery(
                "SELECT p FROM Penyakit p ORDER BY p.id DESC", Penyakit.class)
                .setMaxResults(Math.max(0, max))
                .getResultList();
        } finally { em.close(); }
    }

    public List<Penyakit> page(int offset, int limit) {
        EntityManager em = JpaUtil.getEmf().createEntityManager();
        try {
            return em.createQuery(
                "SELECT p FROM Penyakit p ORDER BY p.namaPenyakit", Penyakit.class)
                .setFirstResult(Math.max(0, offset))
                .setMaxResults(Math.max(0, limit))
                .getResultList();
        } finally { em.close(); }
    }

    public long countAll() {
        EntityManager em = JpaUtil.getEmf().createEntityManager();
        try {
            Long cnt = em.createQuery("SELECT COUNT(p) FROM Penyakit p", Long.class)
                         .getSingleResult();
            return cnt == null ? 0L : cnt;
        } finally { em.close(); }
    }
    
        public void deleteForce(Integer idObat) {
        var em = JpaUtil.getEmf().createEntityManager();
        var tx = em.getTransaction();

        try {
            tx.begin();

            em.createNativeQuery("DELETE FROM anjuran_obat WHERE id_obat = ?")
              .setParameter(1, idObat)
              .executeUpdate();

            em.createNativeQuery("DELETE FROM obat WHERE id = ?")
              .setParameter(1, idObat)
              .executeUpdate();

            tx.commit();
        } catch (RuntimeException ex) {
            if (tx.isActive()) tx.rollback();
            throw ex;
        } finally {
            em.close();
        }
    }
}

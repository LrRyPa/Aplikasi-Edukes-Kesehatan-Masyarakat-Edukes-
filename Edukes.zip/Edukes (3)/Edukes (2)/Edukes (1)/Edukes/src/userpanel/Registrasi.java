
package userpanel;

import controller.AuthController;
import model.User;
import util.AppContext;

import javax.swing.JOptionPane;
import java.util.logging.Logger;
import main.Main;
import controller.AuthController;

public class Registrasi extends javax.swing.JFrame {
    private static final Logger logger = Logger.getLogger(Registrasi.class.getName());
    private final AuthController auth = new AuthController();
 
    public Registrasi() {
        initComponents();
        setTitle("Registrasi - Edukes");
        TambahNama.addActionListener(e -> TambahAlamat.requestFocusInWindow());
        TambahAlamat.addActionListener(e -> TambahEmail.requestFocusInWindow());
        TambahEmail.addActionListener(e -> TambahPassword.requestFocusInWindow());
        TambahPassword.addActionListener(e -> TambahRegistrasi.doClick());
        setLocationRelativeTo(null); 
}

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        TambahNama = new javax.swing.JTextField();
        TambahAlamat = new javax.swing.JTextField();
        KeAwal = new javax.swing.JButton();
        TambahEmail = new javax.swing.JTextField();
        TambahRegistrasi = new javax.swing.JButton();
        TambahPassword = new javax.swing.JPasswordField();
        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        TambahNama.setBackground(new java.awt.Color(255, 255, 255));
        TambahNama.setForeground(new java.awt.Color(0, 153, 153));
        TambahNama.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TambahNamaActionPerformed(evt);
            }
        });
        getContentPane().add(TambahNama, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 120, 270, 30));

        TambahAlamat.setBackground(new java.awt.Color(255, 255, 255));
        TambahAlamat.setForeground(new java.awt.Color(0, 153, 153));
        TambahAlamat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TambahAlamatActionPerformed(evt);
            }
        });
        getContentPane().add(TambahAlamat, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 180, 270, 30));

        KeAwal.setBackground(new java.awt.Color(0, 153, 153));
        KeAwal.setForeground(new java.awt.Color(255, 255, 255));
        KeAwal.setText("Kembali");
        KeAwal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                KeAwalActionPerformed(evt);
            }
        });
        getContentPane().add(KeAwal, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 20, 89, 34));

        TambahEmail.setBackground(new java.awt.Color(255, 255, 255));
        TambahEmail.setForeground(new java.awt.Color(0, 153, 153));
        getContentPane().add(TambahEmail, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 230, 270, 30));

        TambahRegistrasi.setBackground(new java.awt.Color(0, 153, 153));
        TambahRegistrasi.setForeground(new java.awt.Color(255, 255, 255));
        TambahRegistrasi.setText("Kirim");
        TambahRegistrasi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TambahRegistrasiActionPerformed(evt);
            }
        });
        getContentPane().add(TambahRegistrasi, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 340, 75, 30));

        TambahPassword.setBackground(new java.awt.Color(255, 255, 255));
        TambahPassword.setForeground(new java.awt.Color(0, 153, 153));
        getContentPane().add(TambahPassword, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 290, 270, 30));

        jPanel1.setBackground(new java.awt.Color(162, 219, 223));
        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 320, 220, 30));

        jLabel2.setBackground(new java.awt.Color(255, 255, 255));
        jLabel2.setForeground(new java.awt.Color(0, 153, 153));
        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/FrameRegist.png"))); // NOI18N
        jLabel2.setText("jLabel2");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 710, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void TambahNamaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TambahNamaActionPerformed

    }//GEN-LAST:event_TambahNamaActionPerformed

    private void TambahAlamatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TambahAlamatActionPerformed
        if (TambahAlamat.getText().trim().isEmpty()) {
        JOptionPane.showMessageDialog(this, "Alamat belum diisi!", "Peringatan", JOptionPane.WARNING_MESSAGE);
    }
    }//GEN-LAST:event_TambahAlamatActionPerformed

    private void KeAwalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_KeAwalActionPerformed
        Main main = new Main();
        main.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_KeAwalActionPerformed

    private void TambahRegistrasiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TambahRegistrasiActionPerformed
      try {
            String nama = TambahNama.getText().trim();
            String alamat = TambahAlamat.getText().trim();
            String email = TambahEmail.getText().trim();
            String password = new String(TambahPassword.getPassword()).trim();

            if (nama.isEmpty() || alamat.isEmpty() || email.isEmpty() || password.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Semua field harus diisi!", "Peringatan", JOptionPane.WARNING_MESSAGE);
                return;
            }

            User user = auth.registerUser(nama, email, password, alamat);


            AppContext.setCurrentAkun(user);

            JOptionPane.showMessageDialog(this, "Akun berhasil didaftarkan!", "Sukses", JOptionPane.INFORMATION_MESSAGE);


            new main.Main().setVisible(true);
            this.dispose();

        } catch (Exception e) {
            logger.warning("Registrasi gagal: " + e.getMessage());
            JOptionPane.showMessageDialog(this, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_TambahRegistrasiActionPerformed
  

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton KeAwal;
    private javax.swing.JTextField TambahAlamat;
    private javax.swing.JTextField TambahEmail;
    private javax.swing.JTextField TambahNama;
    private javax.swing.JPasswordField TambahPassword;
    private javax.swing.JButton TambahRegistrasi;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    // End of variables declaration//GEN-END:variables
}

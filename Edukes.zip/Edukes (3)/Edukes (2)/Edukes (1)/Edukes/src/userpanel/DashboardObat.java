package userpanel;

import controller.ObatController;
import model.Obat;

import javax.swing.table.DefaultTableModel;
import javax.swing.event.DocumentListener;
import javax.swing.event.DocumentEvent;
import java.text.NumberFormat;
import java.util.Locale;
import javax.swing.JOptionPane;
import java.awt.*;
import java.awt.event.*;
import java.text.DecimalFormat;



public class DashboardObat extends javax.swing.JFrame {
    
    private final ObatController obatController = new ObatController();
    private DefaultTableModel tblModel;
    
    private java.util.List<Obat> cache = java.util.List.of();
    
    public DashboardObat() {
        initComponents();                   
        setLocationRelativeTo(null);
        setTitle("Dashboard Obat");
        
        setupTableModel();
        loadOnce();         
        tampilkan(cache);  
        setupSearchPlaceholder();
        hookLiveSearch();
        
        jPanel7.setOpaque(false);
        jPanel7.setBackground(new java.awt.Color(0,0,0,0));
        tblObat.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override public void mouseClicked(java.awt.event.MouseEvent e) {
                if (e.getClickCount() == 2 && javax.swing.SwingUtilities.isLeftMouseButton(e)) {
                showObatDetail();
                }
            }
        });
    }
    private void setupTableModel() {
        tblModel = new DefaultTableModel(new Object[]{
            "Nama Obat","Deskripsi","Harga","Golongan","Indikasi Umum","Efek Samping"
        }, 0) {
            @Override public boolean isCellEditable(int r, int c){ return false; }
            @Override public Class<?> getColumnClass(int c){ return String.class; }
        };
        tblObat.setModel(tblModel);
        tblObat.getTableHeader().setReorderingAllowed(false);

        int[] w = {160,260,110,120,220,220};
        for (int i=0; i<w.length && i<tblObat.getColumnModel().getColumnCount(); i++) {
            tblObat.getColumnModel().getColumn(i).setPreferredWidth(w[i]);
        }
    }
    private void setupSearchPlaceholder() {
        PencarianObat.setText("Cari Obat");
        PencarianObat.setForeground(Color.GRAY);

        PencarianObat.addFocusListener(new FocusAdapter() {
            @Override public void focusGained(FocusEvent e) {
                if ("Cari Obat".equals(PencarianObat.getText())) {
                    PencarianObat.setText("");
                    PencarianObat.setForeground(Color.BLACK);
                }
            }
            @Override public void focusLost(FocusEvent e) {
                if (PencarianObat.getText().isBlank()) {
                    PencarianObat.setText("Cari Obat");
                    PencarianObat.setForeground(Color.GRAY);
                }
            }
        });
    }
    private void loadOnce() {
        cache = obatController.listAll();    // ganti sesuai nama method di service/dao kamu
        if (cache == null) cache = java.util.List.of();
        System.out.println("Jumlah obat: " + cache.size()); // debug
    }

    
    private void tampilkan(java.util.List<Obat> data) {
        tblModel.setRowCount(0);
        for (Obat o : data) {
            String nama      = nz(o.getNamaObat());
            String desk      = ringkas(nz(o.getDeskripsi()), 160);
            String harga     = formatRupiah(o.getHarga());          // support BigDecimal/Number/null
            String golongan  = nz(o.getGolongan());                  // atau o.getGolongan().getNama()
            String indikasi  = ringkas(nz(o.getIndikasiUmum()), 140);
            String efek      = ringkas(nz(o.getEfekSamping()), 140);

            tblModel.addRow(new Object[]{ nama, desk, harga, golongan, indikasi, efek });
        }
    }
   
    private void hookLiveSearch() {
        PencarianObat.getDocument().addDocumentListener(new DocumentListener() {
            @Override public void insertUpdate(DocumentEvent e){ filter(); }
            @Override public void removeUpdate(DocumentEvent e){ filter(); }
            @Override public void changedUpdate(DocumentEvent e){ filter(); }
        });
    }
    
    private static String formatRupiah(Object harga){
        if (harga == null) return "-";
        try {
            Number n = (harga instanceof Number) ? (Number) harga
                        : new java.math.BigDecimal(String.valueOf(harga));

            DecimalFormat nf = (DecimalFormat) NumberFormat.getCurrencyInstance(new Locale("id","ID"));
            // Paksa prefix pakai spasi setelah Rp
            nf.setPositivePrefix("Rp ");
            nf.setNegativePrefix("-Rp ");

            nf.setMaximumFractionDigits(0); // kalau mau tanpa ,00
            return nf.format(n);
        } catch (Exception e) {
            return String.valueOf(harga);
        }
    }
    
    private void filter() {
        String q = PencarianObat.getText()==null ? "" : PencarianObat.getText().trim().toLowerCase();
        if (q.isEmpty()) { tampilkan(cache); return; }

        var hasil = cache.stream().filter(o ->
               nz(o.getNamaObat()).toLowerCase().contains(q)
            || nz(o.getDeskripsi()).toLowerCase().contains(q)
            || nz(o.getGolongan()).toLowerCase().contains(q)
            || nz(o.getIndikasiUmum()).toLowerCase().contains(q)
            || nz(o.getEfekSamping()).toLowerCase().contains(q)
            || formatRupiah(o.getHarga()).toLowerCase().contains(q)   // ketik “50000” juga ketemu
        ).toList();

        tampilkan(hasil);
    }
    
    private void showObatDetail() {
        int viewRow = tblObat.getSelectedRow();
        if (viewRow < 0) {
            javax.swing.JOptionPane.showMessageDialog(this, "Pilih baris obat dulu, ya.");
            return;
        }
        int row = tblObat.convertRowIndexToModel(viewRow);

        String nama     = nz(tblModel.getValueAt(row, 0));
        String desk     = nz(tblModel.getValueAt(row, 1));
        String harga    = nz(tblModel.getValueAt(row, 2)); 
        String golongan = nz(tblModel.getValueAt(row, 3));
        String indikasi = nz(tblModel.getValueAt(row, 4));
        String efek     = nz(tblModel.getValueAt(row, 5));

        String html = "<html><body style='width:560px;font-family:Segoe UI, sans-serif'>"
                + "<h3 style='margin:0;padding:0'>" + esc(nama) + "</h3><hr>"
                + "<b>Golongan:</b> " + esc(golongan) + "<br>"
                + "<b>Harga:</b> "    + esc(harga)    + "<br>"
                + "<b>Indikasi Umum:</b><br>" + esc(indikasi) + "<br><br>"
                + "<b>Deskripsi:</b><br>"      + esc(desk)     + "<br><br>"
                + "<b>Efek Samping:</b><br>"   + esc(efek)
                + "</body></html>";

        javax.swing.JOptionPane.showMessageDialog(this, html, "Detail Obat", javax.swing.JOptionPane.INFORMATION_MESSAGE);
    }


    private static String nz(Object o) {
        return (o == null) ? "" : String.valueOf(o);
    }
    private static String esc(String s) {
        return s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;");
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        TabelObat = new javax.swing.JScrollPane();
        tblObat = new javax.swing.JTable();
        jPanel7 = new javax.swing.JPanel();
        KeObat5 = new javax.swing.JButton();
        KeArtikel5 = new javax.swing.JButton();
        KePenyakit5 = new javax.swing.JButton();
        KeMain5 = new javax.swing.JButton();
        keAnjuranObat4 = new javax.swing.JButton();
        KeProfil = new javax.swing.JButton();
        PencarianObat = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        addContainerListener(new java.awt.event.ContainerAdapter() {
            public void componentAdded(java.awt.event.ContainerEvent evt) {
                formComponentAdded(evt);
            }
        });
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        tblObat.setBackground(new java.awt.Color(255, 255, 255));
        tblObat.setForeground(new java.awt.Color(0, 0, 0));
        tblObat.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "Nama Obat", "Deskripsi", "Harga", "Golongan", "Indikasi Umum", "Efek Samping"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.Double.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        TabelObat.setViewportView(tblObat);

        getContentPane().add(TabelObat, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 130, 650, 310));

        jPanel7.setBackground(new java.awt.Color(230, 247, 249));

        KeObat5.setBackground(new java.awt.Color(219, 249, 249));
        KeObat5.setForeground(new java.awt.Color(0, 153, 153));
        KeObat5.setText("Obat");
        KeObat5.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        KeObat5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                KeObat5ActionPerformed(evt);
            }
        });

        KeArtikel5.setBackground(new java.awt.Color(219, 249, 249));
        KeArtikel5.setForeground(new java.awt.Color(0, 153, 153));
        KeArtikel5.setText("Artikel");
        KeArtikel5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                KeArtikel5ActionPerformed(evt);
            }
        });

        KePenyakit5.setBackground(new java.awt.Color(219, 249, 249));
        KePenyakit5.setForeground(new java.awt.Color(0, 153, 153));
        KePenyakit5.setText("Penyakit");
        KePenyakit5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                KePenyakit5ActionPerformed(evt);
            }
        });

        KeMain5.setBackground(new java.awt.Color(0, 51, 51));
        KeMain5.setForeground(new java.awt.Color(255, 255, 255));
        KeMain5.setText("Kembali");
        KeMain5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                KeMain5ActionPerformed(evt);
            }
        });

        keAnjuranObat4.setBackground(new java.awt.Color(219, 249, 249));
        keAnjuranObat4.setForeground(new java.awt.Color(0, 153, 153));
        keAnjuranObat4.setText("Anjuran Obat");
        keAnjuranObat4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                keAnjuranObat4ActionPerformed(evt);
            }
        });

        KeProfil.setBackground(new java.awt.Color(219, 249, 249));
        KeProfil.setForeground(new java.awt.Color(0, 153, 153));
        KeProfil.setText("Profil");
        KeProfil.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                KeProfilMouseClicked(evt);
            }
        });
        KeProfil.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                KeProfilActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(KeProfil, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(KeArtikel5, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(KePenyakit5, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(KeObat5, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(keAnjuranObat4, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 81, Short.MAX_VALUE)
                .addComponent(KeMain5, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(KeArtikel5, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(KePenyakit5, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(KeObat5, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(KeMain5, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(keAnjuranObat4, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(KeProfil, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(14, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 20, 610, 60));

        PencarianObat.setBackground(new java.awt.Color(255, 255, 255));
        PencarianObat.setForeground(new java.awt.Color(0, 0, 0));
        PencarianObat.setText("Cari Obat");
        PencarianObat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PencarianObatActionPerformed(evt);
            }
        });
        getContentPane().add(PencarianObat, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 90, 320, 30));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/FrameObat&Penyakit.png"))); // NOI18N
        jLabel2.setText("jLabel2");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 710, -1));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents
    private static String nz(String s){ return s==null ? "" : s; }

    private static String ringkas(String s, int max){
        String t = s.replace('\n',' ').trim();
        return t.length() <= max ? t : t.substring(0, max-3) + "...";
    }

    private void formComponentAdded(java.awt.event.ContainerEvent evt) {//GEN-FIRST:event_formComponentAdded
        // TODO add your handling code here:
    }//GEN-LAST:event_formComponentAdded

    private void KeObat5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_KeObat5ActionPerformed
        JOptionPane.showMessageDialog(this, "Kamu sudah di halaman obat.");
    }//GEN-LAST:event_KeObat5ActionPerformed

    private void KeArtikel5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_KeArtikel5ActionPerformed
        DashboardArtikel dashboardArtikel = new DashboardArtikel();
        dashboardArtikel.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_KeArtikel5ActionPerformed

    private void KePenyakit5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_KePenyakit5ActionPerformed
        DashboardPenyakit dashboardPenyakit = new DashboardPenyakit();
        dashboardPenyakit.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_KePenyakit5ActionPerformed

    private void KeMain5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_KeMain5ActionPerformed
        DashboardAwal main = new DashboardAwal();
        main.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_KeMain5ActionPerformed

    private void keAnjuranObat4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_keAnjuranObat4ActionPerformed
        DashboardAnjuranObat dashboardanjuran = new DashboardAnjuranObat();
        dashboardanjuran.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_keAnjuranObat4ActionPerformed

    private void KeProfilMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_KeProfilMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_KeProfilMouseClicked

    private void KeProfilActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_KeProfilActionPerformed
        FormProfil profil = new FormProfil();
        profil.setVisible(true);
        this.dispose();            
    }//GEN-LAST:event_KeProfilActionPerformed

    private void PencarianObatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PencarianObatActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_PencarianObatActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
//            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
//        java.awt.EventQueue.invokeLater(() -> new DashboardAwal().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton KeArtikel5;
    private javax.swing.JButton KeMain5;
    private javax.swing.JButton KeObat5;
    private javax.swing.JButton KePenyakit5;
    private javax.swing.JButton KeProfil;
    private javax.swing.JTextField PencarianObat;
    private javax.swing.JScrollPane TabelObat;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JButton keAnjuranObat4;
    private javax.swing.JTable tblObat;
    // End of variables declaration//GEN-END:variables
}

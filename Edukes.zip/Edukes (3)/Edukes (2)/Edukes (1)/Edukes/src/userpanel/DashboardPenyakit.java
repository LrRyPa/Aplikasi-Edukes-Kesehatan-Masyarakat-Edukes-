package userpanel;

import controller.PenyakitController;
import model.Penyakit;
import model.Kategori; // kalau ada entitas ini

import javax.swing.table.DefaultTableModel;
import javax.swing.event.DocumentListener;
import javax.swing.event.DocumentEvent;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.List;
import javax.swing.JOptionPane;

public class DashboardPenyakit extends javax.swing.JFrame {
    
    private final PenyakitController penyakitController = new PenyakitController();
    private DefaultTableModel tblModel;
    private List<Penyakit> cache;
    
    public DashboardPenyakit() {
        initComponents();
        setLocationRelativeTo(null);
        setTitle("Dashboard Penyakit");

        setupTableModel();
        setupPlaceholderSearch();
        loadOnce();           
        tampilkan(cache);     
        hookLiveSearch();     
        hookDoubleClick(); 
        jPanel7.setOpaque(false);
        jPanel7.setBackground(new java.awt.Color(0,0,0,0));
    }
       
    private void setupTableModel() {
        tblModel = new DefaultTableModel(new Object[]{
                "Nama Penyakit", "Kategori", "Pengertian", "Gejala",
                "Faktor Resiko", "Pengobatan", "Pencegahan"
        }, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
            @Override public Class<?> getColumnClass(int c) { return String.class; }
        };
        tblPenyakit.setModel(tblModel);
        tblPenyakit.getTableHeader().setReorderingAllowed(false);

        // atur lebar biar enak
        int[] w = {160, 120, 260, 220, 220, 220, 220};
        for (int i = 0; i < w.length && i < tblPenyakit.getColumnModel().getColumnCount(); i++) {
            tblPenyakit.getColumnModel().getColumn(i).setPreferredWidth(w[i]);
        }
    }
    
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel7 = new javax.swing.JPanel();
        KeObat5 = new javax.swing.JButton();
        KeArtikel5 = new javax.swing.JButton();
        KePenyakit5 = new javax.swing.JButton();
        KeMain5 = new javax.swing.JButton();
        keAnjuranObat4 = new javax.swing.JButton();
        KeProfil1 = new javax.swing.JButton();
        TabelObat = new javax.swing.JScrollPane();
        tblPenyakit = new javax.swing.JTable();
        PencarianPenyakit = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        addContainerListener(new java.awt.event.ContainerAdapter() {
            public void componentAdded(java.awt.event.ContainerEvent evt) {
                formComponentAdded(evt);
            }
        });
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel7.setBackground(new java.awt.Color(230, 247, 249));

        KeObat5.setBackground(new java.awt.Color(219, 249, 249));
        KeObat5.setForeground(new java.awt.Color(0, 153, 153));
        KeObat5.setText("Obat");
        KeObat5.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        KeObat5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                KeObat5ActionPerformed(evt);
            }
        });

        KeArtikel5.setBackground(new java.awt.Color(219, 249, 249));
        KeArtikel5.setForeground(new java.awt.Color(0, 153, 153));
        KeArtikel5.setText("Artikel");
        KeArtikel5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                KeArtikel5ActionPerformed(evt);
            }
        });

        KePenyakit5.setBackground(new java.awt.Color(219, 249, 249));
        KePenyakit5.setForeground(new java.awt.Color(0, 153, 153));
        KePenyakit5.setText("Penyakit");
        KePenyakit5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                KePenyakit5ActionPerformed(evt);
            }
        });

        KeMain5.setBackground(new java.awt.Color(0, 51, 51));
        KeMain5.setForeground(new java.awt.Color(255, 255, 255));
        KeMain5.setText("Kembali");
        KeMain5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                KeMain5ActionPerformed(evt);
            }
        });

        keAnjuranObat4.setBackground(new java.awt.Color(219, 249, 249));
        keAnjuranObat4.setForeground(new java.awt.Color(0, 153, 153));
        keAnjuranObat4.setText("Anjuran Obat");
        keAnjuranObat4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                keAnjuranObat4ActionPerformed(evt);
            }
        });

        KeProfil1.setBackground(new java.awt.Color(219, 249, 249));
        KeProfil1.setForeground(new java.awt.Color(0, 153, 153));
        KeProfil1.setText("Profil");
        KeProfil1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                KeProfil1MouseClicked(evt);
            }
        });
        KeProfil1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                KeProfil1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(KeProfil1, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(KeArtikel5, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(KePenyakit5, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(KeObat5, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(keAnjuranObat4, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 81, Short.MAX_VALUE)
                .addComponent(KeMain5, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(KeArtikel5, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(KePenyakit5, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(KeObat5, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(KeMain5, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(keAnjuranObat4, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(KeProfil1, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(14, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 20, 610, 60));

        tblPenyakit.setBackground(new java.awt.Color(255, 255, 255));
        tblPenyakit.setForeground(new java.awt.Color(0, 0, 0));
        tblPenyakit.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "Nama Penyakit", "Kategori", "Pengertian", "Gejala", "Faktor Resiko", "Pengobatan", "Pencegahan"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        TabelObat.setViewportView(tblPenyakit);

        getContentPane().add(TabelObat, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 130, 650, 310));

        PencarianPenyakit.setBackground(new java.awt.Color(255, 255, 255));
        PencarianPenyakit.setForeground(new java.awt.Color(0, 0, 0));
        PencarianPenyakit.setText("Cari Penyakit");
        PencarianPenyakit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PencarianPenyakitActionPerformed(evt);
            }
        });
        getContentPane().add(PencarianPenyakit, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 90, 320, 30));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/FrameObat&Penyakit.png"))); // NOI18N
        jLabel2.setText("jLabel2");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 710, -1));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents
    private void loadOnce() {
        cache = penyakitController.listAll(); 
        if (cache == null) cache = java.util.List.of();
    }
    
    private void tampilkan(List<Penyakit> data) {
        tblModel.setRowCount(0);
        for (Penyakit p : data) {
            String nama      = nz(p.getNamaPenyakit());
            String kategori  = p.getKategori() == null ? "-" : nz(p.getKategori().getNamaKategori());
            String pengertian= ringkas(nz(p.getPengertian()), 160);
            String gejala    = ringkas(nz(p.getTandaGejala()), 140);
            String risiko    = ringkas(nz(p.getFaktorRisiko()), 140);
            String obat      = ringkas(nz(p.getPengobatanUmum()), 140);
            String cegah     = ringkas(nz(p.getPencegahan()), 140);
            tblModel.addRow(new Object[]{ nama, kategori, pengertian, gejala, risiko, obat, cegah });
        }
    }
    private void setupPlaceholderSearch() {
        PencarianPenyakit.setForeground(Color.GRAY);
        PencarianPenyakit.setText("Cari Penyakit");
        PencarianPenyakit.addFocusListener(new java.awt.event.FocusAdapter() {
            @Override public void focusGained(java.awt.event.FocusEvent e) {
                if ("Cari Penyakit".equalsIgnoreCase(PencarianPenyakit.getText())) {
                    PencarianPenyakit.setText(""); PencarianPenyakit.setForeground(Color.BLACK);
                }
            }
            @Override public void focusLost(java.awt.event.FocusEvent e) {
                if (PencarianPenyakit.getText().isBlank()) {
                    PencarianPenyakit.setForeground(Color.GRAY);
                    PencarianPenyakit.setText("Cari Penyakit");
                }
            }
        });
    }
    
    private void hookLiveSearch() {
        PencarianPenyakit.getDocument().addDocumentListener(new DocumentListener() {
            @Override public void insertUpdate(DocumentEvent e) { filter(); }
            @Override public void removeUpdate(DocumentEvent e) { filter(); }
            @Override public void changedUpdate(DocumentEvent e) { filter(); }
        });
    }

    private void filter() {
        String q = PencarianPenyakit.getText().trim().toLowerCase();
        if (q.isEmpty() || "cari penyakit".equalsIgnoreCase(q)) {
            tampilkan(cache); return;
        }
        List<Penyakit> hasil = cache.stream().filter(p ->
            nz(p.getNamaPenyakit()).toLowerCase().contains(q)
         || (p.getKategori()!=null && nz(p.getKategori().getNamaKategori()).toLowerCase().contains(q))
         || nz(p.getPengertian()).toLowerCase().contains(q)
         || nz(p.getTandaGejala()).toLowerCase().contains(q)
         || nz(p.getFaktorRisiko()).toLowerCase().contains(q)
         || nz(p.getPengobatanUmum()).toLowerCase().contains(q)
         || nz(p.getPencegahan()).toLowerCase().contains(q)
        ).toList();
        tampilkan(hasil);
    }
    
    private void hookDoubleClick() {
        tblPenyakit.addMouseListener(new MouseAdapter() {
            @Override public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2 && javax.swing.SwingUtilities.isLeftMouseButton(e)) {
                    int r = tblPenyakit.getSelectedRow();
                    if (r < 0) return;
                    String namaDipilih = String.valueOf(tblModel.getValueAt(r, 0));
                    cache.stream()
                         .filter(p -> nz(p.getNamaPenyakit()).equals(namaDipilih))
                         .findFirst()
                         .ifPresent(DashboardPenyakit.this::showDetailDialog);
                }
            }
        });
    }

    private void showDetailDialog(Penyakit p) {
        String kategori = p.getKategori()==null ? "-" : nz(p.getKategori().getNamaKategori());
        String html = """
            <html><body style='width:640px'>
            <h3 style='margin:0'>%s</h3><hr>
            <b>Kategori:</b> %s<br><br>
            <b>Pengertian</b><br>%s<br><br>
            <b>Gejala</b><br>%s<br><br>
            <b>Faktor Risiko</b><br>%s<br><br>
            <b>Pengobatan</b><br>%s<br><br>
            <b>Pencegahan</b><br>%s
            </body></html>
        """.formatted(esc(nz(p.getNamaPenyakit())), esc(kategori),
                      esc(nz(p.getPengertian())), esc(nz(p.getTandaGejala())),
                      esc(nz(p.getFaktorRisiko())), esc(nz(p.getPengobatanUmum())),
                      esc(nz(p.getPencegahan())));
        JOptionPane.showMessageDialog(this, html, "Detail Penyakit", JOptionPane.INFORMATION_MESSAGE);
    }
    
    private static String nz(String s){ return s == null ? "" : s; }
    private static String ringkas(String s, int max){
        String t = s.replace('\n',' ').trim();
        return t.length() <= max ? t : t.substring(0, max-3) + "...";
    }
    private static String esc(String s){
        return s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;");
    }

    private void formComponentAdded(java.awt.event.ContainerEvent evt) {//GEN-FIRST:event_formComponentAdded
        // TODO add your handling code here:
    }//GEN-LAST:event_formComponentAdded

    private void KeObat5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_KeObat5ActionPerformed
        DashboardObat dashboardObat = new DashboardObat();
        dashboardObat.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_KeObat5ActionPerformed

    private void KeArtikel5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_KeArtikel5ActionPerformed
        DashboardArtikel dashboardArtikel = new DashboardArtikel();
        dashboardArtikel.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_KeArtikel5ActionPerformed

    private void KePenyakit5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_KePenyakit5ActionPerformed
        JOptionPane.showMessageDialog(this, "Kamu sudah di halaman penyakit.");
    }//GEN-LAST:event_KePenyakit5ActionPerformed

    private void KeMain5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_KeMain5ActionPerformed
        DashboardAwal main = new DashboardAwal();
        main.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_KeMain5ActionPerformed

    private void keAnjuranObat4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_keAnjuranObat4ActionPerformed
        DashboardAnjuranObat dashboardanjuran = new DashboardAnjuranObat();
        dashboardanjuran.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_keAnjuranObat4ActionPerformed

    private void KeProfil1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_KeProfil1MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_KeProfil1MouseClicked

    private void KeProfil1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_KeProfil1ActionPerformed
    new FormProfil(util.Sesi.getPengguna()).setVisible(true);
    this.dispose();  
    }//GEN-LAST:event_KeProfil1ActionPerformed

    private void PencarianPenyakitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PencarianPenyakitActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_PencarianPenyakitActionPerformed

    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
//            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
//        java.awt.EventQueue.invokeLater(() -> new DashboardAwal().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton KeArtikel5;
    private javax.swing.JButton KeMain5;
    private javax.swing.JButton KeObat5;
    private javax.swing.JButton KePenyakit5;
    private javax.swing.JButton KeProfil1;
    private javax.swing.JTextField PencarianPenyakit;
    private javax.swing.JScrollPane TabelObat;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JButton keAnjuranObat4;
    private javax.swing.JTable tblPenyakit;
    // End of variables declaration//GEN-END:variables
}


package userpanel;

import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import model.User;
import service.UserService;
import javax.swing.JOptionPane;


public class DashboardEditProfil extends javax.swing.JFrame {  

    private final FormProfil parent;
    private User user;                    
    private final UserService userSvc = new UserService();
    
    public DashboardEditProfil(FormProfil parent, User user) {
        this.parent = parent;
        this.user   = user;

        initComponents();                
        setLocationRelativeTo(parent);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setTitle("Edit Profil");

        TampilkanNama.setText(nv(user.getNama()));
        TampilkanAlamat.setText(nv(user.getAlamat()));
        TampilkanEmail.setText(nv(user.getEmail()));
        TampilkanPassword.setText("");          
        TampilkanTanggal.setText(user.getTanggalRegistrasi() == null ? "-" : user.getTanggalRegistrasi().toString());
        TampilkanTanggal.setEditable(false);    
        TampilkanEmail.setEditable(false);
        
        SimpanProfil.addActionListener(e -> onSimpan());

        BatalSimpan.addActionListener(e -> closeBackToParent());

        KeProfil1.addActionListener(e -> closeBackToParent());
        KeArtikel5.addActionListener(e -> closeBackToParent());
        KePenyakit5.addActionListener(e -> closeBackToParent());
        KeObat5.addActionListener(e -> closeBackToParent());
        KeMain5.addActionListener(e -> closeBackToParent());
        
        jPanel7.setOpaque(false);
        jPanel7.setBackground(new java.awt.Color(0,0,0,0));

        addWindowListener(new WindowAdapter() {
            @Override public void windowClosing(WindowEvent e) {  }
            @Override public void windowClosed(WindowEvent e) { }
        });
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        TampilkanNama = new javax.swing.JTextField();
        TampilkanAlamat = new javax.swing.JTextField();
        TampilkanEmail = new javax.swing.JTextField();
        TampilkanTanggal = new javax.swing.JTextField();
        BatalSimpan = new javax.swing.JButton();
        SimpanProfil = new javax.swing.JButton();
        TampilkanPassword = new javax.swing.JPasswordField();
        jPanel7 = new javax.swing.JPanel();
        KeObat5 = new javax.swing.JButton();
        KeArtikel5 = new javax.swing.JButton();
        KePenyakit5 = new javax.swing.JButton();
        KeMain5 = new javax.swing.JButton();
        keAnjuranObat4 = new javax.swing.JButton();
        KeProfil1 = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        addContainerListener(new java.awt.event.ContainerAdapter() {
            public void componentAdded(java.awt.event.ContainerEvent evt) {
                formComponentAdded(evt);
            }
        });
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        TampilkanNama.setBackground(new java.awt.Color(255, 255, 255));
        TampilkanNama.setForeground(new java.awt.Color(0, 0, 0));
        TampilkanNama.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TampilkanNamaActionPerformed(evt);
            }
        });
        getContentPane().add(TampilkanNama, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 122, 190, 30));

        TampilkanAlamat.setBackground(new java.awt.Color(255, 255, 255));
        TampilkanAlamat.setForeground(new java.awt.Color(0, 0, 0));
        TampilkanAlamat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TampilkanAlamatActionPerformed(evt);
            }
        });
        getContentPane().add(TampilkanAlamat, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 172, 190, 30));

        TampilkanEmail.setBackground(new java.awt.Color(204, 204, 204));
        TampilkanEmail.setForeground(new java.awt.Color(0, 0, 0));
        TampilkanEmail.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TampilkanEmailActionPerformed(evt);
            }
        });
        getContentPane().add(TampilkanEmail, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 232, 190, 30));

        TampilkanTanggal.setBackground(new java.awt.Color(204, 204, 204));
        TampilkanTanggal.setForeground(new java.awt.Color(0, 0, 0));
        getContentPane().add(TampilkanTanggal, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 340, 190, 30));

        BatalSimpan.setBackground(new java.awt.Color(255, 102, 102));
        BatalSimpan.setForeground(new java.awt.Color(255, 255, 255));
        BatalSimpan.setText("Batal");
        BatalSimpan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BatalSimpanActionPerformed(evt);
            }
        });
        getContentPane().add(BatalSimpan, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 390, 75, 30));

        SimpanProfil.setBackground(new java.awt.Color(0, 153, 153));
        SimpanProfil.setForeground(new java.awt.Color(255, 255, 255));
        SimpanProfil.setText("Simpan");
        SimpanProfil.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SimpanProfilActionPerformed(evt);
            }
        });
        getContentPane().add(SimpanProfil, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 390, 75, 30));

        TampilkanPassword.setBackground(new java.awt.Color(255, 255, 255));
        TampilkanPassword.setForeground(new java.awt.Color(0, 0, 0));
        TampilkanPassword.setText("jPasswordField1");
        getContentPane().add(TampilkanPassword, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 290, 190, 30));

        jPanel7.setBackground(new java.awt.Color(230, 247, 249));

        KeObat5.setBackground(new java.awt.Color(219, 249, 249));
        KeObat5.setForeground(new java.awt.Color(0, 153, 153));
        KeObat5.setText("Obat");
        KeObat5.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        KeObat5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                KeObat5ActionPerformed(evt);
            }
        });

        KeArtikel5.setBackground(new java.awt.Color(219, 249, 249));
        KeArtikel5.setForeground(new java.awt.Color(0, 153, 153));
        KeArtikel5.setText("Artikel");
        KeArtikel5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                KeArtikel5ActionPerformed(evt);
            }
        });

        KePenyakit5.setBackground(new java.awt.Color(219, 249, 249));
        KePenyakit5.setForeground(new java.awt.Color(0, 153, 153));
        KePenyakit5.setText("Penyakit");
        KePenyakit5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                KePenyakit5ActionPerformed(evt);
            }
        });

        KeMain5.setBackground(new java.awt.Color(0, 51, 51));
        KeMain5.setForeground(new java.awt.Color(255, 255, 255));
        KeMain5.setText("Kembali");
        KeMain5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                KeMain5ActionPerformed(evt);
            }
        });

        keAnjuranObat4.setBackground(new java.awt.Color(219, 249, 249));
        keAnjuranObat4.setForeground(new java.awt.Color(0, 153, 153));
        keAnjuranObat4.setText("Anjuran Obat");
        keAnjuranObat4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                keAnjuranObat4ActionPerformed(evt);
            }
        });

        KeProfil1.setBackground(new java.awt.Color(219, 249, 249));
        KeProfil1.setForeground(new java.awt.Color(0, 153, 153));
        KeProfil1.setText("Profil");
        KeProfil1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                KeProfil1MouseClicked(evt);
            }
        });
        KeProfil1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                KeProfil1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(KeProfil1, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(KeArtikel5, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(KePenyakit5, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(KeObat5, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(keAnjuranObat4, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 81, Short.MAX_VALUE)
                .addComponent(KeMain5, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(KeArtikel5, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(KePenyakit5, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(KeObat5, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(KeMain5, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(keAnjuranObat4, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(KeProfil1, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(14, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 20, 610, 60));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/FrameProfile.png"))); // NOI18N
        jLabel2.setText("jLabel2");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 710, -1));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    
    private void onSimpan() {
        try {
            String nama  = TampilkanNama.getText().trim();
            String alamat= TampilkanAlamat.getText().trim();
            String email = TampilkanEmail.getText().trim();
            String pass  = new String(TampilkanPassword.getPassword()).trim();

            if (nama.isEmpty())  throw new IllegalArgumentException("Nama wajib diisi");
            if (email.isEmpty()) throw new IllegalArgumentException("Email wajib diisi");

            user.setNama(nama);
            user.setAlamat(alamat);
            user.setEmail(email);
            if (!pass.isEmpty()) {
                user.setPassword(pass); 
            }

            user = userSvc.update(user);

            util.Sesi.setPengguna(user);

            JOptionPane.showMessageDialog(this, "Profil berhasil diperbarui.");
            closeBackToParent(); 
        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Validasi", JOptionPane.WARNING_MESSAGE);
        } catch (RuntimeException ex) {
            JOptionPane.showMessageDialog(this, "Gagal menyimpan: " + ex.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void closeBackToParent() {
        dispose();
        if (parent != null) {
            parent.refreshFromSessionAndShow();
        }
    }

    private static String nv(String s){ return s==null ? "" : s; }
    private void formComponentAdded(java.awt.event.ContainerEvent evt) {//GEN-FIRST:event_formComponentAdded
        // TODO add your handling code here:
    }//GEN-LAST:event_formComponentAdded

    private void TampilkanNamaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TampilkanNamaActionPerformed

        JOptionPane.showMessageDialog(this, 
            "Nama diperbarui sementara. Klik 'Simpan' untuk menyimpan permanen.",
            "Informasi", JOptionPane.INFORMATION_MESSAGE);
    }//GEN-LAST:event_TampilkanNamaActionPerformed

    private void BatalSimpanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BatalSimpanActionPerformed
        closeBackToParent();
    }//GEN-LAST:event_BatalSimpanActionPerformed

    private void TampilkanEmailActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TampilkanEmailActionPerformed

        JOptionPane.showMessageDialog(this, 
            "Email diperbarui sementara. Klik 'Simpan' untuk menyimpan permanen.",
            "Informasi", JOptionPane.INFORMATION_MESSAGE);
    
    }//GEN-LAST:event_TampilkanEmailActionPerformed

    private void TampilkanAlamatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TampilkanAlamatActionPerformed

       JOptionPane.showMessageDialog(this, 
           "Alamat diperbarui sementara. Klik 'Simpan' untuk menyimpan permanen.",
           "Informasi", JOptionPane.INFORMATION_MESSAGE);
    
    }//GEN-LAST:event_TampilkanAlamatActionPerformed

    private void SimpanProfilActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SimpanProfilActionPerformed
        onSimpan();
    }//GEN-LAST:event_SimpanProfilActionPerformed

    private void KeObat5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_KeObat5ActionPerformed
        closeBackToParent();
    }//GEN-LAST:event_KeObat5ActionPerformed

    private void KeArtikel5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_KeArtikel5ActionPerformed
        closeBackToParent();
    }//GEN-LAST:event_KeArtikel5ActionPerformed

    private void KePenyakit5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_KePenyakit5ActionPerformed
        closeBackToParent();
    }//GEN-LAST:event_KePenyakit5ActionPerformed

    private void KeMain5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_KeMain5ActionPerformed
        closeBackToParent();
    }//GEN-LAST:event_KeMain5ActionPerformed

    private void keAnjuranObat4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_keAnjuranObat4ActionPerformed
        closeBackToParent();
    }//GEN-LAST:event_keAnjuranObat4ActionPerformed

    private void KeProfil1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_KeProfil1MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_KeProfil1MouseClicked

    private void KeProfil1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_KeProfil1ActionPerformed
        JOptionPane.showMessageDialog(this, "Kamu sudah di halaman profil.");
    }//GEN-LAST:event_KeProfil1ActionPerformed

    /**
     * @param args the command line arguments
     */

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BatalSimpan;
    private javax.swing.JButton KeArtikel5;
    private javax.swing.JButton KeMain5;
    private javax.swing.JButton KeObat5;
    private javax.swing.JButton KePenyakit5;
    private javax.swing.JButton KeProfil1;
    private javax.swing.JButton SimpanProfil;
    private javax.swing.JTextField TampilkanAlamat;
    private javax.swing.JTextField TampilkanEmail;
    private javax.swing.JTextField TampilkanNama;
    private javax.swing.JPasswordField TampilkanPassword;
    private javax.swing.JTextField TampilkanTanggal;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JButton keAnjuranObat4;
    // End of variables declaration//GEN-END:variables
}

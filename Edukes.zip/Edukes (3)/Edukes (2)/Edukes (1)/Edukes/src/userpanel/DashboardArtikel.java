package userpanel;

import controller.ArtikelController;
import model.Artikel;
import model.Penyakit;

import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.List;

public class DashboardArtikel extends javax.swing.JFrame {
    
    private final ArtikelController artikelController = new ArtikelController();
    private DefaultTableModel tblModel;
    private List<Artikel> cachePublished;

    
    public DashboardArtikel() {
        initComponents();
        setTitle("Dashboard Artikel");
        setupTableModel();
        setupPlaceholderSearch();
        loadPublishedOnce();     
        tampilkan(cachePublished);
        hookLiveSearch();
        hookDoubleClickDetail();
        jPanel7.setOpaque(false);
        jPanel7.setBackground(new java.awt.Color(0,0,0,0));
    }

    private void setupTableModel() {
        tblModel = new DefaultTableModel(new Object[]{"Judul", "Isi Artikel", "Nama Penyakit"}, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
            @Override public Class<?> getColumnClass(int c) { return String.class; }
        };
        tblArtikel.setModel(tblModel);
        tblArtikel.getTableHeader().setReorderingAllowed(false);

        tblArtikel.getColumnModel().getColumn(0).setPreferredWidth(220); 
        tblArtikel.getColumnModel().getColumn(1).setPreferredWidth(300); 
        tblArtikel.getColumnModel().getColumn(2).setPreferredWidth(140); 
    }
    
    private void tampilkan(List<Artikel> data) {
        tblModel.setRowCount(0);
        for (Artikel a : data) {
            String judul   = nz(a.getJudul());
            String konten  = ringkas(nz(a.getKonten()), 140);
            Penyakit p     = a.getPenyakit();
            String penyakit= (p == null || p.getNamaPenyakit() == null) ? "-" : p.getNamaPenyakit();
            tblModel.addRow(new Object[]{ judul, konten, penyakit });
        }
    }
    
     private void loadPublishedOnce() {
        cachePublished = artikelController.listAll()
                .stream()
                .filter(a -> "PUBLISHED".equalsIgnoreCase(nz(a.getStatusReview())))
                .toList();
    }
     
    private void hookLiveSearch() {
        PencarianArtikel.getDocument().addDocumentListener(new DocumentListener() {
            @Override public void insertUpdate(DocumentEvent e) { filter(); }
            @Override public void removeUpdate(DocumentEvent e) { filter(); }
            @Override public void changedUpdate(DocumentEvent e) { filter(); }
        });
    }
    
    private void filter() {
        String q = PencarianArtikel.getText().trim().toLowerCase();
        if (q.isEmpty() || "cari artikel".equalsIgnoreCase(q)) {
            tampilkan(cachePublished);
            return;
        }
        List<Artikel> hasil = cachePublished.stream().filter(a ->
                nz(a.getJudul()).toLowerCase().contains(q)
             || nz(a.getKonten()).toLowerCase().contains(q)
             || (a.getPenyakit()!=null && nz(a.getPenyakit().getNamaPenyakit()).toLowerCase().contains(q))
        ).toList();
        tampilkan(hasil);
    }
    
    private void setupPlaceholderSearch() {
        PencarianArtikel.setForeground(Color.GRAY);
        PencarianArtikel.setText("Cari Artikel");
        PencarianArtikel.addFocusListener(new FocusAdapter() {
            @Override public void focusGained(FocusEvent e) {
                if ("Cari Artikel".equalsIgnoreCase(PencarianArtikel.getText())) {
                    PencarianArtikel.setText("");
                    PencarianArtikel.setForeground(Color.BLACK);
                }
            }
            @Override public void focusLost(FocusEvent e) {
                if (PencarianArtikel.getText().isBlank()) {
                    PencarianArtikel.setForeground(Color.GRAY);
                    PencarianArtikel.setText("Cari Artikel");
                }
            }
        });
    }
    
    private void hookDoubleClickDetail() {
        tblArtikel.addMouseListener(new MouseAdapter() {
            @Override public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2 && SwingUtilities.isLeftMouseButton(e)) {
                    int r = tblArtikel.getSelectedRow();
                    if (r < 0) return;
                    String j = String.valueOf(tblModel.getValueAt(r, 0));
                    cachePublished.stream()
                            .filter(a -> nz(a.getJudul()).equals(j))
                            .findFirst()
                            .ifPresent(DashboardArtikel.this::showDetailDialog);
                }
            }
        });
    }
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        tblArtikel = new javax.swing.JTable();
        jPanel7 = new javax.swing.JPanel();
        KeObat5 = new javax.swing.JButton();
        KeArtikel5 = new javax.swing.JButton();
        KePenyakit5 = new javax.swing.JButton();
        KeMain5 = new javax.swing.JButton();
        keAnjuranObat4 = new javax.swing.JButton();
        KeProfil1 = new javax.swing.JButton();
        PencarianArtikel = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(720, 492));
        addContainerListener(new java.awt.event.ContainerAdapter() {
            public void componentAdded(java.awt.event.ContainerEvent evt) {
                formComponentAdded(evt);
            }
        });
        getContentPane().setLayout(null);

        tblArtikel.setBackground(new java.awt.Color(255, 255, 255));
        tblArtikel.setForeground(new java.awt.Color(0, 0, 0));
        tblArtikel.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "Judul", "Isi Artikel", "Nama Penyakit"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        jScrollPane1.setViewportView(tblArtikel);

        getContentPane().add(jScrollPane1);
        jScrollPane1.setBounds(50, 140, 640, 300);

        jPanel7.setBackground(new java.awt.Color(230, 247, 249));
        jPanel7.setMaximumSize(new java.awt.Dimension(101, 23));
        jPanel7.setMinimumSize(new java.awt.Dimension(101, 23));

        KeObat5.setBackground(new java.awt.Color(219, 249, 249));
        KeObat5.setForeground(new java.awt.Color(0, 153, 153));
        KeObat5.setText("Obat");
        KeObat5.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        KeObat5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                KeObat5ActionPerformed(evt);
            }
        });

        KeArtikel5.setBackground(new java.awt.Color(219, 249, 249));
        KeArtikel5.setForeground(new java.awt.Color(0, 153, 153));
        KeArtikel5.setText("Artikel");
        KeArtikel5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                KeArtikel5ActionPerformed(evt);
            }
        });

        KePenyakit5.setBackground(new java.awt.Color(219, 249, 249));
        KePenyakit5.setForeground(new java.awt.Color(0, 153, 153));
        KePenyakit5.setText("Penyakit");
        KePenyakit5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                KePenyakit5ActionPerformed(evt);
            }
        });

        KeMain5.setBackground(new java.awt.Color(0, 51, 51));
        KeMain5.setForeground(new java.awt.Color(255, 255, 255));
        KeMain5.setText("Kembali");
        KeMain5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                KeMain5ActionPerformed(evt);
            }
        });

        keAnjuranObat4.setBackground(new java.awt.Color(219, 249, 249));
        keAnjuranObat4.setForeground(new java.awt.Color(0, 153, 153));
        keAnjuranObat4.setText("Anjuran Obat");
        keAnjuranObat4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                keAnjuranObat4ActionPerformed(evt);
            }
        });

        KeProfil1.setBackground(new java.awt.Color(219, 249, 249));
        KeProfil1.setForeground(new java.awt.Color(0, 153, 153));
        KeProfil1.setText("Profil");
        KeProfil1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                KeProfil1MouseClicked(evt);
            }
        });
        KeProfil1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                KeProfil1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(KeProfil1, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(KeArtikel5, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(KePenyakit5, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(KeObat5, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(keAnjuranObat4, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 81, Short.MAX_VALUE)
                .addComponent(KeMain5, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(KeArtikel5, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(KePenyakit5, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(KeObat5, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(KeMain5, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(keAnjuranObat4, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(KeProfil1, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(14, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel7);
        jPanel7.setBounds(90, 20, 610, 60);

        PencarianArtikel.setBackground(new java.awt.Color(255, 255, 255));
        PencarianArtikel.setForeground(new java.awt.Color(0, 0, 0));
        PencarianArtikel.setText("Cari Artikel");
        PencarianArtikel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PencarianArtikelActionPerformed(evt);
            }
        });
        getContentPane().add(PencarianArtikel);
        PencarianArtikel.setBounds(220, 100, 320, 30);

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/FrameArtikel.png"))); // NOI18N
        jLabel3.setText("jLabel3");
        getContentPane().add(jLabel3);
        jLabel3.setBounds(1, -2, 710, 470);

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents
    private void showDetailDialog(Artikel a) {
        String penyakit = a.getPenyakit()==null ? "-" : nz(a.getPenyakit().getNamaPenyakit());
        String html = """
            <html><body style='width:520px'>
            <h3 style='margin:0'>%s</h3><hr>
            <b>Penyakit:</b> %s<br>
            <b>Status:</b> %s<br><br>
            <b>Konten:</b><br>%s
            </body></html>
        """.formatted(escape(nz(a.getJudul())), escape(penyakit),
                       escape(nz(a.getStatusReview())), escape(nz(a.getKonten())));
        JOptionPane.showMessageDialog(this, html, "Detail Artikel", JOptionPane.INFORMATION_MESSAGE);
    }
    
    private static String nz(String s){ return s == null ? "" : s; }
    private static String ringkas(String s, int max){
        String t = s.replace('\n',' ').trim();
        return t.length() <= max ? t : t.substring(0, max-3) + "...";
    }
    private static String escape(String s){
        return s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;");
    }
    
    private void formComponentAdded(java.awt.event.ContainerEvent evt) {//GEN-FIRST:event_formComponentAdded
        // TODO add your handling code here:
    }//GEN-LAST:event_formComponentAdded

    private void KeObat5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_KeObat5ActionPerformed
        DashboardObat dashboardObat = new DashboardObat();
        dashboardObat.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_KeObat5ActionPerformed

    private void KeArtikel5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_KeArtikel5ActionPerformed
        JOptionPane.showMessageDialog(this, "Kamu sudah di halaman profil.");
    }//GEN-LAST:event_KeArtikel5ActionPerformed

    private void KePenyakit5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_KePenyakit5ActionPerformed
        DashboardPenyakit dashboardpenyakit = new DashboardPenyakit();
        dashboardpenyakit.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_KePenyakit5ActionPerformed

    private void KeMain5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_KeMain5ActionPerformed
        DashboardAwal main = new DashboardAwal();
        main.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_KeMain5ActionPerformed

    private void keAnjuranObat4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_keAnjuranObat4ActionPerformed
        DashboardAnjuranObat dashboardanjuran = new DashboardAnjuranObat();
        dashboardanjuran.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_keAnjuranObat4ActionPerformed

    private void KeProfil1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_KeProfil1MouseClicked
        DashboardObat dashboardObat = new DashboardObat();
        dashboardObat.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_KeProfil1MouseClicked

    private void KeProfil1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_KeProfil1ActionPerformed
        new FormProfil(util.Sesi.getPengguna()).setVisible(true);
        this.dispose();   
    }//GEN-LAST:event_KeProfil1ActionPerformed

    private void PencarianArtikelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PencarianArtikelActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_PencarianArtikelActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
//            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new DashboardArtikel().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton KeArtikel5;
    private javax.swing.JButton KeMain5;
    private javax.swing.JButton KeObat5;
    private javax.swing.JButton KePenyakit5;
    private javax.swing.JButton KeProfil1;
    private javax.swing.JTextField PencarianArtikel;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JButton keAnjuranObat4;
    private javax.swing.JTable tblArtikel;
    // End of variables declaration//GEN-END:variables

}


package userpanel;


import javax.swing.JComponent;

import model.User;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import util.Sesi;




public class FormProfil extends javax.swing.JFrame {

    private User currentUser;

    public FormProfil(User user) {
        initComponents();
        setTitle("Profil");
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        this.currentUser = (user != null) ? user : Sesi.getPengguna();
        guardLoginOrClose();
        makeReadOnly();
        tampilkanData();
        jPanel7.setOpaque(false);
        jPanel7.setBackground(new java.awt.Color(0,0,0,0));
    }

    public FormProfil() {
        this(Sesi.getPengguna());
    }
    
    void refreshFromSessionAndShow() {
        this.currentUser = Sesi.getPengguna(); 
        tampilkanData();
        setVisible(true);
        toFront();
    }
    private void guardLoginOrClose() {
        if (currentUser == null) {
            JOptionPane.showMessageDialog(this,
                    "Data pengguna tidak ditemukan! Silakan login terlebih dahulu.",
                    "Peringatan", JOptionPane.WARNING_MESSAGE);
            dispose();
        }
    }
    private void makeReadOnly() {
        var fields = new JComponent[]{ TampilkanNama, TampilkanAlamat, TampilkanEmail, TampilkanTanggal, TampilkanPassword };
        for (JComponent c : fields) {
            if (c instanceof JTextField tf) {
                tf.setEditable(false); 
                tf.setFocusable(false); 
            }
            if (c instanceof JPasswordField pf) {
                pf.setEditable(false); 
                pf.setFocusable(false); 
                pf.setText("••••••••"); 
            }
        }
    }   
    
    private void tampilkanData() {
        if (currentUser == null) return;
        TampilkanNama.setText(nv(currentUser.getNama()));
        TampilkanEmail.setText(nv(currentUser.getEmail()));
        TampilkanAlamat.setText(nv(currentUser.getAlamat()));
        TampilkanTanggal.setText(currentUser.getTanggalRegistrasi() == null
                ? "-" : currentUser.getTanggalRegistrasi().toString());
    }

    private static String nv(String s){ return s == null ? "" : s; }
    

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        TampilkanNama = new javax.swing.JTextField();
        TampilkanAlamat = new javax.swing.JTextField();
        TampilkanEmail = new javax.swing.JTextField();
        TampilkanTanggal = new javax.swing.JTextField();
        EditProfil = new javax.swing.JButton();
        TampilkanPassword = new javax.swing.JPasswordField();
        jPanel7 = new javax.swing.JPanel();
        KeObat5 = new javax.swing.JButton();
        KeArtikel5 = new javax.swing.JButton();
        KePenyakit5 = new javax.swing.JButton();
        KeMain5 = new javax.swing.JButton();
        keAnjuranObat4 = new javax.swing.JButton();
        KeProfil = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        addContainerListener(new java.awt.event.ContainerAdapter() {
            public void componentAdded(java.awt.event.ContainerEvent evt) {
                formComponentAdded(evt);
            }
        });
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        TampilkanNama.setBackground(new java.awt.Color(255, 255, 255));
        TampilkanNama.setForeground(new java.awt.Color(0, 0, 0));
        TampilkanNama.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TampilkanNamaActionPerformed(evt);
            }
        });
        getContentPane().add(TampilkanNama, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 122, 190, 30));

        TampilkanAlamat.setBackground(new java.awt.Color(255, 255, 255));
        TampilkanAlamat.setForeground(new java.awt.Color(0, 0, 0));
        TampilkanAlamat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TampilkanAlamatActionPerformed(evt);
            }
        });
        getContentPane().add(TampilkanAlamat, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 172, 190, 30));

        TampilkanEmail.setBackground(new java.awt.Color(255, 255, 255));
        TampilkanEmail.setForeground(new java.awt.Color(0, 0, 0));
        TampilkanEmail.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TampilkanEmailActionPerformed(evt);
            }
        });
        getContentPane().add(TampilkanEmail, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 232, 190, 30));

        TampilkanTanggal.setBackground(new java.awt.Color(255, 255, 255));
        TampilkanTanggal.setForeground(new java.awt.Color(0, 0, 0));
        TampilkanTanggal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TampilkanTanggalActionPerformed(evt);
            }
        });
        getContentPane().add(TampilkanTanggal, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 340, 190, 30));

        EditProfil.setBackground(new java.awt.Color(0, 153, 153));
        EditProfil.setForeground(new java.awt.Color(255, 255, 255));
        EditProfil.setText("Edit");
        EditProfil.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EditProfilActionPerformed(evt);
            }
        });
        getContentPane().add(EditProfil, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 380, 75, 30));

        TampilkanPassword.setBackground(new java.awt.Color(255, 255, 255));
        TampilkanPassword.setForeground(new java.awt.Color(0, 0, 0));
        TampilkanPassword.setText("jPasswordField1");
        getContentPane().add(TampilkanPassword, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 290, 190, 30));

        jPanel7.setBackground(new java.awt.Color(230, 247, 249));

        KeObat5.setBackground(new java.awt.Color(219, 249, 249));
        KeObat5.setForeground(new java.awt.Color(0, 153, 153));
        KeObat5.setText("Obat");
        KeObat5.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        KeObat5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                KeObat5ActionPerformed(evt);
            }
        });

        KeArtikel5.setBackground(new java.awt.Color(219, 249, 249));
        KeArtikel5.setForeground(new java.awt.Color(0, 153, 153));
        KeArtikel5.setText("Artikel");
        KeArtikel5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                KeArtikel5ActionPerformed(evt);
            }
        });

        KePenyakit5.setBackground(new java.awt.Color(219, 249, 249));
        KePenyakit5.setForeground(new java.awt.Color(0, 153, 153));
        KePenyakit5.setText("Penyakit");
        KePenyakit5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                KePenyakit5ActionPerformed(evt);
            }
        });

        KeMain5.setBackground(new java.awt.Color(0, 51, 51));
        KeMain5.setForeground(new java.awt.Color(255, 255, 255));
        KeMain5.setText("Kembali");
        KeMain5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                KeMain5ActionPerformed(evt);
            }
        });

        keAnjuranObat4.setBackground(new java.awt.Color(219, 249, 249));
        keAnjuranObat4.setForeground(new java.awt.Color(0, 153, 153));
        keAnjuranObat4.setText("Anjuran Obat");
        keAnjuranObat4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                keAnjuranObat4ActionPerformed(evt);
            }
        });

        KeProfil.setBackground(new java.awt.Color(219, 249, 249));
        KeProfil.setForeground(new java.awt.Color(0, 153, 153));
        KeProfil.setText("Profil");
        KeProfil.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                KeProfilMouseClicked(evt);
            }
        });
        KeProfil.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                KeProfilActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(KeProfil, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(KeArtikel5, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(KePenyakit5, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(KeObat5, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(keAnjuranObat4, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 81, Short.MAX_VALUE)
                .addComponent(KeMain5, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(KeArtikel5, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(KePenyakit5, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(KeObat5, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(KeMain5, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(keAnjuranObat4, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(KeProfil, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(14, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 20, 610, 60));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/FrameProfile.png"))); // NOI18N
        jLabel2.setText("jLabel2");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 710, -1));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

  
    private void formComponentAdded(java.awt.event.ContainerEvent evt) {//GEN-FIRST:event_formComponentAdded
        // TODO add your handling code here:
    }//GEN-LAST:event_formComponentAdded

    private void KeProfilActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_KeProfilActionPerformed
        JOptionPane.showMessageDialog(this, "Kamu sudah di halaman profil.");
    }//GEN-LAST:event_KeProfilActionPerformed

    private void KeProfilMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_KeProfilMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_KeProfilMouseClicked

    private void TampilkanNamaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TampilkanNamaActionPerformed
        JOptionPane.showMessageDialog(this, "Nama tidak bisa diubah di halaman ini.");
    }//GEN-LAST:event_TampilkanNamaActionPerformed

    private void EditProfilActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EditProfilActionPerformed
    if (currentUser == null) return;

    DashboardEditProfil edit = new DashboardEditProfil(this, currentUser);
    setVisible(false);

    edit.addWindowListener(new java.awt.event.WindowAdapter() {
        @Override public void windowClosed(java.awt.event.WindowEvent e) {
            refreshFromSessionAndShow();
        }
        @Override public void windowClosing(java.awt.event.WindowEvent e) {
        }
    });

    edit.setVisible(true);

    edit.setVisible(true);
    }//GEN-LAST:event_EditProfilActionPerformed

    private void TampilkanEmailActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TampilkanEmailActionPerformed
        JOptionPane.showMessageDialog(this, "Email hanya bisa diubah lewat halaman edit profil.");
    }//GEN-LAST:event_TampilkanEmailActionPerformed

    private void TampilkanAlamatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TampilkanAlamatActionPerformed
        JOptionPane.showMessageDialog(this, "Alamat ditampilkan sesuai data akun.");
    }//GEN-LAST:event_TampilkanAlamatActionPerformed

    private void TampilkanTanggalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TampilkanTanggalActionPerformed
        JOptionPane.showMessageDialog(this, "Tanggal lahir tidak dapat diubah di halaman profil.");
    }//GEN-LAST:event_TampilkanTanggalActionPerformed

    private void KeObat5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_KeObat5ActionPerformed
        DashboardObat dashboardObat = new DashboardObat();
        dashboardObat.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_KeObat5ActionPerformed

    private void KeArtikel5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_KeArtikel5ActionPerformed
        DashboardArtikel dashboardArtikel = new DashboardArtikel();
        dashboardArtikel.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_KeArtikel5ActionPerformed

    private void KePenyakit5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_KePenyakit5ActionPerformed
        DashboardPenyakit dashboardPenyakit = new DashboardPenyakit();
        dashboardPenyakit.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_KePenyakit5ActionPerformed

    private void KeMain5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_KeMain5ActionPerformed
        DashboardAwal main = new DashboardAwal();
        main.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_KeMain5ActionPerformed

    private void keAnjuranObat4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_keAnjuranObat4ActionPerformed
        DashboardAnjuranObat dashboardanjuran = new DashboardAnjuranObat();
        dashboardanjuran.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_keAnjuranObat4ActionPerformed

    /**
     * @param args the command line arguments
     */

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton EditProfil;
    private javax.swing.JButton KeArtikel5;
    private javax.swing.JButton KeMain5;
    private javax.swing.JButton KeObat5;
    private javax.swing.JButton KePenyakit5;
    private javax.swing.JButton KeProfil;
    private javax.swing.JTextField TampilkanAlamat;
    private javax.swing.JTextField TampilkanEmail;
    private javax.swing.JTextField TampilkanNama;
    private javax.swing.JPasswordField TampilkanPassword;
    private javax.swing.JTextField TampilkanTanggal;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JButton keAnjuranObat4;
    // End of variables declaration//GEN-END:variables
}

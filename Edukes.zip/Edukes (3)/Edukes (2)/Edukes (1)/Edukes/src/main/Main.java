
package main;

import controller.AuthController;
import adminpanel.A_Main;
import userpanel.DashboardAwal;

import userpanel.Registrasi;
import model.Admin;
import model.Akun;
import model.User;
import util.Sesi;

public class Main extends javax.swing.JFrame {
    private static final java.util.logging.Logger logger = 
            java.util.logging.Logger.getLogger(DashboardAwal.class.getName());

    private final AuthController auth = new AuthController();

    public Main() {
        initComponents();
        setLocationRelativeTo(null); 
        setTitle("Login - Edukes");
    }
    
    private void onLogin() {
        try {
            String email = EmailLogin.getText().trim();
            String pass  = new String(PasswordLogin.getPassword());
            if (email.isEmpty() || pass.isEmpty())
                throw new IllegalArgumentException("Email dan password wajib diisi");

            Akun akun = auth.login(email, pass);           
            util.AppContext.setCurrentAkun(akun);          

            if (akun instanceof Admin a) {
                Sesi.setAdmin(a);                           
                new adminpanel.A_Main().setVisible(true);

            } else if (akun instanceof User u) {
                Sesi.setPengguna(u);                    
                new userpanel.DashboardAwal().setVisible(true);

            } 
            this.dispose();
        } catch (Exception ex) {
            logger.log(java.util.logging.Level.WARNING, "Login gagal", ex);
            javax.swing.JOptionPane.showMessageDialog(
                this, ex.getMessage(), "Login Gagal",
                javax.swing.JOptionPane.ERROR_MESSAGE
            );
        }
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        KeRegistrasi = new javax.swing.JButton();
        EmailLogin = new javax.swing.JTextField();
        PasswordLogin = new javax.swing.JPasswordField();
        TombolMasuk = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        KeRegistrasi.setBackground(new java.awt.Color(0, 153, 153));
        KeRegistrasi.setForeground(new java.awt.Color(255, 255, 255));
        KeRegistrasi.setText("Registrasi");
        KeRegistrasi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                KeRegistrasiActionPerformed(evt);
            }
        });
        getContentPane().add(KeRegistrasi, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 330, 100, 34));

        EmailLogin.setBackground(new java.awt.Color(255, 255, 255));
        EmailLogin.setForeground(new java.awt.Color(0, 0, 0));
        EmailLogin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EmailLoginActionPerformed(evt);
            }
        });
        getContentPane().add(EmailLogin, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 170, 210, 30));

        PasswordLogin.setBackground(new java.awt.Color(255, 255, 255));
        PasswordLogin.setForeground(new java.awt.Color(0, 0, 0));
        PasswordLogin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PasswordLoginActionPerformed(evt);
            }
        });
        getContentPane().add(PasswordLogin, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 240, 210, 30));

        TombolMasuk.setBackground(new java.awt.Color(0, 153, 153));
        TombolMasuk.setForeground(new java.awt.Color(255, 255, 255));
        TombolMasuk.setText("Masuk");
        TombolMasuk.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TombolMasukActionPerformed(evt);
            }
        });
        getContentPane().add(TombolMasuk, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 280, 75, 30));

        jLabel2.setBackground(new java.awt.Color(255, 255, 255));
        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/FrameAwal.png"))); // NOI18N
        jLabel2.setText("jLabel2");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 710, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void KeRegistrasiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_KeRegistrasiActionPerformed
        Registrasi registrasi = new Registrasi();
        registrasi.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_KeRegistrasiActionPerformed

    private void EmailLoginActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EmailLoginActionPerformed
        PasswordLogin.requestFocusInWindow();
    }//GEN-LAST:event_EmailLoginActionPerformed

    private void PasswordLoginActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PasswordLoginActionPerformed
        TombolMasukActionPerformed(evt);
    }//GEN-LAST:event_PasswordLoginActionPerformed

    private void TombolMasukActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TombolMasukActionPerformed
        onLogin();
    }//GEN-LAST:event_TombolMasukActionPerformed


    public static void main(String args[]) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }

        java.awt.EventQueue.invokeLater(() -> new Main().setVisible(true));
    }


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField EmailLogin;
    private javax.swing.JButton KeRegistrasi;
    private javax.swing.JPasswordField PasswordLogin;
    private javax.swing.JButton TombolMasuk;
    private javax.swing.JLabel jLabel2;
    // End of variables declaration//GEN-END:variables
}

package util;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

public final class JpaUtil {
    private static final EntityManagerFactory EMF;
    static {
        try {
            EMF = Persistence.createEntityManagerFactory("EdukesPU");
            Runtime.getRuntime().addShutdownHook(new Thread(EMF::close));
        } catch (Exception e) {
            // Cetak akar error supaya kelihatan penyebab sebenarnya
            Throwable t = e;
            while (t.getCause() != null) t = t.getCause();
            t.printStackTrace();   // lihat di Output/Console NetBeans
            throw new ExceptionInInitializerError(t);
        }
    }
    private JpaUtil() {}
    public static EntityManagerFactory getEmf() { return EMF; }
    public static EntityManager getEm() { return EMF.createEntityManager(); }
}
package util;

import model.User;
import model.Admin;

public final class Sesi {
    private static User pengguna;
    private static Admin admin;

    private Sesi() {};
    public static void setPengguna(User u) { 
        pengguna = u; 
        admin = null;
    }
    public static User getPengguna()       { return pengguna; }
    
     public static void setAdmin(Admin a)   { admin = a; pengguna = null; }
     public static Admin getAdmin()     { return admin; }
     
    public static boolean isAdmin()    { return admin != null; }
    public static boolean isUser()     { return pengguna != null; }
    public static boolean isLoggedIn() { return isAdmin() || isUser(); }
    
    public static Integer getAdminId() {
        return isAdmin() ? admin.getId() : null;
    }
    public static Integer requireAdminId() {
        if (!isAdmin()) throw new IllegalStateException("Admin belum login.");
        return admin.getId();
    }

    public static void clear() {
        admin = null; pengguna = null; 
    }

}
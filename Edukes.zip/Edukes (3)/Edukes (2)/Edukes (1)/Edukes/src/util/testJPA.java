package util;

import jakarta.persistence.*;

import model.Artikel;

public class testJPA {
//  public static void main(String[] args) {
//        try {
//            EntityManagerFactory emf = Persistence.createEntityManagerFactory("EdukesPU");
//            EntityManager em = emf.createEntityManager();
//            
//            System.out.println("Koneksi ke database BERHASIL!");
//
//            em.close();
//            emf.close();
//        } catch (Exception e) {
//            System.out.println("Koneksi GAGAL!");
//            e.printStackTrace();
//        }
//    }
}

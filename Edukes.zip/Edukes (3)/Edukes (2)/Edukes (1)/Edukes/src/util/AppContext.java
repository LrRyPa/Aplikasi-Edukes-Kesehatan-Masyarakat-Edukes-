package util;

import model.Akun;

public final class AppContext {
    private static Akun currentAkun;
    private AppContext(){}

    public static Akun getCurrentAkun(){
        return currentAkun; 
    }
    public static void setCurrentAkun(Akun a){ 
        currentAkun = a; 
    }
    public static boolean isLoggedIn(){
        return currentAkun != null; 
    }
    public static void logout(){
        currentAkun = null; 
    }
}

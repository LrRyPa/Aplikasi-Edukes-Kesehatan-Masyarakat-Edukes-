package controller;

import model.Akun;
import model.Admin;
import model.User;
import service.AkunService;
import service.AdminService;
import service.UserService;

public class AuthController {
    private final AkunService akunSvc = new AkunService();
    private final AdminService adminSvc = new AdminService();
    private final UserService userSvc = new UserService();

    /** Login → kembalikan instance konkret: Admin atau User (subtype Akun). */
    public Akun login(String email, String password) {
        Akun a = akunSvc.login(email, password); 
        Admin adm = adminSvc.byId(a.getId()); 
        if (adm != null) 
            return adm;
        User usr  = userSvc.byId(a.getId());  
        if (usr != null)  
            return usr;
        return a; // fallback kalau single-table inheritance
    }
    public User registerUser(String nama, String email, String password,
                             String alamat) {
        if (nama == null || nama.isBlank()) throw new IllegalArgumentException("Nama wajib");
        if (alamat == null || alamat.isBlank()) throw new IllegalArgumentException("Alamat wajib");
        if (email == null || email.isBlank()) throw new IllegalArgumentException("Email wajib");
        if (password == null || password.isBlank()) throw new IllegalArgumentException("Password wajib");

        if (akunSvc.emailSudahDipakai(email)) {
            throw new IllegalArgumentException("Email sudah terdaftar");
        }

        // delegasikan ke UserService agar persist subclass User (JOINED)
        return userSvc.register(
                nama, email, password,
                alamat
        );
    }
}

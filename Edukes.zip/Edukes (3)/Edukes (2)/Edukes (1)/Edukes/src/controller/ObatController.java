package controller;

import model.AnjuranObat;
import model.Obat;
import service.ObatService;

import java.math.BigDecimal;
import java.util.List;

public class ObatController {

    private final ObatService svc = new ObatService();

    public Obat create(String namaObat,
                       String deskripsi,
                       BigDecimal harga,
                       String golongan,
                       String indikasiUmum,
                       String efekSamping) {
        return svc.create(namaObat, deskripsi, harga, golongan, indikasiUmum, efekSamping);
    }

    public Obat create(String namaObat,
                       String deskripsi,
                       String hargaStr,
                       String golongan,
                       String indikasiUmum,
                       String efekSamping) {
        return create(namaObat, deskripsi, parseHarga(hargaStr), golongan, indikasiUmum, efekSamping);
    }

    public Obat detail(Integer id) {
        return svc.byId(id);
    }

    public List<Obat> listAll() {
        return svc.semua();
    }

    public List<Obat> searchNama(String keyword) {
        return svc.cariNama(keyword);
    }

    public List<Obat> listByGolongan(String golongan) {
        return svc.byGolongan(golongan);
    }

    public List<Obat> listByHarga(BigDecimal min, BigDecimal max) {
        return svc.byHargaBetween(min, max);
    }

    public List<Obat> listByHarga(String minStr, String maxStr) {
        return listByHarga(parseHarga(minStr), parseHarga(maxStr));
    }

    public List<AnjuranObat> anjuran(Integer idObat) {
        return svc.anjuranUntukObat(idObat);
    }

    public List<Obat> page(int offset, int limit) {
        return svc.page(offset, limit);
    }

    public List<Obat> latest(int max) {
        return svc.terbaru(max);
    }


    public Obat update(Integer idObat,
                       String namaBaru,
                       String deskripsiBaru,
                       BigDecimal hargaBaru,
                       String golonganBaru,
                       String indikasiBaru,
                       String efekSampingBaru) {
        return svc.updateData(idObat, namaBaru, deskripsiBaru, hargaBaru,
                              golonganBaru, indikasiBaru, efekSampingBaru);
    }

    public Obat update(Integer idObat,
                       String namaBaru,
                       String deskripsiBaru,
                       String hargaBaruStr,
                       String golonganBaru,
                       String indikasiBaru,
                       String efekSampingBaru) {
        BigDecimal hargaBaru = (hargaBaruStr == null || hargaBaruStr.isBlank())
                ? null : parseHarga(hargaBaruStr);
        return update(idObat, namaBaru, deskripsiBaru, hargaBaru,
                      golonganBaru, indikasiBaru, efekSampingBaru);
    }

    public boolean updateHarga(Integer idObat, BigDecimal hargaBaru) {
        return svc.updateHarga(idObat, hargaBaru);
    }

    public boolean updateHarga(Integer idObat, String hargaBaruStr) {
        return updateHarga(idObat, parseHarga(hargaBaruStr));
    }

    public void delete(Integer id) {
        svc.hapus(id);
    }
    
    public void deleteForce(Integer id) {
        svc.hapusPaksa(id);
    }

    private BigDecimal parseHarga(String s) {
        if (s == null || s.isBlank()) {
            throw new IllegalArgumentException("Harga wajib diisi");
        }
        try {
            String norm = s.trim().replace(",", "");
            return new BigDecimal(norm);
        } catch (NumberFormatException ex) {
            throw new IllegalArgumentException("Format harga tidak valid: " + s);
        }
    }
}

package controller;

import model.Kategori;
import model.Penyakit;
import service.KategoriService;
import service.PenyakitService;

import java.util.List;

public class PenyakitController {

    private final PenyakitService svc = new PenyakitService();
    private final KategoriService katSvc = new KategoriService(); 

    public Penyakit create(Integer idKategori,
                           String namaPenyakit,
                           String pengertian,
                           String tandaGejala,
                           String faktorRisiko,
                           String pengobatanUmum,
                           String pencegahan) {
        return svc.create(idKategori, namaPenyakit, pengertian, tandaGejala,
                          faktorRisiko, pengobatanUmum, pencegahan);
    }

    public Penyakit detail(Integer id) {
        return svc.byId(id);
    }

    public List<Penyakit> listAll() {
        return svc.semua();
    }

    public List<Penyakit> listByKategori(Integer idKategori) {
        return svc.byKategori(idKategori);
    }

    public List<Penyakit> searchNama(String keyword) {
        return svc.cariNama(keyword);
    }

    public List<Penyakit> page(int offset, int limit) {
        return svc.page(offset, limit);
    }

    public List<Penyakit> latest(int max) {
        return svc.terbaru(max);
    }

    public Penyakit update(Integer idPenyakit,
                           Integer idKategoriBaru,
                           String namaBaru,
                           String pengertian,
                           String tandaGejala,
                           String faktorRisiko,
                           String pengobatanUmum,
                           String pencegahan) {
        return svc.updateData(idPenyakit, idKategoriBaru, namaBaru, pengertian,
                              tandaGejala, faktorRisiko, pengobatanUmum, pencegahan);
    }

    public void delete(Integer id) {
        svc.hapus(id);
    }
    
   public void deleteForce(Integer id) {
        svc.hapusPaksa(id);
    }

    public List<Kategori> refKategori() {
        return katSvc.semua();
    }
}

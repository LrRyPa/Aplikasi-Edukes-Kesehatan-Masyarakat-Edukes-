package controller;

import model.AnjuranObat;
import service.AnjuranObatService;

import java.util.Comparator;
import java.util.List;

public class AnjuranObatController {
    private final AnjuranObatService svc = new AnjuranObatService();

    
    public List<AnjuranObat> listAll() {
        var list = svc.semua();
        list.sort(Comparator
                .comparing(AnjuranObatController::safeNamaPenyakit, String.CASE_INSENSITIVE_ORDER)
                .thenComparing(AnjuranObatController::safeNamaObat, String.CASE_INSENSITIVE_ORDER)
                .thenComparing(AnjuranObat::getId, Comparator.nullsLast(Integer::compareTo)));
        return list;
    }
    
    public AnjuranObat detail(Integer id) {
        if (id == null) throw new IllegalArgumentException("ID wajib diisi.");
        var a = svc.byId(id);
        if (a == null) throw new IllegalArgumentException("Anjuran tidak ditemukan (ID: " + id + ").");
        return a;
    }
    public AnjuranObat create(Integer idPenyakit,
                              Integer idObat,
                              String dosisAnjuran,
                              String aturanPakai) {
        return svc.create(idPenyakit, idObat, dosisAnjuran, aturanPakai);
    }
    
    public AnjuranObat update(Integer idAnjuran,
                              Integer idPenyakitBaru,
                              Integer idObatBaru,
                              String dosisBaru,
                              String aturanBaru) {
        return svc.updateData(idAnjuran, idPenyakitBaru, idObatBaru, dosisBaru, aturanBaru);
    }
    
    public AnjuranObat saveOrUpdate(Integer id,
                                    Integer idPenyakit,
                                    Integer idObat,
                                    String dosisAnjuran,
                                    String aturanPakai) {
        if (id == null) {
            return svc.create(idPenyakit, idObat, dosisAnjuran, aturanPakai);
        } else {
            // updateData di service bersifat “opsional per-field”; kita kirim saja nilai form.
            return svc.updateData(id, idPenyakit, idObat, dosisAnjuran, aturanPakai);
        }
    }

    public void delete(Integer id) {
        if (id == null) throw new IllegalArgumentException("ID wajib diisi.");
        svc.hapus(id);
    }
    
    public void deleteForce(Integer id) {
        delete(id);
    }
    
        public List<AnjuranObat> search(String keyword) {
        if (keyword == null || keyword.isBlank()) return listAll();
        return svc.cariTeks(keyword);
    }

    public List<AnjuranObat> page(int offset, int limit) {
        return svc.page(offset, limit);
    }

    public long countAll() {
        return svc.hitungSemua();
    }

    private static String nv(String s) { return s == null ? "" : s; }

    private static String safeNamaPenyakit(AnjuranObat a) {
        return (a == null || a.getPenyakit() == null) ? "" : nv(a.getPenyakit().getNamaPenyakit());
    }

    private static String safeNamaObat(AnjuranObat a) {
        return (a == null || a.getObat() == null) ? "" : nv(a.getObat().getNamaObat());
    }
    
    public List<AnjuranObat> byPenyakit(Integer idPenyakit) {
        return svc.byPenyakit(idPenyakit);
    }

    public List<AnjuranObat> byObat(Integer idObat) {
        return svc.byObat(idObat);
    }

    public AnjuranObat byPenyakitDanObat(Integer idPenyakit, Integer idObat) {
        return svc.byPenyakitDanObat(idPenyakit, idObat);
    }
}
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    


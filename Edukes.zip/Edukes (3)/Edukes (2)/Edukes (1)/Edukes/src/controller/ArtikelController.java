package controller;

import model.Admin;
import model.Artikel;
import model.Penyakit;
import service.AdminService;
import service.ArtikelService;
import service.PenyakitService;
import java.util.Set;

import java.util.List;

public class ArtikelController {

    private final ArtikelService artikelSvc   = new ArtikelService();
    private final AdminService adminSvc       = new AdminService();
    private final PenyakitService penyakitSvc = new PenyakitService();
    private static final Set<String> ALLOWED_STATUS =
            Set.of("DRAFT", "PUBLISHED", "REVIEW");

    private static String nv(String s) { return s == null ? "" : s; }
        
    private static String normalizeStatus(String s){
        if (s == null) return "DRAFT";
        s = s.trim();
        // dari UI (Indonesia) → kode DB
        if (s.equalsIgnoreCase("Draft"))  return "DRAFT";
        if (s.equalsIgnoreCase("Tinjau")) return "REVIEW";
        if (s.equalsIgnoreCase("Tayang")) return "PUBLISHED";
        // kalau sudah pakai kode
        String up = s.toUpperCase();
        return ALLOWED_STATUS.contains(up) ? up : "DRAFT";
    }
    

    private static void require(boolean expr, String msg) {
        if (!expr) throw new IllegalArgumentException(msg);
    }
 

    public Artikel create(Integer adminId, Integer penyakitId,
                          String judul, String konten, String status) {

        String j = nv(judul);
        String k = nv(konten);
        require(!j.isEmpty(), "Judul wajib diisi");
        require(!k.isEmpty(), "Konten wajib diisi");

        Admin admin = null;
        if (adminId != null) {
            admin = adminSvc.byId(adminId);
            require(admin != null, "Admin tidak ditemukan"); 
        }

        Penyakit p = null;
        if (penyakitId != null) {
            p = penyakitSvc.byId(penyakitId);
            require(p != null, "Penyakit tidak ditemukan");
        }

        Artikel a = new Artikel();
        a.setAdmin(admin);         
        a.setPenyakit(p);          
        a.setJudul(j);
        a.setKonten(k);
        a.setStatusReview(normalizeStatus(status));
        return artikelSvc.simpan(a);
    }

    public Artikel create(String judul, String konten, String status) {
        return create(null, null, judul, konten, status);
    }

    public Artikel detail(Integer idArtikel) {
        return artikelSvc.byId(idArtikel);
    }

    public List<Artikel> listAll() {
        return artikelSvc.semua();
    }

    public List<Artikel> listByAdmin(Integer adminId) {
        return artikelSvc.byAdmin(adminId);
    }

    public List<Artikel> listByPenyakit(Integer penyakitId) {
        return artikelSvc.byPenyakit(penyakitId);
    }

    public List<Artikel> searchJudul(String keyword) {
        return artikelSvc.cariJudul(keyword);
    }

    public List<Artikel> latest(int max) {
        return artikelSvc.terbaru(max);
    }

    public List<Artikel> page(int offset, int limit) {
        return artikelSvc.page(offset, limit);
    }


    /** Ubah judul & konten artikel. */
    public boolean updateKonten(Integer idArtikel, String judulBaru, String kontenBaru) {
        String j = nv(judulBaru);
        String k = nv(kontenBaru);
        require(!j.isEmpty(), "Judul wajib diisi");
        require(!k.isEmpty(), "Konten wajib diisi");
        return artikelSvc.updateKonten(idArtikel, j, k);
    }

    /** Ubah status review artikel (mis. DRAFT/REVIEW/PUBLISHED). */
    public boolean updateStatus(Integer idArtikel, String statusBaru) {
        return artikelSvc.updateStatus(idArtikel, normalizeStatus(statusBaru));
    }



    // UI -> DB
    private String toDbStatus(String ui){
        if (ui == null) return "DRAFT";
        return switch (ui.trim().toLowerCase()) {
            case "draft"  -> "DRAFT";
            case "tinjau" -> "REVIEW";
            case "tayang" -> "PUBLISHED";
            default -> ui.toUpperCase();
        };
    }

    // DB -> UI (untuk load)
    private String toUiStatus(String db){
        if (db == null) return "Draft";
        return switch (db.trim().toUpperCase()) {
            case "DRAFT"     -> "Draft";
            case "REVIEW"    -> "Tinjau";
            case "PUBLISHED" -> "Tayang";
            default -> db;
        };
    }
    
    public Artikel update(Integer idArtikel, String judulBaru, String kontenBaru, String statusBaru) {
        String j = nv(judulBaru).trim();
        String k = nv(kontenBaru).trim();
        require(!j.isEmpty(), "Judul wajib diisi");
        require(!k.isEmpty(), "Konten wajib diisi");
        String s = normalizeStatus(statusBaru);

        return updateFull(idArtikel, null, null, j, k, s);
    }
    
    public Artikel updateFull(Integer idArtikel,
                              Integer adminIdBaru,    
                              Integer penyakitIdBaru, 
                              String judulBaru,      
                              String kontenBaru,     
                              String statusBaru) {    
        Artikel a = artikelSvc.byId(idArtikel);
        if (a == null) throw new IllegalArgumentException("Artikel tidak ditemukan");

        // Relasi (opsional)
        if (adminIdBaru != null) {
            Admin adm = adminSvc.byId(adminIdBaru);
            require(adm != null, "Admin tidak ditemukan");
            a.setAdmin(adm);
        }
        if (penyakitIdBaru != null) {
            Penyakit p = penyakitSvc.byId(penyakitIdBaru);
            require(p != null, "Penyakit tidak ditemukan");
            a.setPenyakit(p);
        }

        // Konten (opsional)
        if (judulBaru != null && !nv(judulBaru).isEmpty()) a.setJudul(nv(judulBaru));
        if (kontenBaru != null && !nv(kontenBaru).isEmpty()) a.setKonten(nv(kontenBaru));

        // Status (opsional)
        if (statusBaru != null && !nv(statusBaru).isEmpty()) {
            a.setStatusReview(normalizeStatus(statusBaru));
        }

        return artikelSvc.simpan(a);
    }


    public void delete(Integer idArtikel) {
        artikelSvc.hapus(idArtikel);
    }
    public void deleteForce(Integer idArtikel) {
        artikelSvc.hapusPaksa(idArtikel);        
    }


    /** Data Admin untuk mengisi ComboBox di Form Artikel. */
    public List<Admin> refAdmins() {
        return adminSvc.semua();
    }

    /** Data Penyakit untuk mengisi ComboBox di Form Artikel. */
    public List<Penyakit> refPenyakit() {
        return penyakitSvc.semua();
    }
}

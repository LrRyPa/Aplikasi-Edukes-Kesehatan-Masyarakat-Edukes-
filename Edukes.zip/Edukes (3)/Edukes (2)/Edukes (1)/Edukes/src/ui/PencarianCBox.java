package ui;

import javax.swing.*;


public class PencarianCBox {
  private static final String PROP_ATTACHED = "searchable.attached";
  private PencarianCBox(){}

  public static <T> void attach(JComboBox<T> combo){
    if (Boolean.TRUE.equals(combo.getClientProperty(PROP_ATTACHED))) return;
    combo.putClientProperty(PROP_ATTACHED, Boolean.TRUE);
    combo.setEditable(true);


    final java.util.List<T> master = new java.util.ArrayList<>();
    for (int i=0; i<combo.getItemCount(); i++) master.add(combo.getItemAt(i));

    final JTextField editor = (JTextField) combo.getEditor().getEditorComponent();
    final javax.swing.Timer debounce = new javax.swing.Timer(120, null);
    debounce.setRepeats(false);

    final boolean[] updating = { false };
    final boolean[] justSelected = { false };

    Runnable runFilter = () -> {
      if (updating[0] || justSelected[0]) return;  
      updating[0] = true;

      String q = editor.getText();
      String low = q == null ? "" : q.toLowerCase(java.util.Locale.ROOT).trim();

      DefaultComboBoxModel<T> filtered = new DefaultComboBoxModel<>();
      if (low.isEmpty()) {
        master.forEach(filtered::addElement);
      } else {
        for (T it : master) {
          String s = String.valueOf(it);
          if (s != null && s.toLowerCase(java.util.Locale.ROOT).contains(low)) filtered.addElement(it);
        }
      }

      int caret = editor.getCaretPosition();
      combo.setModel(filtered);
      editor.setText(q);
      if (caret <= editor.getText().length()) editor.setCaretPosition(caret);

 
      if (editor.hasFocus() && filtered.getSize() > 0) combo.setPopupVisible(true);

      updating[0] = false;
    };

    editor.getDocument().addDocumentListener(new javax.swing.event.DocumentListener() {
      @Override public void insertUpdate(javax.swing.event.DocumentEvent e){ debounce.restart(); }
      @Override public void removeUpdate(javax.swing.event.DocumentEvent e){ debounce.restart(); }
      @Override public void changedUpdate(javax.swing.event.DocumentEvent e){ debounce.restart(); }
    });
    debounce.addActionListener(e -> javax.swing.SwingUtilities.invokeLater(runFilter));

    // ENTER -> commit dan tutup popup
    editor.addKeyListener(new java.awt.event.KeyAdapter() {
      @Override public void keyPressed(java.awt.event.KeyEvent e) {
        if (e.getKeyCode() == java.awt.event.KeyEvent.VK_ENTER) {
          if (combo.getSelectedItem() == null && combo.getItemCount() > 0) combo.setSelectedIndex(0);
          justSelected[0] = true;
          combo.setPopupVisible(false);
          // clear cooldown setelah 150ms
          new javax.swing.Timer(150, a -> { justSelected[0] = false; ((javax.swing.Timer)a.getSource()).stop();}).start();
        }
      }
    });


    combo.addActionListener(e -> {
      if (updating[0]) return;
      if (combo.isPopupVisible()) {
        justSelected[0] = true;
        combo.setPopupVisible(false);
        editor.setText(String.valueOf(combo.getSelectedItem()));
        editor.selectAll();
        new javax.swing.Timer(150, a -> { justSelected[0] = false; ((javax.swing.Timer)a.getSource()).stop();}).start();
      }
    });

    editor.addFocusListener(new java.awt.event.FocusAdapter() {
      @Override public void focusLost(java.awt.event.FocusEvent e) { combo.setPopupVisible(false); }
    });
  }
}

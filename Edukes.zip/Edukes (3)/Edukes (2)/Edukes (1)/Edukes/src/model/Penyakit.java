package model;

import jakarta.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "penyakit")
public class Penyakit {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_penyakit")
    private Integer id;

    @ManyToOne(optional = false)
    @JoinColumn(name = "id_kategori", nullable = false)
    private Kategori kategori;

    @Column(name = "nama_penyakit", nullable = false, length = 120, unique = true)
    private String namaPenyakit;

    @Column(name = "pengertian", nullable = false, columnDefinition = "TEXT")
    private String pengertian;

    @Column(name = "tanda_gejala", nullable = false, columnDefinition = "TEXT")
    private String tandaGejala;

    @Column(name = "faktor_risiko", nullable = false, columnDefinition = "TEXT")
    private String faktorRisiko;

    @Column(name = "pengobatan_umum", nullable = false, columnDefinition = "TEXT")
    private String pengobatanUmum;

    @Column(name = "pencegahan", nullable = false, columnDefinition = "TEXT")
    private String pencegahan;

    @OneToMany(mappedBy = "penyakit")
    private List<Artikel> artikelList = new ArrayList<>();

    @OneToMany(mappedBy = "penyakit")
    private List<AnjuranObat> anjuranList = new ArrayList<>();

    public Penyakit() {}

    // Getter & Setter
    public Integer getId() {
        return id; 
    }
    public void setId(Integer id) {
        this.id = id; 
    }

    public Kategori getKategori() {
        return kategori; 
    }
    public void setKategori(Kategori kategori) {
        this.kategori = kategori; 
    }

    public String getNamaPenyakit() {
        return namaPenyakit; 
    }
    public void setNamaPenyakit(String namaPenyakit) {
        this.namaPenyakit = namaPenyakit; 
    }

    public String getPengertian() {
        return pengertian; 
    }
    public void setPengertian(String pengertian) { 
        this.pengertian = pengertian;
    }

    public String getTandaGejala() { 
        return tandaGejala; 
    }
    public void setTandaGejala(String tandaGejala) { 
        this.tandaGejala = tandaGejala; 
    }

    public String getFaktorRisiko() {
        return faktorRisiko; 
    }
    public void setFaktorRisiko(String faktorRisiko) {
        this.faktorRisiko = faktorRisiko; 
    }

    public String getPengobatanUmum() {
        return pengobatanUmum; 
    }
    public void setPengobatanUmum(String pengobatanUmum) {
        this.pengobatanUmum = pengobatanUmum; 
    }

    public String getPencegahan() {
        return pencegahan; 
    }
    public void setPencegahan(String pencegahan) { 
        this.pencegahan = pencegahan; 
    }

    public List<Artikel> getArtikelList() { 
        return artikelList;
    }
    public void setArtikelList(List<Artikel> artikelList) {
        this.artikelList = artikelList; 
    }

    public List<AnjuranObat> getAnjuranList() {
        return anjuranList; 
    }
    public void setAnjuranList(List<AnjuranObat> anjuranList) {
        this.anjuranList = anjuranList; 
    }

//    @Override
//    public String toString() {
//        return "Penyakit{id=" + id + ", nama='" + namaPenyakit + "'}";
//    }
//
//    @Override
//    public int hashCode() { return id != null ? id.hashCode() : 0; }
//
//    @Override
//    public boolean equals(Object obj) {
//        if (this == obj) return true;
//        if (!(obj instanceof Penyakit other)) return false;
//        return id != null && id.equals(other.id);
//    }
}

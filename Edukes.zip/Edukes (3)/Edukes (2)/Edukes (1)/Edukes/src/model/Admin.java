package model;

import jakarta.persistence.*;

@Entity
@Table(name = "admin")
@PrimaryKeyJoinColumn(name = "id_admin", referencedColumnName = "id_akun")
@DiscriminatorValue("Admin")
public class Admin extends Akun {

    @Column(name = "kontak", nullable = false, length = 13)
    private String kontak;

    public Admin() {}

    // Getter & Setter
    public String getKontak() {
        return kontak; 
    }
    public void setKontak(String kontak) {
        this.kontak = kontak; 
    }
}

package model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "artikel")
public class Artikel {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_artikel")
    private Integer id;

    // FK wajib ke admin
    @ManyToOne(optional = false)
    @JoinColumn(name = "id_admin", nullable = true)
    private Admin admin;

    // FK wajib ke penyakit
    @ManyToOne(optional = false)
    @JoinColumn(name = "id_penyakit", nullable = false)
    private Penyakit penyakit;

    @Column(name = "judul", nullable = false, length = 200)
    private String judul;

    // TEXT di MySQL — String panjang; boleh @Lob, tapi tidak wajib
    // @Lob
    @Column(name = "konten", nullable = false, columnDefinition = "TEXT")
    private String konten;

    @Column(name = "status_review", nullable = false, length = 20)
    private String statusReview;

    // Di DB ada DEFAULT CURRENT_TIMESTAMP.
    // insertable=false, updatable=false agar mengikuti default dari DB.
    @Column(name = "tanggal_upload", insertable = false, updatable = false)
    private LocalDateTime tanggalUpload;

    public Artikel() {}

    // Getter & Setter
    public Integer getId() {
        return id; 
    }
    public void setId(Integer id) {
        this.id = id; 
    }

    public Admin getAdmin() {
        return admin; 
    }
    public void setAdmin(Admin admin) {
        this.admin = admin; 
    }

    public Penyakit getPenyakit() {
        return penyakit; 
    }
    public void setPenyakit(Penyakit penyakit) {
        this.penyakit = penyakit; 
    }

    public String getJudul() {
        return judul; 
    }
    public void setJudul(String judul) {
        this.judul = judul; 
    }

    public String getKonten() { 
        return konten; 
    }
    public void setKonten(String konten) {
        this.konten = konten; 
    }

    public String getStatusReview() {
        return statusReview; 
    }
    public void setStatusReview(String statusReview) {
        this.statusReview = statusReview; 
    }

    public LocalDateTime getTanggalUpload() {
        return tanggalUpload; 
    }
    public void setTanggalUpload(LocalDateTime tanggalUpload) {
        this.tanggalUpload = tanggalUpload; 
    }
//    @Override
//    public String toString() {
//        return "Artikel{id=" + id + ", judul='" + judul + "'}";
//    }
//
//    @Override
//    public int hashCode() { return id != null ? id.hashCode() : 0; }
//
//    @Override
//    public boolean equals(Object obj) {
//        if (this == obj) return true;
//        if (!(obj instanceof Artikel other)) return false;
//        return id != null && id.equals(other.id);
//    }
}

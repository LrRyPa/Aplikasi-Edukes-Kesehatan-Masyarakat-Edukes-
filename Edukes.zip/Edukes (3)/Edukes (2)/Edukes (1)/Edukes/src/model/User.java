package model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "user")
@PrimaryKeyJoinColumn(name = "id_user", referencedColumnName = "id_akun")
@DiscriminatorValue("User")
public class User extends Akun {

    @Column(name = "alamat", length = 150)
    private String alamat;

    @Column(name = "tanggal_registrasi")
    private LocalDateTime tanggalRegistrasi;

    public User() {}

    // Getter & Setter
    public String getAlamat() {
        return alamat; 
    }
    public void setAlamat(String alamat) {
        this.alamat = alamat; 
    }

    public LocalDateTime getTanggalRegistrasi() {
        return tanggalRegistrasi; 
    }
    public void setTanggalRegistrasi(LocalDateTime tanggalRegistrasi) {
        this.tanggalRegistrasi = tanggalRegistrasi; 
    }
}

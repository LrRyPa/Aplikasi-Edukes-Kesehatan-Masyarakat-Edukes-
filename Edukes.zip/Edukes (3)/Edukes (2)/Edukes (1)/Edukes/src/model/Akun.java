package model;

import jakarta.persistence.*;

@Entity
@Table(
    name = "akun",
    uniqueConstraints = @UniqueConstraint(name = "uk_akun_email", columnNames = "email")
)
@Inheritance(strategy = InheritanceType.JOINED)
@DiscriminatorColumn(name = "peran", length = 10)
public class Akun {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_akun")
    private Integer id;

    @Column(name = "nama", nullable = false, length = 100)
    private String nama;

    @Column(name = "email", nullable = false, length = 100)
    private String email;

    @Column(name = "password", nullable = false, length = 20)
    private String password;

    public Akun() {}

    // Getter & Setter
    public Integer getId() {
        return id; 
    }
    public void setId(Integer id) {
        this.id = id; 
    }

    public String getNama() {
        return nama; 
    }
    public void setNama(String nama) {
        this.nama = nama; 
    }

    public String getEmail() {
        return email; 
    }
    public void setEmail(String email) {
        this.email = email; 
    }

    public String getPassword() {
        return password; 
    }
    public void setPassword(String password) {
        this.password = password; 
    }
}

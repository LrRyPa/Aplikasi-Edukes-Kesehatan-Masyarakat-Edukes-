package model;

import jakarta.persistence.*;

@Entity
@Table(name = "anjuran_obat")
public class AnjuranObat {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_anjuran_obat")
    private Integer id;

    @ManyToOne(optional = false)
    @JoinColumn(name = "id_penyakit", nullable = false)
    private Penyakit penyakit;

    @ManyToOne(optional = false)
    @JoinColumn(name = "id_obat", nullable = false)
    private Obat obat;

    @Column(name = "dosis_anjuran", nullable = false, columnDefinition = "TEXT")
    private String dosisAnjuran;

    @Column(name = "aturan_pakai", nullable = false, columnDefinition = "TEXT")
    private String aturanPakai;

    public AnjuranObat() {}

    // Getters & Setters
    public Integer getId() {
        return id; 
    }
    public void setId(Integer id) { 
        this.id = id; 
    }

    public Penyakit getPenyakit() { 
        return penyakit; 
    }
    public void setPenyakit(Penyakit penyakit) { 
        this.penyakit = penyakit; 
    }

    public Obat getObat() { 
        return obat; 
    }
    public void setObat(Obat obat) { 
        this.obat = obat; 
    }

    public String getDosisAnjuran() {
        return dosisAnjuran; 
    }
    public void setDosisAnjuran(String dosisAnjuran) { 
        this.dosisAnjuran = dosisAnjuran;
    }

    public String getAturanPakai() {
        return aturanPakai; 
    }
    public void setAturanPakai(String aturanPakai) { 
        this.aturanPakai = aturanPakai; 
    }

//    @Override
//    public String toString() {
//        return "AnjuranObat{id=" + id +
//               ", penyakit=" + (penyakit != null ? penyakit.getId() : null) +
//               ", obat=" + (obat != null ? obat.getId() : null) + "}";
//    }
//
//    @Override
//    public int hashCode() { return id != null ? id.hashCode() : 0; }

//    @Override
//    public boolean equals(Object obj) {
//        if (this == obj) return true;
//        if (!(obj instanceof AnjuranObat other)) return false;
//        return id != null && id.equals(other.id);
//    }
}

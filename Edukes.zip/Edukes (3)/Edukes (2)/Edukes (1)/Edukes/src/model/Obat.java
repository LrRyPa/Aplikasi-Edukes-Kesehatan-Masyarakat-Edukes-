package model;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "obat")
public class Obat {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_obat")
    private Integer id;

    @Column(name = "nama_obat", nullable = false, length = 120)
    private String namaObat;

    @Column(name = "deskripsi", nullable = false, columnDefinition = "TEXT")
    private String deskripsi;

    @Column(name = "harga", nullable = false, precision = 15, scale = 2)
    private BigDecimal harga;

    @Column(name = "golongan", nullable = false, length = 60)
    private String golongan;

    @Column(name = "indikasi_umum", nullable = false, columnDefinition = "TEXT")
    private String indikasiUmum;

    @Column(name = "efek_samping", nullable = false, columnDefinition = "TEXT")
    private String efekSamping;

    @OneToMany(mappedBy = "obat")
    private List<AnjuranObat> anjuranList = new ArrayList<>();

    public Obat() {}

    // Getters & Setters
    public Integer getId() {
        return id;
    } 
    public void setId(Integer id) { 
        this.id = id;
    } 

    public String getNamaObat() {
        return namaObat;
    } 
    public void setNamaObat(String namaObat) {
        this.namaObat = namaObat;
    } 

    public String getDeskripsi() {
        return deskripsi;
    } 
    public void setDeskripsi(String deskripsi) { 
        this.deskripsi = deskripsi;
    } 

    public BigDecimal getHarga() { 
        return harga;
    } 
    public void setHarga(BigDecimal harga) { 
        this.harga = harga;
    } 

    public String getGolongan() {
        return golongan;
    } 
    public void setGolongan(String golongan) { 
        this.golongan = golongan;
    } 

    public String getIndikasiUmum() { 
        return indikasiUmum;
    } 
    public void setIndikasiUmum(String indikasiUmum) { 
        this.indikasiUmum = indikasiUmum;
    } 

    public String getEfekSamping() { 
        return efekSamping;
    } 
    public void setEfekSamping(String efekSamping) { 
        this.efekSamping = efekSamping;
    } 

    public List<AnjuranObat> getAnjuranList() { 
        return anjuranList;
    } 
    public void setAnjuranList(List<AnjuranObat> anjuranList) {
        this.anjuranList = anjuranList;
    }
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (!(obj instanceof Obat other)) return false;
        return id != null && id.equals(other.id);
    }
}

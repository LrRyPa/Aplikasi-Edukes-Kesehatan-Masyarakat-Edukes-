package model;

import jakarta.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "kategori")
public class Kategori {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_kategori")
    private Integer id;

    @Column(name = "nama_kategori", nullable = false, length = 100)
    private String namaKategori;

    @Column(name = "deskripsi", nullable = false, columnDefinition = "TEXT")
    private String deskripsi;

    @OneToMany(mappedBy = "kategori")
    private List<Penyakit> penyakitList = new ArrayList<>();

    public Kategori() {}

    // Getter & Setter
    public Integer getId() {
        return id; 
    }
    public void setId(Integer id) {
        this.id = id; 
    }

    public String getNamaKategori() {
        return namaKategori; 
    }
    public void setNamaKategori(String namaKategori) {
        this.namaKategori = namaKategori; 
    }

    public String getDeskripsi() {
        return deskripsi; 
    }
    public void setDeskripsi(String deskripsi) {
        this.deskripsi = deskripsi; 
    }

    public List<Penyakit> getPenyakitList() { 
        return penyakitList; 
    }
    public void setPenyakitList(List<Penyakit> penyakitList) {
        this.penyakitList = penyakitList; 
    }

//    @Override
//    public String toString() {
//        return "Kategori{id=" + id + ", namaKategori='" + namaKategori + "'}";
//    }
//
//    @Override
//    public int hashCode() { return id != null ? id.hashCode() : 0; }
//
//    @Override
//    public boolean equals(Object obj) {
//        if (this == obj) return true;
//        if (!(obj instanceof Kategori other)) return false;
//        return id != null && id.equals(other.id);
//    }
}

package service;

import dao.AdminDao;
import model.Admin;
import model.Artikel;

import java.util.List;

public class AdminService {

    private final AdminDao dao = new AdminDao();

    public Admin register(String nama, String email, String password, String kontak) {
        requireNama(nama);
        requireEmail(email);
        requirePassword(password);
        requireKontak(kontak);

        if (dao.existsEmailOnAkun(email)) {
            throw new IllegalArgumentException("Email sudah terdaftar");
        }

        Admin a = new Admin();
        a.setNama(nama);
        a.setEmail(email);
        a.setPassword(password);
        a.setKontak(kontak);
        return dao.save(a);
    }

    public Admin updateProfil(Integer idAdmin, String namaBaru, String kontakBaru) {
        requireNotNull(idAdmin, "id admin wajib");
        requireNama(namaBaru);
        requireKontak(kontakBaru);

        Admin a = dao.find(idAdmin);
        if (a == null) throw new IllegalArgumentException("Admin tidak ditemukan");

        a.setNama(namaBaru);
        a.setKontak(kontakBaru);
        return dao.save(a);
    }

    public Admin login(String email, String password) {
        requireEmail(email);
        requirePassword(password);
        return dao.authenticate(email, password);
    }


    public Admin byId(Integer id) {
        requireNotNull(id, "id admin wajib");
        return dao.find(id);
    }

    public Admin byEmail(String email) {
        requireEmail(email);
        return dao.findByEmail(email);
    }

    public List<Admin> semua() {
        return dao.findAll();
    }

    public List<Admin> cariNama(String keyword) {
        return dao.searchByNama(keyword);
    }


    public List<Artikel> artikelAdmin(Integer idAdmin) {
        requireNotNull(idAdmin, "id admin wajib");
        return dao.listArtikelByAdmin(idAdmin);
    }

    public long hitungArtikelByStatus(Integer idAdmin, String status) {
        requireNotNull(idAdmin, "id admin wajib");
        requireStatus(status);
        return dao.countArtikelByStatus(idAdmin, status);
    }

    public void hapus(Integer idAdmin) {
        requireNotNull(idAdmin, "id admin wajib");
        dao.deleteById(idAdmin);
    }

    private void requireNotNull(Object o, String msg) {
        if (o == null) throw new IllegalArgumentException(msg);
    }

    private void requireNama(String nama) {
        if (nama == null || nama.isBlank())
            throw new IllegalArgumentException("Nama wajib");
        if (nama.length() > 100)
            throw new IllegalArgumentException("Nama terlalu panjang (maks 100)");
    }

    private void requireEmail(String email) {
        if (email == null || email.isBlank())
            throw new IllegalArgumentException("Email wajib");
        if (!email.contains("@") || email.length() > 100)
            throw new IllegalArgumentException("Format email tidak valid / terlalu panjang");
    }

    private void requirePassword(String pw) {
        if (pw == null || pw.isBlank())
            throw new IllegalArgumentException("Password wajib");
        if (pw.length() < 6 || pw.length() > 20)
            throw new IllegalArgumentException("Panjang password 6–20 karakter");
    }

    private void requirePasswordBaru(String pw) {
        requirePassword(pw);
    }

    private void requireKontak(String kontak) {
        if (kontak == null || kontak.isBlank())
            throw new IllegalArgumentException("Kontak wajib");
        if (kontak.length() > 13)
            throw new IllegalArgumentException("Kontak terlalu panjang (maks 13 digit)");
    }

    private void requireStatus(String status) {
        if (status == null || status.isBlank())
            throw new IllegalArgumentException("Status wajib");
        if (status.length() > 20)
            throw new IllegalArgumentException("Status terlalu panjang (maks 20)");
    }
}

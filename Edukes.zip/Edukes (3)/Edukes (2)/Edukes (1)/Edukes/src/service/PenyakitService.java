package service;

import dao.PenyakitDao;
import model.Kategori;
import model.Penyakit;

import java.util.List;

public class PenyakitService {

    private final PenyakitDao dao = new PenyakitDao();
    private final KategoriService kategoriSvc = new KategoriService(); 

    public Penyakit simpan(Penyakit p) {
        requireNotNull(p, "Penyakit tidak boleh null");
        requireKategori(p.getKategori());
        requireNama(p.getNamaPenyakit());
        requireText("Pengertian", p.getPengertian());
        requireText("Tanda/gejala", p.getTandaGejala());
        requireText("Faktor risiko", p.getFaktorRisiko());
        requireText("Pengobatan umum", p.getPengobatanUmum());
        requireText("Pencegahan", p.getPencegahan());

        Penyakit existing = dao.findByNamaExact(p.getNamaPenyakit());
        if (existing != null && (p.getId() == null || !existing.getId().equals(p.getId()))) {
            throw new IllegalArgumentException("Nama penyakit sudah ada");
        }
        return dao.save(p);
    }

    public Penyakit create(Integer idKategori,
                           String namaPenyakit,
                           String pengertian,
                           String tandaGejala,
                           String faktorRisiko,
                           String pengobatanUmum,
                           String pencegahan) {

        requireId(idKategori);
        Kategori kat = kategoriSvc.byId(idKategori);
        if (kat == null) throw new IllegalArgumentException("Kategori tidak ditemukan");

        requireNama(namaPenyakit);
        requireText("Pengertian", pengertian);
        requireText("Tanda/gejala", tandaGejala);
        requireText("Faktor risiko", faktorRisiko);
        requireText("Pengobatan umum", pengobatanUmum);
        requireText("Pencegahan", pencegahan);

        Penyakit p = new Penyakit();
        p.setKategori(kat);
        p.setNamaPenyakit(namaPenyakit);
        p.setPengertian(pengertian);
        p.setTandaGejala(tandaGejala);
        p.setFaktorRisiko(faktorRisiko);
        p.setPengobatanUmum(pengobatanUmum);
        p.setPencegahan(pencegahan);

        if (dao.findByNamaExact(namaPenyakit) != null) {
            throw new IllegalArgumentException("Nama penyakit sudah ada");
        }
        return dao.save(p);
    }

    public Penyakit updateData(Integer idPenyakit,
                               Integer idKategoriBaru,     // boleh null (tetap)
                               String namaBaru,            // boleh null/blank (tetap)
                               String pengertian,          // boleh null/blank (tetap)
                               String tandaGejala,
                               String faktorRisiko,
                               String pengobatanUmum,
                               String pencegahan) {

        requireId(idPenyakit);
        Penyakit p = dao.find(idPenyakit);
        if (p == null) throw new IllegalArgumentException("Penyakit tidak ditemukan");

        if (idKategoriBaru != null) {
            Kategori kat = kategoriSvc.byId(idKategoriBaru);
            if (kat == null) throw new IllegalArgumentException("Kategori baru tidak ditemukan");
            p.setKategori(kat);
        }

        if (namaBaru != null && !namaBaru.isBlank()) {
            requireNama(namaBaru);
            Penyakit existing = dao.findByNamaExact(namaBaru);
            if (existing != null && !existing.getId().equals(p.getId())) {
                throw new IllegalArgumentException("Nama penyakit sudah ada");
            }
            p.setNamaPenyakit(namaBaru);
        }

        if (isProvided(pengertian))      p.setPengertian(pengertian);
        if (isProvided(tandaGejala))     p.setTandaGejala(tandaGejala);
        if (isProvided(faktorRisiko))    p.setFaktorRisiko(faktorRisiko);
        if (isProvided(pengobatanUmum))  p.setPengobatanUmum(pengobatanUmum);
        if (isProvided(pencegahan))      p.setPencegahan(pencegahan);

        requireKategori(p.getKategori());
        requireNama(p.getNamaPenyakit());
        requireText("Pengertian", p.getPengertian());
        requireText("Tanda/gejala", p.getTandaGejala());
        requireText("Faktor risiko", p.getFaktorRisiko());
        requireText("Pengobatan umum", p.getPengobatanUmum());
        requireText("Pencegahan", p.getPencegahan());

        return dao.save(p);
    }

    public Penyakit byId(Integer id) {
        requireId(id);
        return dao.find(id);
    }

    public List<Penyakit> semua() {
        return dao.findAll();
    }

    public Penyakit byNamaPersis(String nama) {
        requireNama(nama);
        return dao.findByNamaExact(nama);
    }

    public List<Penyakit> cariNama(String keyword) {
        return dao.findByNamaContains(keyword);
    }

    public List<Penyakit> byKategori(Integer idKategori) {
        requireId(idKategori);
        return dao.findByKategori(idKategori);
    }

    public List<Penyakit> terbaru(int max) {
        return dao.latest(max);
    }

    public List<Penyakit> page(int offset, int limit) {
        if (offset < 0 || limit < 0) throw new IllegalArgumentException("Offset/limit tidak valid");
        return dao.page(offset, limit);
    }

    public long hitungSemua() {
        return dao.countAll();
    }

    public long hitungByKategori(Integer idKategori) {
        requireId(idKategori);
        return dao.countByKategori(idKategori);
    }

    public void hapus(Integer id) {
        requireId(id);
        dao.deleteById(id);
    }
    
    public void hapusPaksa(Integer id) {
        dao.deleteForce(id);
    }

    private void requireNotNull(Object o, String msg) {
        if (o == null) throw new IllegalArgumentException(msg);
    }

    private void requireId(Integer id) {
        if (id == null || id <= 0) throw new IllegalArgumentException("ID tidak valid");
    }

    private void requireKategori(Kategori k) {
        if (k == null) throw new IllegalArgumentException("Kategori wajib diisi");
    }

    private void requireNama(String nama) {
        if (nama == null || nama.isBlank())
            throw new IllegalArgumentException("Nama penyakit wajib diisi");
        if (nama.length() > 120)
            throw new IllegalArgumentException("Nama penyakit terlalu panjang (maks 120)");
    }

    private void requireText(String label, String val) {
        if (val == null || val.isBlank())
            throw new IllegalArgumentException(label + " wajib diisi");
    }

    private boolean isProvided(String s) {
        return s != null && !s.isBlank();
    }
}

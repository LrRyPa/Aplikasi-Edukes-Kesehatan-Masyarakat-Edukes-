package service;

import dao.AkunDao;
import model.Akun;

import java.util.List;

public class AkunService {

    private final AkunDao dao = new AkunDao();

    public Akun byId(Integer id) {
        requireNotNull(id, "id akun wajib");
        return dao.find(id);
    }

    public Akun byEmail(String email) {
        requireEmail(email);
        return dao.findByEmail(email);
    }

    public List<Akun> semua() {
        return dao.findAll();
    }

    public boolean emailSudahDipakai(String email) {
        requireEmail(email);
        return dao.existsByEmail(email);
    }

    public Akun login(String email, String password) {
        if (email == null || email.isBlank()) throw new IllegalArgumentException("Email wajib");
        if (password == null || password.isBlank()) throw new IllegalArgumentException("Password wajib");

        Akun akun = dao.authenticate(email, password);  // <— pastikan ini
        if (akun == null) throw new IllegalArgumentException("Email atau password salah");
        return akun;
    }


    public boolean gantiPassword(Integer idAkun, String passwordLama, String passwordBaru) {
        requireNotNull(idAkun, "id akun wajib");
        requirePassword(passwordLama);
        requirePasswordBaru(passwordBaru);

        Akun a = dao.find(idAkun);
        if (a == null) return false;
        if (!a.getPassword().equals(passwordLama)) {
            throw new IllegalArgumentException("Password lama tidak cocok");
        }
        return dao.updatePassword(idAkun, passwordBaru);
    }

    public boolean resetPassword(Integer idAkun, String passwordBaru) {
        requireNotNull(idAkun, "id akun wajib");
        requirePasswordBaru(passwordBaru);
        return dao.updatePassword(idAkun, passwordBaru);
    }

    private void requireNotNull(Object o, String msg) {
        if (o == null) throw new IllegalArgumentException(msg);
    }

    private void requireEmail(String email) {
        if (email == null || email.isBlank())
            throw new IllegalArgumentException("Email wajib");
        if (!email.contains("@") || email.length() > 100)
            throw new IllegalArgumentException("Format email tidak valid / terlalu panjang");
    }

    private void requirePassword(String pw) {
        if (pw == null || pw.isBlank())
            throw new IllegalArgumentException("Password wajib");
        if (pw.length() < 6 || pw.length() > 20)
            throw new IllegalArgumentException("Panjang password 6–20 karakter");
    }

    private void requirePasswordBaru(String pw) {
        requirePassword(pw);
    }
}

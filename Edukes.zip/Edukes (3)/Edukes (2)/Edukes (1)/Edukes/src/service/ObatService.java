package service;

import dao.ObatDao;
import model.AnjuranObat;
import model.Obat;

import java.math.BigDecimal;
import java.util.List;

public class ObatService {

    private final ObatDao dao = new ObatDao();

    public Obat simpan(Obat o) {
        requireNotNull(o, "Obat tidak boleh null");
        requireNama(o.getNamaObat());
        requireDeskripsi(o.getDeskripsi());
        requireHarga(o.getHarga());
        requireGolongan(o.getGolongan());
        requireText("Indikasi umum", o.getIndikasiUmum());
        requireText("Efek samping", o.getEfekSamping());

        // Cegah duplikat nama (kecuali update dirinya sendiri)
        Obat existing = dao.findByNamaExact(o.getNamaObat());
        if (existing != null && (o.getId() == null || !existing.getId().equals(o.getId()))) {
            throw new IllegalArgumentException("Nama obat sudah ada");
        }
        return dao.save(o);
    }

    public Obat create(String namaObat,
                       String deskripsi,
                       BigDecimal harga,
                       String golongan,
                       String indikasiUmum,
                       String efekSamping) {
        requireNama(namaObat);
        requireDeskripsi(deskripsi);
        requireHarga(harga);
        requireGolongan(golongan);
        requireText("Indikasi umum", indikasiUmum);
        requireText("Efek samping", efekSamping);

        if (dao.existsByNama(namaObat)) {
            throw new IllegalArgumentException("Nama obat sudah ada");
        }

        Obat o = new Obat();
        o.setNamaObat(namaObat);
        o.setDeskripsi(deskripsi);
        o.setHarga(harga);
        o.setGolongan(golongan);
        o.setIndikasiUmum(indikasiUmum);
        o.setEfekSamping(efekSamping);
        return dao.save(o);
    }

    public Obat updateData(Integer idObat,
                           String namaBaru,
                           String deskripsiBaru,
                           BigDecimal hargaBaru,
                           String golonganBaru,
                           String indikasiBaru,
                           String efekSampingBaru) {

        requireId(idObat);
        Obat o = dao.find(idObat);
        if (o == null) throw new IllegalArgumentException("Obat tidak ditemukan");

        if (isProvided(namaBaru)) {
            requireNama(namaBaru);
            Obat existing = dao.findByNamaExact(namaBaru);
            if (existing != null && !existing.getId().equals(o.getId())) {
                throw new IllegalArgumentException("Nama obat sudah ada");
            }
            o.setNamaObat(namaBaru);
        }
        if (isProvided(deskripsiBaru))  { requireDeskripsi(deskripsiBaru); o.setDeskripsi(deskripsiBaru); }
        if (hargaBaru != null)          { requireHarga(hargaBaru);         o.setHarga(hargaBaru); }
        if (isProvided(golonganBaru))   { requireGolongan(golonganBaru);   o.setGolongan(golonganBaru); }
        if (isProvided(indikasiBaru))   { requireText("Indikasi umum", indikasiBaru);   o.setIndikasiUmum(indikasiBaru); }
        if (isProvided(efekSampingBaru)){ requireText("Efek samping", efekSampingBaru); o.setEfekSamping(efekSampingBaru); }


        requireNama(o.getNamaObat());
        requireDeskripsi(o.getDeskripsi());
        requireHarga(o.getHarga());
        requireGolongan(o.getGolongan());
        requireText("Indikasi umum", o.getIndikasiUmum());
        requireText("Efek samping", o.getEfekSamping());

        return dao.save(o);
    }

    public boolean updateHarga(Integer idObat, BigDecimal hargaBaru) {
        requireId(idObat);
        requireHarga(hargaBaru);
        return dao.updateHarga(idObat, hargaBaru);
    }

    public Obat byId(Integer id) {
        requireId(id);
        return dao.find(id);
    }

    public List<Obat> semua() {
        return dao.findAll();
    }

    public Obat byNamaPersis(String nama) {
        requireNama(nama);
        return dao.findByNamaExact(nama);
    }

    public boolean namaSudahAda(String nama) {
        requireNama(nama);
        return dao.existsByNama(nama);
    }

    public List<Obat> cariNama(String keyword) {
        return dao.findByNamaContains(keyword);
    }

    public List<Obat> byGolongan(String golongan) {
        requireGolongan(golongan);
        return dao.findByGolongan(golongan);
    }

    public List<Obat> byHargaBetween(BigDecimal min, BigDecimal max) {
        if (min == null || max == null) throw new IllegalArgumentException("Range harga wajib");
        if (min.compareTo(BigDecimal.ZERO) < 0 || max.compareTo(min) < 0)
            throw new IllegalArgumentException("Range harga tidak valid");
        return dao.findByHargaBetween(min, max);
    }

    public List<Obat> cariDiIndikasiAtauEfek(String keyword) {
        return dao.searchInIndikasiOrEfek(keyword);
    }

    public List<AnjuranObat> anjuranUntukObat(Integer idObat) {
        requireId(idObat);
        return dao.listAnjuran(idObat);
    }


    public List<Obat> terbaru(int max) {
        return dao.latest(max);
    }

    public List<Obat> page(int offset, int limit) {
        if (offset < 0 || limit < 0) throw new IllegalArgumentException("Offset/limit tidak valid");
        return dao.page(offset, limit);
    }

    public long hitungSemua() {
        return dao.countAll();
    }

    public void hapus(Integer id) {
        requireId(id);
        dao.deleteById(id);
    }
    
    public void hapusPaksa(Integer id) {
        dao.deleteForce(id);
    }

    private void requireNotNull(Object o, String msg) {
        if (o == null) throw new IllegalArgumentException(msg);
    }

    private void requireId(Integer id) {
        if (id == null || id <= 0) throw new IllegalArgumentException("ID tidak valid");
    }

    private void requireNama(String nama) {
        if (nama == null || nama.isBlank())
            throw new IllegalArgumentException("Nama obat wajib diisi");
        if (nama.length() > 120)
            throw new IllegalArgumentException("Nama obat terlalu panjang (maks 120)");
    }

    private void requireDeskripsi(String deskripsi) {
        if (deskripsi == null || deskripsi.isBlank())
            throw new IllegalArgumentException("Deskripsi wajib diisi");
    }

    private void requireHarga(BigDecimal harga) {
        if (harga == null)
            throw new IllegalArgumentException("Harga wajib diisi");
        if (harga.scale() > 2)
            throw new IllegalArgumentException("Harga maksimal 2 desimal");
        if (harga.compareTo(BigDecimal.ZERO) <= 0)
            throw new IllegalArgumentException("Harga harus > 0");
    }

    private void requireGolongan(String golongan) {
        if (golongan == null || golongan.isBlank())
            throw new IllegalArgumentException("Golongan wajib diisi");
        if (golongan.length() > 60)
            throw new IllegalArgumentException("Golongan terlalu panjang (maks 60)");
    }

    private void requireText(String label, String val) {
        if (val == null || val.isBlank())
            throw new IllegalArgumentException(label + " wajib diisi");
    }

    private boolean isProvided(String s) {
        return s != null && !s.isBlank();
    }
}

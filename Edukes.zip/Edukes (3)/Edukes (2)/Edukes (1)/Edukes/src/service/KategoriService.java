package service;

import dao.KategoriDao;
import model.Kategori;
import model.Penyakit;

import java.util.List;

public class KategoriService {

    private final KategoriDao dao = new KategoriDao();

    public Kategori simpan(Kategori k) {
        requireNotNull(k, "Kategori tidak boleh null");
        requireNama(k.getNamaKategori());
        requireDeskripsi(k.getDeskripsi());

        // Cegah duplikat nama (kecuali update dirinya sendiri)
        Kategori existing = dao.findByNamaExact(k.getNamaKategori());
        if (existing != null && (k.getId() == null || !existing.getId().equals(k.getId()))) {
            throw new IllegalArgumentException("Nama kategori sudah ada");
        }
        return dao.save(k);
    }

    public Kategori create(String namaKategori, String deskripsi) {
        requireNama(namaKategori);
        requireDeskripsi(deskripsi);

        if (dao.existsByNama(namaKategori)) {
            throw new IllegalArgumentException("Nama kategori sudah ada");
        }
        Kategori k = new Kategori();
        k.setNamaKategori(namaKategori);
        k.setDeskripsi(deskripsi);
        return dao.save(k);
    }

    public Kategori byId(Integer id) {
        requireId(id);
        return dao.find(id);
    }

    public List<Kategori> semua() {
        return dao.findAll();
    }

    public Kategori byNamaPersis(String nama) {
        requireNama(nama);
        return dao.findByNamaExact(nama);
    }

    public boolean namaSudahAda(String nama) {
        requireNama(nama);
        return dao.existsByNama(nama);
    }

    public List<Kategori> cariNama(String keyword) {
        return dao.findByNamaContains(keyword);
    }

    /** Ambil semua penyakit dalam kategori ini. */
    public List<Penyakit> penyakitDalamKategori(Integer idKategori) {
        requireId(idKategori);
        return dao.listPenyakit(idKategori);
    }

    public List<Kategori> terbaru(int max) {
        return dao.latest(max);
    }

    public List<Kategori> page(int offset, int limit) {
        if (offset < 0 || limit < 0) throw new IllegalArgumentException("Offset/limit tidak valid");
        return dao.page(offset, limit);
    }

    public long hitungSemua() {
        return dao.countAll();
    }

    public long hitungPenyakit(Integer idKategori) {
        requireId(idKategori);
        return dao.countPenyakit(idKategori);
    }

    public void hapus(Integer id) {
        requireId(id);
        dao.deleteById(id);
    }

    private void requireNotNull(Object o, String msg) {
        if (o == null) throw new IllegalArgumentException(msg);
    }

    private void requireId(Integer id) {
        if (id == null || id <= 0) throw new IllegalArgumentException("ID tidak valid");
    }

    private void requireNama(String nama) {
        if (nama == null || nama.isBlank())
            throw new IllegalArgumentException("Nama kategori wajib diisi");
        if (nama.length() > 100)
            throw new IllegalArgumentException("Nama kategori terlalu panjang (maks 100)");
    }

    private void requireDeskripsi(String deskripsi) {
        if (deskripsi == null || deskripsi.isBlank())
            throw new IllegalArgumentException("Deskripsi wajib diisi");
    }
}

package service;

import dao.ArtikelDao;
import model.Artikel;

import java.util.List;

public class ArtikelService {

    private final ArtikelDao dao = new ArtikelDao();

    public Artikel simpan(Artikel a) {
        requireNotNull(a, "Artikel tidak boleh null");
        requireJudul(a.getJudul());
        if (a.getStatusReview() == null || a.getStatusReview().isBlank()) {
            a.setStatusReview("DRAFT");
        } else {
            requireStatus(a.getStatusReview());
        }
        requireKonten(a.getKonten());
        return dao.save(a);
    }

    public boolean updateKonten(Integer idArtikel, String judulBaru, String kontenBaru) {
        requireId(idArtikel);
        if ((judulBaru == null || judulBaru.isBlank()) &&
            (kontenBaru == null || kontenBaru.isBlank())) {
            throw new IllegalArgumentException("Tidak ada perubahan isi");
        }
        if (judulBaru != null && !judulBaru.isBlank()) requireJudul(judulBaru);
        if (kontenBaru != null && !kontenBaru.isBlank()) requireKonten(kontenBaru);
        return dao.updateContent(idArtikel, judulBaru, kontenBaru);
    }

    public boolean updateStatus(Integer idArtikel, String statusBaru) {
        requireId(idArtikel);
        requireStatus(statusBaru);
        return dao.updateStatus(idArtikel, statusBaru);
    }


    public Artikel byId(Integer id) {
        requireId(id);
        return dao.find(id);
    }

    public List<Artikel> semua() {
        return dao.findAll();
    }

    public Artikel byJudulPersis(String judul) {
        requireJudul(judul);
        return dao.findByExactJudul(judul);
    }

    public boolean judulSudahAda(String judul) {
        requireJudul(judul);
        return dao.existsByJudul(judul);
    }

    public List<Artikel> cariJudul(String keyword) {
        return dao.findByJudulContains(keyword);
    }

    public List<Artikel> byAdmin(Integer idAdmin) {
        requireId(idAdmin);
        return dao.findByAdmin(idAdmin);
    }

    public List<Artikel> byPenyakit(Integer idPenyakit) {
        requireId(idPenyakit);
        return dao.findByPenyakit(idPenyakit);
    }

    public List<Artikel> terbaru(int max) {
        return dao.latest(max);
    }

    public List<Artikel> page(int offset, int limit) {
        if (offset < 0 || limit < 0) throw new IllegalArgumentException("Offset/limit tidak valid");
        return dao.page(offset, limit);
    }

    public long hitungSemua() {
        return dao.countAll();
    }

    public long hitungByAdminStatus(Integer idAdmin, String status) {
        requireId(idAdmin);
        requireStatus(status);
        return dao.countByAdminAndStatus(idAdmin, status);
    }


    public void hapus(Integer id) {
        requireId(id);
        dao.deleteById(id);
    }
    public void hapusPaksa(Integer id) {
        if (id == null) throw new IllegalArgumentException("ID artikel wajib diisi");
        dao.deleteForceMySql(id);

    }


    private void requireNotNull(Object o, String msg) {
        if (o == null) throw new IllegalArgumentException(msg);
    }

    private void requireId(Integer id) {
        if (id == null || id <= 0) throw new IllegalArgumentException("ID tidak valid");
    }

    private void requireJudul(String judul) {
        if (judul == null || judul.isBlank())
            throw new IllegalArgumentException("Judul wajib diisi");
        if (judul.length() > 200)
            throw new IllegalArgumentException("Judul terlalu panjang (maks 200)");
    }

    private void requireKonten(String konten) {
        if (konten == null || konten.isBlank())
            throw new IllegalArgumentException("Konten wajib diisi");
    }

    private void requireStatus(String status) {
        if (status == null || status.isBlank())
            throw new IllegalArgumentException("Status wajib diisi");
        if (status.length() > 20)
            throw new IllegalArgumentException("Status terlalu panjang (maks 20)");
    }
}

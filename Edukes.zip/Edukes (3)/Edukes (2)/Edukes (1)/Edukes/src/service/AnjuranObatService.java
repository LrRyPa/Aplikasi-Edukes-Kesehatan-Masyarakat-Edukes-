package service;

import dao.AnjuranObatDao;
import model.AnjuranObat;
import model.Obat;
import model.Penyakit;

import java.util.List;

public class AnjuranObatService {

    private final AnjuranObatDao dao = new AnjuranObatDao();
    private final PenyakitService penyakitSvc = new PenyakitService();
    private final ObatService obatSvc = new ObatService();

    public AnjuranObat create(Integer idPenyakit,
                              Integer idObat,
                              String dosisAnjuran,
                              String aturanPakai) {

        requireId(idPenyakit, "id penyakit wajib");
        requireId(idObat, "id obat wajib");
        requireText100("Dosis anjuran", dosisAnjuran);
        requireText100("Aturan pakai", aturanPakai);

        Penyakit p = penyakitSvc.byId(idPenyakit);
        if (p == null) throw new IllegalArgumentException("Penyakit tidak ditemukan");

        Obat o = obatSvc.byId(idObat);
        if (o == null) throw new IllegalArgumentException("Obat tidak ditemukan");

        if (dao.existsByPenyakitAndObat(idPenyakit, idObat)) {
            throw new IllegalArgumentException("Kombinasi penyakit & obat sudah ada");
        }

        AnjuranObat a = new AnjuranObat();
        a.setPenyakit(p);
        a.setObat(o);
        a.setDosisAnjuran(dosisAnjuran);
        a.setAturanPakai(aturanPakai);

        return dao.save(a);
    }

    public AnjuranObat updateData(Integer idAnjuran,
                                  Integer idPenyakitBaru,  
                                  Integer idObatBaru,      
                                  String dosisBaru,       
                                  String aturanBaru) {     
        requireId(idAnjuran, "id anjuran wajib");

        AnjuranObat a = dao.find(idAnjuran);
        if (a == null) throw new IllegalArgumentException("Anjuran tidak ditemukan");

        Integer targetPenyakitId = a.getPenyakit() != null ? a.getPenyakit().getId() : null;
        Integer targetObatId     = a.getObat()     != null ? a.getObat().getId()     : null;

        if (idPenyakitBaru != null) {
            Penyakit p = penyakitSvc.byId(idPenyakitBaru);
            if (p == null) throw new IllegalArgumentException("Penyakit baru tidak ditemukan");
            a.setPenyakit(p);
            targetPenyakitId = p.getId();
        }
        if (idObatBaru != null) {
            Obat o = obatSvc.byId(idObatBaru);
            if (o == null) throw new IllegalArgumentException("Obat baru tidak ditemukan");
            a.setObat(o);
            targetObatId = o.getId();
        }


        if ((idPenyakitBaru != null) || (idObatBaru != null)) {
            if (dao.existsByPenyakitAndObat(targetPenyakitId, targetObatId)) {
                AnjuranObat dupe = dao.findByPenyakitAndObat(targetPenyakitId, targetObatId);
                if (dupe != null && !dupe.getId().equals(a.getId())) {
                    throw new IllegalArgumentException("Kombinasi penyakit & obat sudah ada");
                }
            }
        }

        if (isProvided(dosisBaru)) {
            requireText100("Dosis anjuran", dosisBaru);
            a.setDosisAnjuran(dosisBaru);
        }
        if (isProvided(aturanBaru)) {
            requireText100("Aturan pakai", aturanBaru);
            a.setAturanPakai(aturanBaru);
        }

        requireNotNull(a.getPenyakit(), "Penyakit wajib");
        requireNotNull(a.getObat(), "Obat wajib");
        requireText100("Dosis anjuran", a.getDosisAnjuran());
        requireText100("Aturan pakai", a.getAturanPakai());

        return dao.save(a);
    }

    public boolean updateDosisDanAturan(Integer idAnjuran, String dosisBaru, String aturanBaru) {
        requireId(idAnjuran, "id anjuran wajib");
        if (!isProvided(dosisBaru) && !isProvided(aturanBaru)) {
            throw new IllegalArgumentException("Tidak ada perubahan");
        }
        if (isProvided(dosisBaru))  requireText100("Dosis anjuran", dosisBaru);
        if (isProvided(aturanBaru)) requireText100("Aturan pakai", aturanBaru);
        return dao.updateDosisDanAturan(idAnjuran, dosisBaru, aturanBaru);
    }


    public AnjuranObat byId(Integer id) {
        requireId(id, "id anjuran wajib");
        return dao.find(id);
    }

    public AnjuranObat byPenyakitDanObat(Integer idPenyakit, Integer idObat) {
        requireId(idPenyakit, "id penyakit wajib");
        requireId(idObat, "id obat wajib");
        return dao.findByPenyakitAndObat(idPenyakit, idObat);
    }

    public List<AnjuranObat> semua() {
        return dao.findAll();
    }

    public List<AnjuranObat> byPenyakit(Integer idPenyakit) {
        requireId(idPenyakit, "id penyakit wajib");
        return dao.findByPenyakit(idPenyakit);
    }

    public List<AnjuranObat> byObat(Integer idObat) {
        requireId(idObat, "id obat wajib");
        return dao.findByObat(idObat);
    }

    public List<AnjuranObat> cariTeks(String keyword) {
        return dao.searchInDosisOrAturan(keyword);
    }

    public List<AnjuranObat> page(int offset, int limit) {
        if (offset < 0 || limit < 0) throw new IllegalArgumentException("Offset/limit tidak valid");
        return dao.page(offset, limit);
    }

    public long hitungSemua() {
        return dao.countAll();
    }


    public void hapus(Integer id) {
        requireId(id, "id anjuran wajib");
        dao.deleteById(id);
    }

    public int hapusByPenyakit(Integer idPenyakit) {
        requireId(idPenyakit, "id penyakit wajib");
        return dao.deleteByPenyakit(idPenyakit);
    }

    public int hapusByObat(Integer idObat) {
        requireId(idObat, "id obat wajib");
        return dao.deleteByObat(idObat);
    }


    private void requireNotNull(Object o, String msg) {
        if (o == null) throw new IllegalArgumentException(msg);
    }

    private void requireId(Integer id, String msg) {
        if (id == null || id <= 0) throw new IllegalArgumentException(msg);
    }

    private void requireText100(String label, String val) {
        if (val == null || val.isBlank())
            throw new IllegalArgumentException(label + " wajib diisi");
        if (val.length() > 100)
            throw new IllegalArgumentException(label + " maksimal 100 karakter");
    }

    private boolean isProvided(String s) {
        return s != null && !s.isBlank();
    }
}

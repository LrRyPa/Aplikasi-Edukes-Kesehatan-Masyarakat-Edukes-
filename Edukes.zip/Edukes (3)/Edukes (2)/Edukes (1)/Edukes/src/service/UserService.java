package service;

import dao.UserDao;
import model.User;

import java.time.LocalDateTime;
import java.util.List;

public class UserService {

    private final UserDao dao = new UserDao();

    public User register(String nama, String email, String password, String alamat) {
        requireNama(nama);
        requireEmail(email);
        requirePassword(password);

        if (dao.existsEmailOnAkun(email)) {
            throw new IllegalArgumentException("Email sudah terdaftar");
        }

        User u = new User();
        u.setNama(nama);
        u.setEmail(email);
        u.setPassword(password);
        u.setAlamat(alamat);
        if (u.getTanggalRegistrasi() == null) {
            u.setTanggalRegistrasi(LocalDateTime.now());
       }
        return dao.save(u);
    }

    public User updateProfil(Integer idUser, String namaBaru, String alamatBaru) {
        requireNotNull(idUser, "id user wajib");
        requireNama(namaBaru);

        User u = dao.find(idUser);
        if (u == null) throw new IllegalArgumentException("User tidak ditemukan");

        u.setNama(namaBaru);
        u.setAlamat(alamatBaru);
        return dao.save(u);
    }
    
    public User update(User u) {
        requireNotNull(u, "User wajib");
        Integer id = u.getId(); // ganti jika fieldnya berbeda
        requireNotNull(id, "ID user wajib");

        requireNama(u.getNama());
        requireEmail(u.getEmail());

        if (dao.existsEmailOnAkunExceptId(u.getEmail(), id)) {
            throw new IllegalArgumentException("Email sudah dipakai akun lain");
        }

        if (u.getPassword() == null || u.getPassword().isBlank()) {
            User lama = dao.find(id);
            if (lama == null) throw new IllegalArgumentException("User tidak ditemukan");
            u.setPassword(lama.getPassword());
        } else {
            requirePassword(u.getPassword());
        }

        return dao.save(u);
    }
    public boolean gantiPassword(Integer idUser, String passwordLama, String passwordBaru) {
        requireNotNull(idUser, "id user wajib");
        requirePassword(passwordLama);
        requirePasswordBaru(passwordBaru);

        User u = dao.find(idUser);
        if (u == null) throw new IllegalArgumentException("User tidak ditemukan");
        if (!u.getPassword().equals(passwordLama)) {
            throw new IllegalArgumentException("Password lama tidak cocok");
        }
        return dao.updatePassword(idUser, passwordBaru);
    }


    public User byId(Integer id) {
        requireNotNull(id, "id user wajib");
        return dao.find(id);
    }

    public User byEmail(String email) {
        requireEmail(email);
        return dao.findByEmail(email);
    }

    public List<User> semua() {
        return dao.findAll();
    }

    public List<User> cariNama(String keyword) {
        return dao.searchByNama(keyword);
    }

    public List<User> terbaru(int max) {
        return dao.latestRegistered(max);
    }

    public void hapus(Integer id) {
        requireNotNull(id, "id user wajib");
        dao.deleteById(id);
    }

    private void requireNotNull(Object o, String msg) {
        if (o == null) throw new IllegalArgumentException(msg);
    }

    private void requireNama(String nama) {
        if (nama == null || nama.isBlank())
            throw new IllegalArgumentException("Nama wajib");
        if (nama.length() > 100)
            throw new IllegalArgumentException("Nama terlalu panjang (maks 100)");
    }

    private void requireEmail(String email) {
        if (email == null || email.isBlank())
            throw new IllegalArgumentException("Email wajib");
        if (!email.contains("@") || email.length() > 100)
            throw new IllegalArgumentException("Format email tidak valid / terlalu panjang");
    }

    private void requirePassword(String pw) {
        if (pw == null || pw.isBlank())
            throw new IllegalArgumentException("Password wajib");
        if (pw.length() < 6 || pw.length() > 20)
            throw new IllegalArgumentException("Panjang password 6–20 karakter");
    }

    private void requirePasswordBaru(String pw) {
        requirePassword(pw);
    }
}

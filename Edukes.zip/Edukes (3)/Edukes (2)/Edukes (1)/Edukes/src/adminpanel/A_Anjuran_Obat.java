package adminpanel;

import controller.AnjuranObatController;
import model.AnjuranObat;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.SwingUtilities;
import java.util.List;

public class A_Anjuran_Obat extends javax.swing.JFrame {
    
    private final AnjuranObatController anjuranController = new AnjuranObatController();
    private DefaultTableModel tblModel;
    private List<AnjuranObat> snapshot;

    public A_Anjuran_Obat() {
        initComponents();
        setLocationRelativeTo(null);
        setTitle("Anjuran Obat");
        configureTable();
        enforceSortById();
        reloadTable();

        addWindowListener(new WindowAdapter() {
            @Override public void windowActivated(WindowEvent e) { reloadTable(); }
        });
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel3 = new javax.swing.JPanel();
        KeObat1 = new javax.swing.JButton();
        KeArtikel1 = new javax.swing.JButton();
        KePenyakit1 = new javax.swing.JButton();
        KeMain1 = new javax.swing.JButton();
        keAnjuranObat = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        KeObat2 = new javax.swing.JButton();
        KeArtikel2 = new javax.swing.JButton();
        KePenyakit2 = new javax.swing.JButton();
        KeMain2 = new javax.swing.JButton();
        keAnjuranObat1 = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        tblAnjuranObat = new javax.swing.JTable();
        HapusAnjuran = new javax.swing.JButton();
        jPanel5 = new javax.swing.JPanel();
        KeObat3 = new javax.swing.JButton();
        KeArtikel3 = new javax.swing.JButton();
        KePenyakit3 = new javax.swing.JButton();
        KeMain3 = new javax.swing.JButton();
        keAnjuranObat2 = new javax.swing.JButton();
        PerbaruiAnjuran = new javax.swing.JButton();
        TambahAnjuran1 = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();

        jPanel3.setBackground(new java.awt.Color(230, 247, 249));

        KeObat1.setBackground(new java.awt.Color(219, 249, 249));
        KeObat1.setForeground(new java.awt.Color(0, 153, 153));
        KeObat1.setText("Obat");
        KeObat1.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        KeObat1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                KeObat1ActionPerformed(evt);
            }
        });

        KeArtikel1.setBackground(new java.awt.Color(219, 249, 249));
        KeArtikel1.setForeground(new java.awt.Color(0, 153, 153));
        KeArtikel1.setText("Artikel");
        KeArtikel1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                KeArtikel1ActionPerformed(evt);
            }
        });

        KePenyakit1.setBackground(new java.awt.Color(219, 249, 249));
        KePenyakit1.setForeground(new java.awt.Color(0, 153, 153));
        KePenyakit1.setText("Penyakit");
        KePenyakit1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                KePenyakit1ActionPerformed(evt);
            }
        });

        KeMain1.setBackground(new java.awt.Color(0, 51, 51));
        KeMain1.setForeground(new java.awt.Color(255, 255, 255));
        KeMain1.setText("Kembali");
        KeMain1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                KeMain1ActionPerformed(evt);
            }
        });

        keAnjuranObat.setBackground(new java.awt.Color(219, 249, 249));
        keAnjuranObat.setForeground(new java.awt.Color(0, 153, 153));
        keAnjuranObat.setText("Anjuran Obat");
        keAnjuranObat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                keAnjuranObatActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(KeArtikel1, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(KePenyakit1, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(KeObat1, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(keAnjuranObat)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 91, Short.MAX_VALUE)
                .addComponent(KeMain1, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(KeArtikel1, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(KePenyakit1, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(KeObat1, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(KeMain1, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(keAnjuranObat, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(14, Short.MAX_VALUE))
        );

        jPanel4.setBackground(new java.awt.Color(230, 247, 249));

        KeObat2.setBackground(new java.awt.Color(219, 249, 249));
        KeObat2.setForeground(new java.awt.Color(0, 153, 153));
        KeObat2.setText("Obat");
        KeObat2.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        KeObat2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                KeObat2ActionPerformed(evt);
            }
        });

        KeArtikel2.setBackground(new java.awt.Color(219, 249, 249));
        KeArtikel2.setForeground(new java.awt.Color(0, 153, 153));
        KeArtikel2.setText("Artikel");
        KeArtikel2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                KeArtikel2ActionPerformed(evt);
            }
        });

        KePenyakit2.setBackground(new java.awt.Color(219, 249, 249));
        KePenyakit2.setForeground(new java.awt.Color(0, 153, 153));
        KePenyakit2.setText("Penyakit");
        KePenyakit2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                KePenyakit2ActionPerformed(evt);
            }
        });

        KeMain2.setBackground(new java.awt.Color(0, 51, 51));
        KeMain2.setForeground(new java.awt.Color(255, 255, 255));
        KeMain2.setText("Kembali");
        KeMain2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                KeMain2ActionPerformed(evt);
            }
        });

        keAnjuranObat1.setBackground(new java.awt.Color(219, 249, 249));
        keAnjuranObat1.setForeground(new java.awt.Color(0, 153, 153));
        keAnjuranObat1.setText("Anjuran Obat");
        keAnjuranObat1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                keAnjuranObat1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(KeArtikel2, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(KePenyakit2, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(KeObat2, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(keAnjuranObat1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 91, Short.MAX_VALUE)
                .addComponent(KeMain2, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(KeArtikel2, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(KePenyakit2, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(KeObat2, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(KeMain2, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(keAnjuranObat1, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(14, Short.MAX_VALUE))
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        addContainerListener(new java.awt.event.ContainerAdapter() {
            public void componentAdded(java.awt.event.ContainerEvent evt) {
                formComponentAdded(evt);
            }
        });
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        tblAnjuranObat.setBackground(new java.awt.Color(255, 255, 255));
        tblAnjuranObat.setForeground(new java.awt.Color(0, 0, 0));
        tblAnjuranObat.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "ID", "Penyakit", "Obat", "Dosis Anjuran", "Aturan Pakai"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.Object.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        tblAnjuranObat.setSelectionBackground(new java.awt.Color(0, 153, 153));
        jScrollPane2.setViewportView(tblAnjuranObat);

        getContentPane().add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 90, 670, 300));

        HapusAnjuran.setBackground(new java.awt.Color(255, 102, 102));
        HapusAnjuran.setForeground(new java.awt.Color(255, 255, 255));
        HapusAnjuran.setText("Hapus");
        HapusAnjuran.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                HapusAnjuranActionPerformed(evt);
            }
        });
        getContentPane().add(HapusAnjuran, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 400, 75, 30));

        jPanel5.setBackground(new java.awt.Color(230, 247, 249));

        KeObat3.setBackground(new java.awt.Color(219, 249, 249));
        KeObat3.setForeground(new java.awt.Color(0, 153, 153));
        KeObat3.setText("Obat");
        KeObat3.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        KeObat3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                KeObat3ActionPerformed(evt);
            }
        });

        KeArtikel3.setBackground(new java.awt.Color(219, 249, 249));
        KeArtikel3.setForeground(new java.awt.Color(0, 153, 153));
        KeArtikel3.setText("Artikel");
        KeArtikel3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                KeArtikel3ActionPerformed(evt);
            }
        });

        KePenyakit3.setBackground(new java.awt.Color(219, 249, 249));
        KePenyakit3.setForeground(new java.awt.Color(0, 153, 153));
        KePenyakit3.setText("Penyakit");
        KePenyakit3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                KePenyakit3ActionPerformed(evt);
            }
        });

        KeMain3.setBackground(new java.awt.Color(0, 51, 51));
        KeMain3.setForeground(new java.awt.Color(255, 255, 255));
        KeMain3.setText("Kembali");
        KeMain3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                KeMain3ActionPerformed(evt);
            }
        });

        keAnjuranObat2.setBackground(new java.awt.Color(219, 249, 249));
        keAnjuranObat2.setForeground(new java.awt.Color(0, 153, 153));
        keAnjuranObat2.setText("Anjuran Obat");
        keAnjuranObat2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                keAnjuranObat2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(KeArtikel3, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(KePenyakit3, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(KeObat3, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(keAnjuranObat2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 92, Short.MAX_VALUE)
                .addComponent(KeMain3, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(KeArtikel3, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(KePenyakit3, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(KeObat3, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(KeMain3, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(keAnjuranObat2, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(14, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 20, 610, 60));

        PerbaruiAnjuran.setBackground(new java.awt.Color(0, 153, 153));
        PerbaruiAnjuran.setForeground(new java.awt.Color(255, 255, 255));
        PerbaruiAnjuran.setText("Perbarui");
        PerbaruiAnjuran.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PerbaruiAnjuranActionPerformed(evt);
            }
        });
        getContentPane().add(PerbaruiAnjuran, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 400, 75, 30));

        TambahAnjuran1.setBackground(new java.awt.Color(0, 153, 153));
        TambahAnjuran1.setForeground(new java.awt.Color(255, 255, 255));
        TambahAnjuran1.setText("Tambah");
        TambahAnjuran1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TambahAnjuran1ActionPerformed(evt);
            }
        });
        getContentPane().add(TambahAnjuran1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 400, 75, 30));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/FrameObat&Penyakit.png"))); // NOI18N
        jLabel2.setText("jLabel2");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 710, -1));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void configureTable() {
        tblModel = new DefaultTableModel(
                new Object[]{"ID","Penyakit","Obat","Dosis Anjuran","Aturan Pakai"}, 0
        ) {
            @Override public boolean isCellEditable(int r,int c){ return false; }
            @Override public Class<?> getColumnClass(int c){ return c==0 ? Integer.class : String.class; }
        };
        tblAnjuranObat.setModel(tblModel);
        tblAnjuranObat.setAutoCreateRowSorter(true);
        tblAnjuranObat.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        // Double-click → detail popup
        tblAnjuranObat.addMouseListener(new MouseAdapter() {
            @Override public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2 && SwingUtilities.isLeftMouseButton(e)) {
                    showDetailPopup();
                }
            }
        });
    }  
    
    private void enforceSortById() {
        var sorter = new javax.swing.table.TableRowSorter<>(tblModel);

        sorter.setComparator(0, (a, b) -> Integer.compare(((Number)a).intValue(),
                                                         ((Number)b).intValue()));


        java.util.List<javax.swing.RowSorter.SortKey> keys = java.util.List.of(
                new javax.swing.RowSorter.SortKey(0, javax.swing.SortOrder.ASCENDING)
        );
        sorter.setSortKeys(keys);
        sorter.sort();

        for (int i = 1; i < tblModel.getColumnCount(); i++) {
            sorter.setSortable(i, false);
        }

        tblAnjuranObat.setRowSorter(sorter);
    }

    public void reloadTable() {
        try {
            tblModel.setRowCount(0);
            snapshot = anjuranController.listAll();

            for (AnjuranObat a : snapshot) {
                String penyakit = a.getPenyakit()==null ? "" :
                        (a.getPenyakit().getNamaPenyakit()==null ? "" : a.getPenyakit().getNamaPenyakit());
                String obat = a.getObat()==null ? "" :
                        (a.getObat().getNamaObat()==null ? "" : a.getObat().getNamaObat());

                tblModel.addRow(new Object[]{
                        a.getId(),
                        penyakit,
                        obat,
                        nv(a.getDosisAnjuran()),
                        nv(a.getAturanPakai())
                });
            }
        } catch (Exception ex) {
            showError("Gagal memuat data anjuran obat: " + ex.getMessage());
        }
    }

    private void showDetailPopup() {
        Integer id = getSelectedId();
        if (id == null) return;

        try {
            var a = anjuranController.detail(id);
            if (a == null) { JOptionPane.showMessageDialog(this, "Data anjuran tidak ditemukan."); return; }

            String penyakit = (a.getPenyakit()==null || a.getPenyakit().getNamaPenyakit()==null)
                    ? "-" : a.getPenyakit().getNamaPenyakit();
            String obat = (a.getObat()==null || a.getObat().getNamaObat()==null)
                    ? "-" : a.getObat().getNamaObat();

            String msg = "<html><body style='width:480px'>"
                    + "<h3 style='margin:0'>Anjuran Obat #" + id + "</h3>"
                    + "<hr>"
                    + "<b>Penyakit:</b> " + escape(penyakit) + "<br>"
                    + "<b>Obat:</b> " + escape(obat) + "<br><br>"
                    + "<b>Dosis Anjuran:</b><br>" + escape(nv(a.getDosisAnjuran())) + "<br><br>"
                    + "<b>Aturan Pakai:</b><br>" + escape(nv(a.getAturanPakai()))
                    + "</body></html>";

            JOptionPane.showMessageDialog(this, msg, "Detail Anjuran Obat", JOptionPane.INFORMATION_MESSAGE);

        } catch (Exception ex) {
            showError("Gagal memuat detail: " + ex.getMessage());
        }
    }


    private Integer getSelectedId() {
        int row = tblAnjuranObat.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Pilih baris terlebih dahulu.");
            return null;
        }
        int modelRow = tblAnjuranObat.convertRowIndexToModel(row);
        Object idObj = tblModel.getValueAt(modelRow, 0);
        return (idObj instanceof Number) ? ((Number) idObj).intValue()
                : Integer.valueOf(idObj.toString());
    }

    private String nv(String s) { return s == null ? "" : s; }
    private String escape(String s) { return s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;"); }
    private void showError(String msg){
        JOptionPane.showMessageDialog(this, msg, "Error", JOptionPane.ERROR_MESSAGE);
    }
    
    
    private void formComponentAdded(java.awt.event.ContainerEvent evt) {//GEN-FIRST:event_formComponentAdded
        // TODO add your handling code here:
    }//GEN-LAST:event_formComponentAdded

    private void KeObat1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_KeObat1ActionPerformed

    }//GEN-LAST:event_KeObat1ActionPerformed

    private void KeArtikel1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_KeArtikel1ActionPerformed

    }//GEN-LAST:event_KeArtikel1ActionPerformed

    private void KePenyakit1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_KePenyakit1ActionPerformed

    }//GEN-LAST:event_KePenyakit1ActionPerformed

    private void KeMain1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_KeMain1ActionPerformed

    }//GEN-LAST:event_KeMain1ActionPerformed

    private void keAnjuranObatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_keAnjuranObatActionPerformed

    }//GEN-LAST:event_keAnjuranObatActionPerformed

    private void KeObat2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_KeObat2ActionPerformed

    }//GEN-LAST:event_KeObat2ActionPerformed

    private void KeArtikel2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_KeArtikel2ActionPerformed
 
    }//GEN-LAST:event_KeArtikel2ActionPerformed

    private void KePenyakit2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_KePenyakit2ActionPerformed

    }//GEN-LAST:event_KePenyakit2ActionPerformed

    private void KeMain2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_KeMain2ActionPerformed

    }//GEN-LAST:event_KeMain2ActionPerformed

    private void keAnjuranObat1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_keAnjuranObat1ActionPerformed
        ;
    }//GEN-LAST:event_keAnjuranObat1ActionPerformed

    private void KeObat3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_KeObat3ActionPerformed
        new A_Obat().setVisible(true); dispose();
    }//GEN-LAST:event_KeObat3ActionPerformed

    private void KeArtikel3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_KeArtikel3ActionPerformed
        new A_Artikel().setVisible(true); dispose();
    }//GEN-LAST:event_KeArtikel3ActionPerformed

    private void KePenyakit3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_KePenyakit3ActionPerformed
        A_Penyakit a_Penyakit = new A_Penyakit();
        a_Penyakit.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_KePenyakit3ActionPerformed

    private void KeMain3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_KeMain3ActionPerformed
        A_Main main = new A_Main();
        main.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_KeMain3ActionPerformed

    private void keAnjuranObat2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_keAnjuranObat2ActionPerformed
        
    }//GEN-LAST:event_keAnjuranObat2ActionPerformed

    private void PerbaruiAnjuranActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PerbaruiAnjuranActionPerformed
        Integer id = getSelectedId();
        if (id == null) return;
        new A_Edit_Anjuran_Obat(this, id).setVisible(true);
    }//GEN-LAST:event_PerbaruiAnjuranActionPerformed

    private void TambahAnjuran1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TambahAnjuran1ActionPerformed
        new A_Edit_Anjuran_Obat(this, null).setVisible(true);
    }//GEN-LAST:event_TambahAnjuran1ActionPerformed

    private void HapusAnjuranActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_HapusAnjuranActionPerformed
        Integer id = getSelectedId();
        if (id == null) return;

        int x = JOptionPane.showConfirmDialog(this,
                "Hapus anjuran terpilih?", "Konfirmasi", JOptionPane.YES_NO_OPTION);
        if (x != JOptionPane.YES_OPTION) return;

        try {
            anjuranController.delete(id);
            reloadTable();
            JOptionPane.showMessageDialog(this, "Anjuran dihapus.");
        } catch (RuntimeException fk) {
            int y = JOptionPane.showConfirmDialog(this,
                    "Data anjuran masih direferensikan (FK). Hapus paksa?",
                    "Konfirmasi Hapus Paksa",
                    JOptionPane.YES_NO_OPTION);
            if (y == JOptionPane.YES_OPTION) {
                try {
                    anjuranController.deleteForce(id);
                    reloadTable();
                    JOptionPane.showMessageDialog(this, "Anjuran dihapus paksa.");
                } catch (RuntimeException ex) {
                    showError("Gagal menghapus paksa: " + ex.getMessage());
                }
            }
        }
    }//GEN-LAST:event_HapusAnjuranActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
//            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
//        java.awt.EventQueue.invokeLater(() -> new Main().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton HapusAnjuran;
    private javax.swing.JButton KeArtikel1;
    private javax.swing.JButton KeArtikel2;
    private javax.swing.JButton KeArtikel3;
    private javax.swing.JButton KeMain1;
    private javax.swing.JButton KeMain2;
    private javax.swing.JButton KeMain3;
    private javax.swing.JButton KeObat1;
    private javax.swing.JButton KeObat2;
    private javax.swing.JButton KeObat3;
    private javax.swing.JButton KePenyakit1;
    private javax.swing.JButton KePenyakit2;
    private javax.swing.JButton KePenyakit3;
    private javax.swing.JButton PerbaruiAnjuran;
    private javax.swing.JButton TambahAnjuran1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JButton keAnjuranObat;
    private javax.swing.JButton keAnjuranObat1;
    private javax.swing.JButton keAnjuranObat2;
    private javax.swing.JTable tblAnjuranObat;
    // End of variables declaration//GEN-END:variables
}


package adminpanel;

import controller.ObatController;
import model.Obat;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.SwingUtilities;
import java.util.List;

public class A_Obat extends javax.swing.JFrame {
    
   private final ObatController obatController = new ObatController();
    private DefaultTableModel tblModel;
    private List<Obat> snapshot;
    
    public A_Obat() {
        initComponents();
        setLocationRelativeTo(null);
        jPanel3.setOpaque(false);
        jPanel3.setBackground(new java.awt.Color(0,0,0,0));
        setTitle("Obat");
        configureTable();
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowActivated(WindowEvent e) {
                reloadTable(); // refresh tiap kali A_Obat aktif lagi
            }
        });
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane2 = new javax.swing.JScrollPane();
        tblObat = new javax.swing.JTable();
        TambahObat = new javax.swing.JButton();
        HapusObat = new javax.swing.JButton();
        PerbaruiObat = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        KeObat1 = new javax.swing.JButton();
        KeArtikel1 = new javax.swing.JButton();
        KePenyakit1 = new javax.swing.JButton();
        KeMain1 = new javax.swing.JButton();
        keAnjuranObat = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        addContainerListener(new java.awt.event.ContainerAdapter() {
            public void componentAdded(java.awt.event.ContainerEvent evt) {
                formComponentAdded(evt);
            }
        });
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        tblObat.setBackground(new java.awt.Color(255, 255, 255));
        tblObat.setForeground(new java.awt.Color(0, 0, 0));
        tblObat.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "ID", "Obat", "Deskripsi", "Harga", "Golongan", "Indikasi Umum", "Efek Samping"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.Double.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        tblObat.setSelectionBackground(new java.awt.Color(0, 153, 153));
        jScrollPane2.setViewportView(tblObat);

        getContentPane().add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 90, 670, 300));

        TambahObat.setBackground(new java.awt.Color(0, 153, 153));
        TambahObat.setForeground(new java.awt.Color(255, 255, 255));
        TambahObat.setText("Tambah");
        TambahObat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TambahObatActionPerformed(evt);
            }
        });
        getContentPane().add(TambahObat, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 400, 75, 30));

        HapusObat.setBackground(new java.awt.Color(255, 102, 102));
        HapusObat.setForeground(new java.awt.Color(255, 255, 255));
        HapusObat.setText("Hapus");
        HapusObat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                HapusObatActionPerformed(evt);
            }
        });
        getContentPane().add(HapusObat, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 400, 75, 30));

        PerbaruiObat.setBackground(new java.awt.Color(0, 153, 153));
        PerbaruiObat.setForeground(new java.awt.Color(255, 255, 255));
        PerbaruiObat.setText("Perbarui");
        PerbaruiObat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PerbaruiObatActionPerformed(evt);
            }
        });
        getContentPane().add(PerbaruiObat, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 400, 75, 30));

        jPanel3.setBackground(new java.awt.Color(230, 247, 249));

        KeObat1.setBackground(new java.awt.Color(219, 249, 249));
        KeObat1.setForeground(new java.awt.Color(0, 153, 153));
        KeObat1.setText("Obat");
        KeObat1.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        KeObat1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                KeObat1ActionPerformed(evt);
            }
        });

        KeArtikel1.setBackground(new java.awt.Color(219, 249, 249));
        KeArtikel1.setForeground(new java.awt.Color(0, 153, 153));
        KeArtikel1.setText("Artikel");
        KeArtikel1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                KeArtikel1ActionPerformed(evt);
            }
        });

        KePenyakit1.setBackground(new java.awt.Color(219, 249, 249));
        KePenyakit1.setForeground(new java.awt.Color(0, 153, 153));
        KePenyakit1.setText("Penyakit");
        KePenyakit1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                KePenyakit1ActionPerformed(evt);
            }
        });

        KeMain1.setBackground(new java.awt.Color(0, 51, 51));
        KeMain1.setForeground(new java.awt.Color(255, 255, 255));
        KeMain1.setText("Kembali");
        KeMain1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                KeMain1ActionPerformed(evt);
            }
        });

        keAnjuranObat.setBackground(new java.awt.Color(219, 249, 249));
        keAnjuranObat.setForeground(new java.awt.Color(0, 153, 153));
        keAnjuranObat.setText("Anjuran Obat");
        keAnjuranObat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                keAnjuranObatActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(KeArtikel1, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(KePenyakit1, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(KeObat1, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(keAnjuranObat)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 91, Short.MAX_VALUE)
                .addComponent(KeMain1, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(KeArtikel1, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(KePenyakit1, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(KeObat1, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(KeMain1, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(keAnjuranObat, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(14, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 20, 610, 60));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/FrameObat&Penyakit.png"))); // NOI18N
        jLabel2.setText("jLabel2");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 710, -1));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void configureTable() {
    java.text.NumberFormat rupiah = java.text.NumberFormat.getNumberInstance(new java.util.Locale("id","ID"));
    rupiah.setMinimumFractionDigits(2);
    rupiah.setMaximumFractionDigits(2);

    javax.swing.table.DefaultTableCellRenderer hargaRenderer = new javax.swing.table.DefaultTableCellRenderer() {
        @Override public void setValue(Object v) {
            if (v == null) { setText(""); return; }
            if (v instanceof java.math.BigDecimal bd) {
                setText(rupiah.format(bd));
            } else if (v instanceof Number n) {
                setText(rupiah.format(n.doubleValue()));
            } else {
                setText(v.toString());
            }
        }
    };
    hargaRenderer.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
    tblObat.getColumnModel().getColumn(3).setCellRenderer(hargaRenderer);
        tblModel = new DefaultTableModel(
                new Object[]{"ID","Obat","Deskripsi","Harga","Golongan","Indikasi Umum","Efek Samping"}, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
            @Override public Class<?> getColumnClass(int c) {
                return switch (c) {
                    case 0 -> Integer.class;             // ID
                    case 3 -> java.math.BigDecimal.class; // Harga
                    default -> String.class;
                };
            }
        };

        tblObat.setModel(tblModel);
        tblObat.addMouseListener(new MouseAdapter() {
        @Override public void mouseClicked(MouseEvent e) {
            if (e.getClickCount() == 2 && SwingUtilities.isLeftMouseButton(e)) {
                showDetailPopup();
            }
        }
    });
        tblObat.setAutoCreateRowSorter(true);
    }

    private void showDetailPopup() {
        Integer id = getSelectedId();
        if (id == null) return;

        try {
            // ambil dari controller supaya data paling update
            var o = obatController.detail(id);
            if (o == null) {
                JOptionPane.showMessageDialog(this, "Data obat tidak ditemukan.");
                return;
            }

            String harga = (o.getHarga() == null) ? "-" : o.getHarga().toPlainString();

            // pakai HTML biar rapi
            String msg = "<html><body style='width:420px'>"
                    + "<h3 style='margin:0'>"+ escape(nv(o.getNamaObat())) +"</h3>"
                    + "<hr>"
                    + "<b>Golongan:</b> " + escape(nv(o.getGolongan())) + "<br>"
                    + "<b>Harga:</b> " + harga + "<br><br>"
                    + "<b>Deskripsi:</b><br>" + escape(nv(o.getDeskripsi())) + "<br><br>"
                    + "<b>Indikasi Umum:</b><br>" + escape(nv(o.getIndikasiUmum())) + "<br><br>"
                    + "<b>Efek Samping:</b><br>" + escape(nv(o.getEfekSamping()))
                    + "</body></html>";

            JOptionPane.showMessageDialog(this, msg, "Detail Obat", JOptionPane.INFORMATION_MESSAGE);

        } catch (Exception ex) {
            showError("Gagal memuat detail: " + ex.getMessage());
        }
    }


    private String nv(String s) { return s == null ? "" : s; }
    private String escape(String s) {
    return s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;");
    }
   
    
    public void reloadTable() {
        try {
            tblModel.setRowCount(0);
            snapshot = obatController.listAll(); 
            for (Obat o : snapshot) {
                tblModel.addRow(new Object[]{
                    o.getId(),
                    safe(o.getNamaObat()),
                    safe(o.getDeskripsi()),
                    o.getHarga(),
                    safe(o.getGolongan()),
                    safe(o.getIndikasiUmum()),
                    safe(o.getEfekSamping())
                });
            }
        } catch (Exception ex) {
            showError("Gagal memuat data obat: " + ex.getMessage());
        }
    }
    
        private void showError(String msg){
        JOptionPane.showMessageDialog(this, msg, "Error", JOptionPane.ERROR_MESSAGE);
    }
    
    private Integer getSelectedId() {
        int row = tblObat.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Pilih baris obat terlebih dahulu.");
            return null;
        }
        int modelRow = tblObat.convertRowIndexToModel(row);
        Object idObj = tblModel.getValueAt(modelRow, 0);
        return (idObj instanceof Number) ? ((Number) idObj).intValue() : Integer.valueOf(idObj.toString());
    }
    
    private String safe(String s){ return s == null ? "" : s; }
    
    private void formComponentAdded(java.awt.event.ContainerEvent evt) {//GEN-FIRST:event_formComponentAdded
        // TODO add your handling code here:
    }//GEN-LAST:event_formComponentAdded

    private void TambahObatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TambahObatActionPerformed
     new A_Edit_Obat(this).setVisible(true);
    }//GEN-LAST:event_TambahObatActionPerformed

    private void HapusObatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_HapusObatActionPerformed
        Integer id = getSelectedId();
        if (id == null) return;

        int x = JOptionPane.showConfirmDialog(this,
                "Hapus obat terpilih?", "Konfirmasi",
                JOptionPane.YES_NO_OPTION);
        if (x != JOptionPane.YES_OPTION) return;

        try {
            obatController.delete(id);
            reloadTable();
            JOptionPane.showMessageDialog(this, "Obat dihapus.");
        } catch (RuntimeException fk) {
            int y = JOptionPane.showConfirmDialog(this,
                    "Obat masih dipakai di tabel lain (FK). Hapus paksa?",
                    "Konfirmasi Hapus Paksa",
                    JOptionPane.YES_NO_OPTION);
            if (y == JOptionPane.YES_OPTION) {
                try {
                    obatController.deleteForce(id);
                    reloadTable();
                    JOptionPane.showMessageDialog(this, "Obat dihapus paksa.");
                } catch (RuntimeException ex) {
                    JOptionPane.showMessageDialog(this, ex.getMessage(), "Gagal", JOptionPane.ERROR_MESSAGE);
                }
            }
        }
    }//GEN-LAST:event_HapusObatActionPerformed

    
    private void PerbaruiObatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PerbaruiObatActionPerformed
        Integer id = getSelectedId();
        if (id == null) return;
        new A_Edit_Obat(this, id).setVisible(true); 
    }//GEN-LAST:event_PerbaruiObatActionPerformed

    private void KeObat1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_KeObat1ActionPerformed
        A_Obat a_Obat = new A_Obat();
        a_Obat.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_KeObat1ActionPerformed

    private void KeArtikel1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_KeArtikel1ActionPerformed
        A_Artikel a_Artikel = new A_Artikel();
        a_Artikel.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_KeArtikel1ActionPerformed

    private void KePenyakit1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_KePenyakit1ActionPerformed
        A_Penyakit a_Penyakit = new A_Penyakit();
        a_Penyakit.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_KePenyakit1ActionPerformed

    private void KeMain1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_KeMain1ActionPerformed
        A_Main main = new A_Main();
        main.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_KeMain1ActionPerformed

    private void keAnjuranObatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_keAnjuranObatActionPerformed
        A_Anjuran_Obat a_anjuran = new A_Anjuran_Obat();
        a_anjuran.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_keAnjuranObatActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
//            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
//        java.awt.EventQueue.invokeLater(() -> new Main().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton HapusObat;
    private javax.swing.JButton KeArtikel1;
    private javax.swing.JButton KeMain1;
    private javax.swing.JButton KeObat1;
    private javax.swing.JButton KePenyakit1;
    private javax.swing.JButton PerbaruiObat;
    private javax.swing.JButton TambahObat;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JButton keAnjuranObat;
    private javax.swing.JTable tblObat;
    // End of variables declaration//GEN-END:variables
}

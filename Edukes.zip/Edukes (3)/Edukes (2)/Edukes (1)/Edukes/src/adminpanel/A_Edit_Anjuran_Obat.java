package adminpanel;

import controller.AnjuranObatController;
import model.AnjuranObat;
import service.ObatService;
import service.PenyakitService;
import ui.PencarianCBox;

import javax.swing.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class A_Edit_Anjuran_Obat extends javax.swing.JFrame {
    
    private final AnjuranObatController anjuranCtrl = new AnjuranObatController();
    private final PenyakitService penyakitSvc = new PenyakitService();
    private final ObatService obatSvc = new ObatService();


    private final A_Anjuran_Obat parent; 
    private final Integer editingId;  
    
    public A_Edit_Anjuran_Obat(A_Anjuran_Obat parent, Integer idForEdit) {
        this.parent    = parent;
        this.editingId = idForEdit;

        initComponents();
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLocationRelativeTo(parent);
        setTitle(editingId == null ? "Tambah Anjuran Obat" : "Perbarui Anjuran Obat");

        // header transparan
        jPanel3.setOpaque(false);
        jPanel3.setBackground(new java.awt.Color(0,0,0,0));

        // text area jadi single-line feel (tinggi 1 baris + wrap)
        setupTextAreas();

        // isi combobox master
        DefaultComboBoxModel<ComboItem> mP = new DefaultComboBoxModel<>();
        DefaultComboBoxModel<ComboItem> mO = new DefaultComboBoxModel<>();
        NamaPenyakit.setModel(mP);
        NamaObat.setModel(mO);

        loadMasters(); 

        // jika edit, muat data
        if (editingId != null) {
            loadData(editingId);
        }

        // simpan
        SimpanObat.addActionListener(e -> onSimpan());

        // ketika form ditutup, refresh parent
        addWindowListener(new WindowAdapter() {
            @Override public void windowClosed(WindowEvent e) {
                if (A_Edit_Anjuran_Obat.this.parent != null) {
                    A_Edit_Anjuran_Obat.this.parent.reloadTable();
                }
            }
        });
    }
    
    public class ComboItem {
        private final Integer id;
        private final String  label;
        public ComboItem(Integer id, String label){ this.id=id; this.label=label; }
        public Integer getId(){ return id; }
        public String  getLabel(){ return label; }
        @Override public String toString(){ return label; } // yang ditampilkan di dropdown
    }
    
    public A_Edit_Anjuran_Obat(A_Anjuran_Obat parent) { this(parent, null); }
    public A_Edit_Anjuran_Obat() { this(null, null); }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        DosisPakai = new javax.swing.JTextArea();
        jLabel6 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        AturanPakai = new javax.swing.JTextArea();
        NamaPenyakit = new javax.swing.JComboBox();
        SimpanObat = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        KeObat1 = new javax.swing.JButton();
        KeArtikel1 = new javax.swing.JButton();
        KePenyakit1 = new javax.swing.JButton();
        KeMain1 = new javax.swing.JButton();
        keAnjuranObat = new javax.swing.JButton();
        NamaObat = new javax.swing.JComboBox();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        addContainerListener(new java.awt.event.ContainerAdapter() {
            public void componentAdded(java.awt.event.ContainerEvent evt) {
                formComponentAdded(evt);
            }
        });
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(0, 153, 153));
        jLabel4.setText("Nama Penyakit   :");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 140, 150, -1));

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(0, 153, 153));
        jLabel5.setText("Aturan Pakai       :");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 290, -1, -1));

        DosisPakai.setBackground(new java.awt.Color(255, 255, 255));
        DosisPakai.setColumns(20);
        DosisPakai.setForeground(new java.awt.Color(0, 0, 0));
        DosisPakai.setRows(5);
        jScrollPane1.setViewportView(DosisPakai);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 240, 430, 30));

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(0, 153, 153));
        jLabel6.setText("Nama Obat          :");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 190, 150, -1));

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(0, 153, 153));
        jLabel8.setText("Dosis Pakai          :");
        getContentPane().add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 240, -1, -1));

        AturanPakai.setBackground(new java.awt.Color(255, 255, 255));
        AturanPakai.setColumns(20);
        AturanPakai.setForeground(new java.awt.Color(0, 0, 0));
        AturanPakai.setRows(5);
        jScrollPane3.setViewportView(AturanPakai);

        getContentPane().add(jScrollPane3, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 290, 430, 30));

        NamaPenyakit.setBackground(new java.awt.Color(255, 255, 255));
        NamaPenyakit.setForeground(new java.awt.Color(0, 0, 0));
        NamaPenyakit.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        NamaPenyakit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NamaPenyakitActionPerformed(evt);
            }
        });
        getContentPane().add(NamaPenyakit, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 140, 430, 30));

        SimpanObat.setBackground(new java.awt.Color(0, 153, 153));
        SimpanObat.setForeground(new java.awt.Color(255, 255, 255));
        SimpanObat.setText("Simpan");
        getContentPane().add(SimpanObat, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 350, 85, 34));

        jPanel3.setBackground(new java.awt.Color(230, 247, 249));

        KeObat1.setBackground(new java.awt.Color(219, 249, 249));
        KeObat1.setForeground(new java.awt.Color(0, 153, 153));
        KeObat1.setText("Obat");
        KeObat1.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        KeObat1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                KeObat1ActionPerformed(evt);
            }
        });

        KeArtikel1.setBackground(new java.awt.Color(219, 249, 249));
        KeArtikel1.setForeground(new java.awt.Color(0, 153, 153));
        KeArtikel1.setText("Artikel");
        KeArtikel1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                KeArtikel1ActionPerformed(evt);
            }
        });

        KePenyakit1.setBackground(new java.awt.Color(219, 249, 249));
        KePenyakit1.setForeground(new java.awt.Color(0, 153, 153));
        KePenyakit1.setText("Penyakit");
        KePenyakit1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                KePenyakit1ActionPerformed(evt);
            }
        });

        KeMain1.setBackground(new java.awt.Color(0, 51, 51));
        KeMain1.setForeground(new java.awt.Color(255, 255, 255));
        KeMain1.setText("Kembali");
        KeMain1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                KeMain1ActionPerformed(evt);
            }
        });

        keAnjuranObat.setBackground(new java.awt.Color(219, 249, 249));
        keAnjuranObat.setForeground(new java.awt.Color(0, 153, 153));
        keAnjuranObat.setText("Anjuran Obat");
        keAnjuranObat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                keAnjuranObatActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(KeArtikel1, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(KePenyakit1, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(KeObat1, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(keAnjuranObat)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 91, Short.MAX_VALUE)
                .addComponent(KeMain1, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(KeArtikel1, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(KePenyakit1, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(KeObat1, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(KeMain1, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(keAnjuranObat, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(14, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 20, 610, 60));

        NamaObat.setBackground(new java.awt.Color(255, 255, 255));
        NamaObat.setForeground(new java.awt.Color(0, 0, 0));
        NamaObat.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        NamaObat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NamaObatActionPerformed(evt);
            }
        });
        getContentPane().add(NamaObat, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 190, 430, 30));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/FrameObat&Penyakit.png"))); // NOI18N
        jLabel2.setText("jLabel2");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 710, -1));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents
    
    private void setupTextAreas() {
        DosisPakai.setLineWrap(true);
        DosisPakai.setWrapStyleWord(true);
        AturanPakai.setLineWrap(true);
        AturanPakai.setWrapStyleWord(true);
    } 
    
    private void loadMasters() {
        // ====== Penyakit ======
        DefaultComboBoxModel<ComboItem> mp = new DefaultComboBoxModel<>();
        for (var p : penyakitSvc.semua()) {
            mp.addElement(new ComboItem(p.getId(), p.getNamaPenyakit()));
        }
        NamaPenyakit.setModel(mp);
        NamaPenyakit.setSelectedIndex(mp.getSize() == 0 ? -1 : 0);

        // ====== Obat ======
        DefaultComboBoxModel<ComboItem> mo = new DefaultComboBoxModel<>();
        for (var o : obatSvc.semua()) {
            mo.addElement(new ComboItem(o.getId(), o.getNamaObat()));
        }
        NamaObat.setModel(mo);
        NamaObat.setSelectedIndex(mo.getSize() == 0 ? -1 : 0);

        // jadikan searchable
        PencarianCBox.attach(NamaPenyakit);
        PencarianCBox.attach(NamaObat);
    }

    private void loadData(Integer id) {
        try {
            AnjuranObat a = anjuranCtrl.detail(id);
            if (a == null) {
                JOptionPane.showMessageDialog(this, "Data anjuran tidak ditemukan.");
                return;
            }
            selectComboById(NamaPenyakit, a.getPenyakit() == null ? null : a.getPenyakit().getId());
            selectComboById(NamaObat,     a.getObat()     == null ? null : a.getObat().getId());
            DosisPakai.setText(safe(a.getDosisAnjuran()));
            AturanPakai.setText(safe(a.getAturanPakai()));
        } catch (RuntimeException ex) {
            showError("Gagal memuat data: " + ex.getMessage());
        }
    }
    
    private void selectComboById(JComboBox<?> cb, Integer id) {
        if (id == null) { cb.setSelectedIndex(-1); return; }
        ComboBoxModel<?> m = cb.getModel();
        for (int i=0; i<m.getSize(); i++) {
            Object it = m.getElementAt(i);
            if (it instanceof ComboItem c && id.equals(c.id)) {
                cb.setSelectedIndex(i);
                return;
            }
        }
        cb.setSelectedIndex(-1);
    }
    
    private static Integer getSelectedId(javax.swing.JComboBox cb){
        Object it = cb.getSelectedItem();
        return (it instanceof ComboItem ci) ? ci.getId() : null;
    }
    
    private String safe(String s){ return s == null ? "" : s; }
    
    private void onSimpan() {
        try {
            Integer idPenyakit = getSelectedId(NamaPenyakit);
            Integer idObat     = getSelectedId(NamaObat);
            String dosis       = DosisPakai.getText().trim();
            String aturan      = AturanPakai.getText().trim();

            if (idPenyakit == null) throw new IllegalArgumentException("Penyakit wajib dipilih");
            if (idObat == null)     throw new IllegalArgumentException("Obat wajib dipilih");

            if (editingId == null) {
                // CREATE
                anjuranCtrl.create(idPenyakit, idObat, dosis, aturan);
                JOptionPane.showMessageDialog(this, "Anjuran obat berhasil ditambahkan.");
            } else {
                // UPDATE (boleh ganti relasi & teks)
                anjuranCtrl.update(editingId, idPenyakit, idObat, dosis, aturan);
                JOptionPane.showMessageDialog(this, "Anjuran obat berhasil diperbarui.");
            }

            // kembali ke list
            if (parent != null) parent.reloadTable();
            dispose();

        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Validasi", JOptionPane.WARNING_MESSAGE);
        } catch (RuntimeException ex) {
            showError("Gagal menyimpan: " + ex.getMessage());
        }
    }
    
    private void showError(String msg){
        JOptionPane.showMessageDialog(this, msg, "Error", JOptionPane.ERROR_MESSAGE);
    }
    
    
    private String nv(String s) {
        return (s == null) ? "" : s;
    }
    
    
    private void formComponentAdded(java.awt.event.ContainerEvent evt) {//GEN-FIRST:event_formComponentAdded
        // TODO add your handling code here:
    }//GEN-LAST:event_formComponentAdded

    private void NamaPenyakitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NamaPenyakitActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_NamaPenyakitActionPerformed

    private void KeObat1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_KeObat1ActionPerformed
        new A_Obat().setVisible(true); dispose();
    }//GEN-LAST:event_KeObat1ActionPerformed

    private void KeArtikel1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_KeArtikel1ActionPerformed
        new A_Artikel().setVisible(true); dispose();
    }//GEN-LAST:event_KeArtikel1ActionPerformed

    private void KePenyakit1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_KePenyakit1ActionPerformed
        new A_Penyakit().setVisible(true); dispose();
    }//GEN-LAST:event_KePenyakit1ActionPerformed

    private void KeMain1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_KeMain1ActionPerformed
        new A_Main().setVisible(true); dispose();
    }//GEN-LAST:event_KeMain1ActionPerformed

    private void keAnjuranObatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_keAnjuranObatActionPerformed
        new A_Anjuran_Obat().setVisible(true); dispose();
    }//GEN-LAST:event_keAnjuranObatActionPerformed

    private void NamaObatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NamaObatActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_NamaObatActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
//            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
//        java.awt.EventQueue.invokeLater(() -> new Main().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextArea AturanPakai;
    private javax.swing.JTextArea DosisPakai;
    private javax.swing.JButton KeArtikel1;
    private javax.swing.JButton KeMain1;
    private javax.swing.JButton KeObat1;
    private javax.swing.JButton KePenyakit1;
    private javax.swing.JComboBox NamaObat;
    private javax.swing.JComboBox NamaPenyakit;
    private javax.swing.JButton SimpanObat;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JButton keAnjuranObat;
    // End of variables declaration//GEN-END:variables
}

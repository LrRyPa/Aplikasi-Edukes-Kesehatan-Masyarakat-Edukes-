
package adminpanel;

import controller.ArtikelController;
import model.Artikel;
import model.Penyakit;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;

import java.time.format.DateTimeFormatter;
import java.util.Comparator;
import java.util.List;
import util.Sesi;

public class A_Artikel extends javax.swing.JFrame {
    
    private final ArtikelController artikelController = new ArtikelController();

    private DefaultTableModel tblModel;
    private List<Artikel> snapshot;
    private Integer adminLoginId;

    public A_Artikel() {
        initComponents();
        setLocationRelativeTo(null);
        jPanel3.setOpaque(false);
        jPanel3.setBackground(new java.awt.Color(0,0,0,0));
        this.adminLoginId = Sesi.requireAdminId();
        setTitle("Artikel");
        configureTable();
        reloadTable();
    }
    
    public A_Artikel(Integer adminLoginId) {
        this();                      
        this.adminLoginId = adminLoginId;
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane2 = new javax.swing.JScrollPane();
        TabelArtikel = new javax.swing.JTable();
        TambahArtikel = new javax.swing.JButton();
        HapusArtikel = new javax.swing.JButton();
        PerbaruiArtikel = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        KeObat1 = new javax.swing.JButton();
        KeArtikel1 = new javax.swing.JButton();
        KePenyakit1 = new javax.swing.JButton();
        KeMain1 = new javax.swing.JButton();
        keAnjuranObat = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        addContainerListener(new java.awt.event.ContainerAdapter() {
            public void componentAdded(java.awt.event.ContainerEvent evt) {
                formComponentAdded(evt);
            }
        });
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        TabelArtikel.setBackground(new java.awt.Color(255, 255, 255));
        TabelArtikel.setForeground(new java.awt.Color(0, 0, 0));
        TabelArtikel.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "ID", "Judul", "Admin", "Penyakit", "Isi Artikel", "Status", "Tanggal Upload"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.Integer.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        TabelArtikel.setSelectionBackground(new java.awt.Color(0, 153, 153));
        jScrollPane2.setViewportView(TabelArtikel);

        getContentPane().add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 90, 670, 300));

        TambahArtikel.setBackground(new java.awt.Color(0, 153, 153));
        TambahArtikel.setForeground(new java.awt.Color(255, 255, 255));
        TambahArtikel.setText("Tambah");
        TambahArtikel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TambahArtikelActionPerformed(evt);
            }
        });
        getContentPane().add(TambahArtikel, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 400, 75, 30));

        HapusArtikel.setBackground(new java.awt.Color(255, 102, 102));
        HapusArtikel.setForeground(new java.awt.Color(255, 255, 255));
        HapusArtikel.setText("Hapus");
        HapusArtikel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                HapusArtikelActionPerformed(evt);
            }
        });
        getContentPane().add(HapusArtikel, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 400, 75, 30));

        PerbaruiArtikel.setBackground(new java.awt.Color(0, 153, 153));
        PerbaruiArtikel.setForeground(new java.awt.Color(255, 255, 255));
        PerbaruiArtikel.setText("Perbarui");
        PerbaruiArtikel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PerbaruiArtikelActionPerformed(evt);
            }
        });
        getContentPane().add(PerbaruiArtikel, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 400, 75, 30));

        jPanel3.setBackground(new java.awt.Color(230, 247, 249));

        KeObat1.setBackground(new java.awt.Color(219, 249, 249));
        KeObat1.setForeground(new java.awt.Color(0, 153, 153));
        KeObat1.setText("Obat");
        KeObat1.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        KeObat1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                KeObat1ActionPerformed(evt);
            }
        });

        KeArtikel1.setBackground(new java.awt.Color(219, 249, 249));
        KeArtikel1.setForeground(new java.awt.Color(0, 153, 153));
        KeArtikel1.setText("Artikel");
        KeArtikel1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                KeArtikel1ActionPerformed(evt);
            }
        });

        KePenyakit1.setBackground(new java.awt.Color(219, 249, 249));
        KePenyakit1.setForeground(new java.awt.Color(0, 153, 153));
        KePenyakit1.setText("Penyakit");
        KePenyakit1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                KePenyakit1ActionPerformed(evt);
            }
        });

        KeMain1.setBackground(new java.awt.Color(0, 51, 51));
        KeMain1.setForeground(new java.awt.Color(255, 255, 255));
        KeMain1.setText("Kembali");
        KeMain1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                KeMain1ActionPerformed(evt);
            }
        });

        keAnjuranObat.setBackground(new java.awt.Color(219, 249, 249));
        keAnjuranObat.setForeground(new java.awt.Color(0, 153, 153));
        keAnjuranObat.setText("Anjuran Obat");
        keAnjuranObat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                keAnjuranObatActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(KeArtikel1, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(KePenyakit1, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(KeObat1, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(keAnjuranObat)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 91, Short.MAX_VALUE)
                .addComponent(KeMain1, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(KeArtikel1, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(KePenyakit1, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(KeObat1, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(KeMain1, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(keAnjuranObat, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(14, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 20, 610, 60));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/FrameObat&Penyakit.png"))); // NOI18N
        jLabel2.setText("jLabel2");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 710, -1));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void configureTable() {
        tblModel = new DefaultTableModel(
            new Object[]{"ID","Judul","Admin","Penyakit","Isi Artikel","Status","Tanggal Upload"}, 0
        ) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
            @Override public Class<?> getColumnClass(int c) { return (c == 0) ? Integer.class : String.class; }
        };

        TabelArtikel.setModel(tblModel);
        TabelArtikel.setAutoCreateColumnsFromModel(true);

        // sorter default: ID ASC
        TableRowSorter<DefaultTableModel> sorter = new TableRowSorter<>(tblModel);
        sorter.setComparator(0, Comparator.comparingInt(o -> Integer.parseInt(String.valueOf(o))));
        TabelArtikel.setRowSorter(sorter);
        sorter.toggleSortOrder(0);
        
        TabelArtikel.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override public void mouseClicked(java.awt.event.MouseEvent e) {
                if (e.getClickCount() == 2 && SwingUtilities.isLeftMouseButton(e)) {
                    showDetailPopup();
                }
            }
        });
    }
        
    public void reloadTable() {
        try {
            tblModel.setRowCount(0);
            snapshot = artikelController.listAll(); // pastikan controller mengembalikan relasi admin & penyakit (JOIN/Fetch)
            DateTimeFormatter fmt = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");

            for (Artikel a : snapshot) {
                String adminNama = (a.getAdmin()==null || a.getAdmin().getNama()==null)
                        ? "-" : a.getAdmin().getNama();

                Penyakit py = a.getPenyakit();
                String penyakitNama = (py==null || py.getNamaPenyakit()==null)
                        ? "-" : py.getNamaPenyakit();

                String ringkasKonten = ringkas(nv(a.getKonten()), 90);

                String tgl;
                Object tu = a.getTanggalUpload();
                if (tu == null) {
                    tgl = "-";
                } else if (tu instanceof java.time.LocalDateTime ldt) {
                    tgl = ldt.format(fmt);
                } else if (tu instanceof java.sql.Timestamp ts) {
                    tgl = ts.toLocalDateTime().format(fmt);
                } else if (tu instanceof java.util.Date d) {
                    tgl = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm").format(d);
                } else {
                    tgl = String.valueOf(tu);
                }

                tblModel.addRow(new Object[]{
                    a.getId(),
                    nv(a.getJudul()),
                    adminNama,
                    penyakitNama,
                    ringkasKonten,
                    nv(a.getStatusReview()),
                    tgl
                });
            }
        } catch (Exception ex) {
            showError("Gagal memuat artikel: " + ex.getMessage());
        }
    }
        
    private void showDetailPopup() {
        Integer id = getSelectedId();
        if (id == null) return;

        try {
            var a = artikelController.detail(id);
            if (a == null) { JOptionPane.showMessageDialog(this,"Data artikel tidak ditemukan."); return; }

            String adminNama = (a.getAdmin()==null || a.getAdmin().getNama()==null) ? "-" : a.getAdmin().getNama();
            Penyakit p = a.getPenyakit();
            String namaPenyakit = (p==null || p.getNamaPenyakit()==null) ? "-" : p.getNamaPenyakit();
            String tgl = (a.getTanggalUpload()==null) ? "-" : a.getTanggalUpload().toString();

            String msg = "<html><body style='width:560px'>"
                    + "<h3 style='margin:0'>" + escape(nv(a.getJudul())) + "</h3><hr>"
                    + "<b>Admin:</b> " + escape(adminNama) + "<br>"
                    + "<b>Penyakit:</b> " + escape(namaPenyakit) + "<br>"
                    + "<b>Status:</b> " + escape(nv(a.getStatusReview())) + "<br>"
                    + "<b>Tanggal:</b> " + escape(tgl) + "<br><br>"
                    + "<b>Isi Artikel:</b><br>" + escape(nv(a.getKonten()))
                    + "</body></html>";

            JOptionPane.showMessageDialog(this, msg, "Detail Artikel", JOptionPane.INFORMATION_MESSAGE);

        } catch (Exception ex) {
            showError("Gagal memuat detail: " + ex.getMessage());
        }
    }

    private Integer getSelectedId() {
        int row = TabelArtikel.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Pilih baris artikel terlebih dahulu.");
            return null;
        }
        int modelRow = TabelArtikel.convertRowIndexToModel(row);
        Object idObj = tblModel.getValueAt(modelRow, 0);
        return (idObj instanceof Number) ? ((Number) idObj).intValue()
                                         : Integer.valueOf(String.valueOf(idObj));
    }
    
    private void openEdit() {
        Integer id = getSelectedId();
        if (id == null) return;

        A_Edit_Artikel edit = new A_Edit_Artikel(this, id, adminLoginId);

        // Saat editor ditutup, baru reload tabel (di-defer, aman).
        edit.addWindowListener(new java.awt.event.WindowAdapter() {
            @Override public void windowClosed(java.awt.event.WindowEvent e) {
                SwingUtilities.invokeLater(A_Artikel.this::reloadTable);
            }
        });

        edit.setVisible(true);
    }
    private void showError(String msg){
        JOptionPane.showMessageDialog(this, msg, "Error", JOptionPane.ERROR_MESSAGE);
    }

    private static String nv(String s){ return s==null ? "" : s; }
    private static String ringkas(String s, int max){
        if (s == null) return "";
        String t = s.replace('\n',' ').trim();
        return (t.length() <= max) ? t : t.substring(0, max-3) + "...";
    }
    private static String escape(String s){
        return s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;");
    }    
    
    private void formComponentAdded(java.awt.event.ContainerEvent evt) {//GEN-FIRST:event_formComponentAdded
        // TODO add your handling code here:
    }//GEN-LAST:event_formComponentAdded

    private void TambahArtikelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TambahArtikelActionPerformed
        new A_Edit_Artikel(this, null, adminLoginId).setVisible(true);
    }//GEN-LAST:event_TambahArtikelActionPerformed

    private void PerbaruiArtikelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PerbaruiArtikelActionPerformed
        openEdit();
    }//GEN-LAST:event_PerbaruiArtikelActionPerformed

    private void HapusArtikelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_HapusArtikelActionPerformed
        Integer id = getSelectedId();
        if (id == null) return;

        int x = JOptionPane.showConfirmDialog(this,
                "Hapus artikel terpilih?", "Konfirmasi",
                JOptionPane.YES_NO_OPTION);
        if (x != JOptionPane.YES_OPTION) return;

        try {
            artikelController.delete(id);
            reloadTable();
            JOptionPane.showMessageDialog(this, "Artikel dihapus.");
        } catch (RuntimeException fk) {
            int y = JOptionPane.showConfirmDialog(this,
                    "Artikel masih terhubung (FK). Hapus paksa?",
                    "Konfirmasi Hapus Paksa",
                    JOptionPane.YES_NO_OPTION);
            if (y == JOptionPane.YES_OPTION) {
                try {
                    artikelController.deleteForce(id);
                    reloadTable();
                    JOptionPane.showMessageDialog(this, "Artikel dihapus paksa.");
                } catch (RuntimeException ex) {
                    showError(ex.getMessage());
                }
            }
        }
    }//GEN-LAST:event_HapusArtikelActionPerformed

    private void KeObat1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_KeObat1ActionPerformed
        A_Obat a_Obat = new A_Obat();
        a_Obat.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_KeObat1ActionPerformed

    private void KeArtikel1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_KeArtikel1ActionPerformed
        A_Artikel a_Artikel = new A_Artikel();
        a_Artikel.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_KeArtikel1ActionPerformed

    private void KePenyakit1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_KePenyakit1ActionPerformed
        A_Penyakit a_Penyakit = new A_Penyakit();
        a_Penyakit.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_KePenyakit1ActionPerformed

    private void KeMain1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_KeMain1ActionPerformed
        A_Main main = new A_Main();
        main.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_KeMain1ActionPerformed

    private void keAnjuranObatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_keAnjuranObatActionPerformed
        A_Anjuran_Obat a_anjuran = new A_Anjuran_Obat();
        a_anjuran.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_keAnjuranObatActionPerformed
  
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
//            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
//        java.awt.EventQueue.invokeLater(() -> new Main().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton HapusArtikel;
    private javax.swing.JButton KeArtikel1;
    private javax.swing.JButton KeMain1;
    private javax.swing.JButton KeObat1;
    private javax.swing.JButton KePenyakit1;
    private javax.swing.JButton PerbaruiArtikel;
    private javax.swing.JTable TabelArtikel;
    private javax.swing.JButton TambahArtikel;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JButton keAnjuranObat;
    // End of variables declaration//GEN-END:variables
}

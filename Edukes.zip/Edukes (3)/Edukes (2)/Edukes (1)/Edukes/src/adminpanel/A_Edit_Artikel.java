
package adminpanel;

import controller.ArtikelController;
import model.Artikel;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ComboBoxModel;
import javax.swing.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
public class A_Edit_Artikel extends javax.swing.JFrame {
    
    private final ArtikelController artikelController = new ArtikelController();
    private final controller.PenyakitController penyakitController = new controller.PenyakitController();
    private java.util.List<model.Penyakit> penyakitRef = new java.util.ArrayList<>();
    private DefaultComboBoxModel<String> penyakitModel;
    private final A_Artikel parent;
    private final Integer editingId;
    private final Integer adminIdLogin;
    private java.util.List<String> penyakitLabels = new java.util.ArrayList<>();
    
    public A_Edit_Artikel(A_Artikel parent, Integer idForEdit) {
        this(parent, idForEdit, null); 
    }
    
    public A_Edit_Artikel(A_Artikel parent, Integer idForEdit, Integer adminIdLogin) {
        this.parent = parent;
        this.editingId = idForEdit;
        this.adminIdLogin = adminIdLogin;

        initComponents();
        NamaPenyakit.setRenderer(new DefaultListCellRenderer() {
            @Override
            public java.awt.Component getListCellRendererComponent(
                    JList<?> list, Object value, int index,
                    boolean isSelected, boolean cellHasFocus) {
                super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
                if (value instanceof model.Penyakit p) {
                    setText(p.getNamaPenyakit() == null ? "(tanpa nama)" : p.getNamaPenyakit());
                } else if (value == null) {
                    setText("— Pilih Penyakit —");
                }
                return this;
            }
        });
        setLocationRelativeTo(parent);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setTitle(editingId == null ? "Tambah Artikel" : "Perbarui Artikel");

        configureTextAreas();
        configureStatusCombo();
        loadPenyakitCombo();
        
        if (editingId != null) loadData(editingId);

        SimpanArtikel.addActionListener(e -> onSimpan());
        addWindowListener(new java.awt.event.WindowAdapter() {
            @Override public void windowClosed(java.awt.event.WindowEvent e) {
                if (parent != null) parent.reloadTable();
            }
        });
        jPanel3.setOpaque(false);
        jPanel3.setBackground(new java.awt.Color(0,0,0,0));
    }
   

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        JudulArtikel = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        KontenArtikel = new javax.swing.JTextArea();
        ComboArtikel = new javax.swing.JComboBox<>();
        SimpanArtikel = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        KeObat1 = new javax.swing.JButton();
        KeArtikel1 = new javax.swing.JButton();
        KePenyakit1 = new javax.swing.JButton();
        KeMain1 = new javax.swing.JButton();
        keAnjuranObat = new javax.swing.JButton();
        NamaPenyakit = new javax.swing.JComboBox<model.Penyakit>() ;
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        addContainerListener(new java.awt.event.ContainerAdapter() {
            public void componentAdded(java.awt.event.ContainerEvent evt) {
                formComponentAdded(evt);
            }
        });
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 153, 153));
        jLabel1.setText("Status    : ");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 330, 100, -1));

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(0, 153, 153));
        jLabel4.setText("Judul        :");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 130, 90, -1));

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(0, 153, 153));
        jLabel5.setText("Konten    :");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 210, 90, -1));

        JudulArtikel.setBackground(new java.awt.Color(255, 255, 255));
        JudulArtikel.setForeground(new java.awt.Color(0, 0, 0));
        getContentPane().add(JudulArtikel, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 130, 430, 30));

        KontenArtikel.setBackground(new java.awt.Color(255, 255, 255));
        KontenArtikel.setColumns(20);
        KontenArtikel.setForeground(new java.awt.Color(0, 0, 0));
        KontenArtikel.setRows(5);
        jScrollPane1.setViewportView(KontenArtikel);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 210, 430, 110));

        ComboArtikel.setBackground(new java.awt.Color(255, 255, 255));
        ComboArtikel.setForeground(new java.awt.Color(0, 0, 0));
        ComboArtikel.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Draft", "Tinjau", "Tayang" }));
        getContentPane().add(ComboArtikel, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 330, 100, 30));

        SimpanArtikel.setBackground(new java.awt.Color(0, 153, 153));
        SimpanArtikel.setForeground(new java.awt.Color(255, 255, 255));
        SimpanArtikel.setText("Simpan");
        SimpanArtikel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SimpanArtikelActionPerformed(evt);
            }
        });
        getContentPane().add(SimpanArtikel, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 380, 85, 30));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(0, 153, 153));
        jLabel3.setText("Penyakit  :");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 170, -1, -1));

        jPanel3.setBackground(new java.awt.Color(230, 247, 249));

        KeObat1.setBackground(new java.awt.Color(219, 249, 249));
        KeObat1.setForeground(new java.awt.Color(0, 153, 153));
        KeObat1.setText("Obat");
        KeObat1.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        KeObat1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                KeObat1ActionPerformed(evt);
            }
        });

        KeArtikel1.setBackground(new java.awt.Color(219, 249, 249));
        KeArtikel1.setForeground(new java.awt.Color(0, 153, 153));
        KeArtikel1.setText("Artikel");
        KeArtikel1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                KeArtikel1ActionPerformed(evt);
            }
        });

        KePenyakit1.setBackground(new java.awt.Color(219, 249, 249));
        KePenyakit1.setForeground(new java.awt.Color(0, 153, 153));
        KePenyakit1.setText("Penyakit");
        KePenyakit1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                KePenyakit1ActionPerformed(evt);
            }
        });

        KeMain1.setBackground(new java.awt.Color(0, 51, 51));
        KeMain1.setForeground(new java.awt.Color(255, 255, 255));
        KeMain1.setText("Kembali");
        KeMain1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                KeMain1ActionPerformed(evt);
            }
        });

        keAnjuranObat.setBackground(new java.awt.Color(219, 249, 249));
        keAnjuranObat.setForeground(new java.awt.Color(0, 153, 153));
        keAnjuranObat.setText("Anjuran Obat");
        keAnjuranObat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                keAnjuranObatActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(KeArtikel1, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(KePenyakit1, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(KeObat1, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(keAnjuranObat)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 91, Short.MAX_VALUE)
                .addComponent(KeMain1, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(KeArtikel1, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(KePenyakit1, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(KeObat1, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(KeMain1, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(keAnjuranObat, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(14, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 20, 610, 60));

        NamaPenyakit.setBackground(new java.awt.Color(255, 255, 255));
        NamaPenyakit.setForeground(new java.awt.Color(0, 0, 0));
        NamaPenyakit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NamaPenyakitActionPerformed(evt);
            }
        });
        getContentPane().add(NamaPenyakit, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 170, 430, 30));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/FrameObat&Penyakit.png"))); // NOI18N
        jLabel2.setText("jLabel2");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 710, -1));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void configureTextAreas() {
        KontenArtikel.addMouseListener(new MouseAdapter() {
            @Override public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2 && SwingUtilities.isLeftMouseButton(e)) {
                    JTextArea editor = new JTextArea(20, 60);
                    editor.setLineWrap(true); editor.setWrapStyleWord(true);
                    editor.setText(KontenArtikel.getText());
                    int x = JOptionPane.showConfirmDialog(
                            A_Edit_Artikel.this,
                            new JScrollPane(editor),
                            "Edit Konten",
                            JOptionPane.OK_CANCEL_OPTION,
                            JOptionPane.PLAIN_MESSAGE);
                    if (x == JOptionPane.OK_OPTION) {
                        KontenArtikel.setText(editor.getText());
                    }
                }
            }
        });
    }
    
    private void loadPenyakitCombo() {
        DefaultComboBoxModel<model.Penyakit> m = new DefaultComboBoxModel<>();
        m.addElement(null); // placeholder baris pertama
        try {
            java.util.List<model.Penyakit> list = penyakitController.listAll();
            if (list != null) for (model.Penyakit p : list) m.addElement(p);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Gagal memuat penyakit: " + ex.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
        NamaPenyakit.setModel(m);
    }

    private Integer getSelectedPenyakitId() {
        model.Penyakit p = (model.Penyakit) NamaPenyakit.getSelectedItem();
        return (p == null) ? null : p.getId();
    }

    private void selectPenyakitById(Integer id) {
        ComboBoxModel<model.Penyakit> m = NamaPenyakit.getModel();
        if (id == null) { NamaPenyakit.setSelectedIndex(0); return; }
        for (int i = 0; i < m.getSize(); i++) {
            model.Penyakit p = m.getElementAt(i);
            if (p != null && id.equals(p.getId())) {
                NamaPenyakit.setSelectedIndex(i);
                return;
            }
        }
        NamaPenyakit.setSelectedIndex(0);
    }
    
    private void configureStatusCombo() {

        ComboArtikel.setModel(new DefaultComboBoxModel<>(new String[]{
                "Draft", "Tinjau", "Tayang"
        }));
        ComboArtikel.setSelectedIndex(0);
    }
    
    private String toDbStatus(String ui){
        if (ui == null) return "DRAFT";
        return switch (ui.trim().toLowerCase()) {
            case "draft"  -> "DRAFT";
            case "tinjau" -> "REVIEW";
            case "tayang" -> "PUBLISHED";
            default -> ui.toUpperCase();
        };
    }

    // DB -> UI
    private String toUiStatus(String db){
        if (db == null) return "Draft";
        return switch (db.trim().toUpperCase()) {
            case "DRAFT"     -> "Draft";
            case "REVIEW"    -> "Tinjau";
            case "PUBLISHED" -> "Tayang";
            default -> db;
        };
    }
    
    private void loadData(Integer id) {
        try {
            Artikel a = artikelController.detail(id);
            if (a == null) {
                JOptionPane.showMessageDialog(this, "Artikel tidak ditemukan.");
                dispose();
                return;
            }
            JudulArtikel.setText(nv(a.getJudul()));
            KontenArtikel.setText(nv(a.getKonten()));

            // pilih penyakit pada combobox
            Integer pid = (a.getPenyakit() != null) ? a.getPenyakit().getId() : null;
            selectPenyakitById(pid);

            // status
            String uiStatus = toUiStatus(a.getStatusReview());
            ComboBoxModel<String> m = ComboArtikel.getModel();
            int idx = 0;
            for (int i = 0; i < m.getSize(); i++) {
                if (m.getElementAt(i).equalsIgnoreCase(uiStatus)) { idx = i; break; }
            }
            ComboArtikel.setSelectedIndex(idx);
        } catch (RuntimeException ex) {
            JOptionPane.showMessageDialog(this, "Gagal memuat data: " + ex.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
        
    private void onSimpan() {
        try {
            String judul   = JudulArtikel.getText().trim();
            String konten  = KontenArtikel.getText().trim();
            String status  = toDbStatus(String.valueOf(ComboArtikel.getSelectedItem()));
            Integer penyakitId = getSelectedPenyakitId();

            // ===== VALIDASI WAJIB =====
            if (adminIdLogin == null)
                throw new IllegalArgumentException("Admin login tidak ditemukan. Silakan login ulang.");
            if (penyakitId == null)
                throw new IllegalArgumentException("Penyakit wajib dipilih.");
            if (judul.isEmpty())
                throw new IllegalArgumentException("Judul wajib diisi.");
            if (konten.isEmpty())
                throw new IllegalArgumentException("Konten wajib diisi.");

            if (editingId == null) {
                // Tambah baru → admin & penyakit WAJIB tidak null
                artikelController.create(adminIdLogin, penyakitId, judul, konten, status);
                JOptionPane.showMessageDialog(this, "Artikel berhasil ditambahkan.");
            } else {
                // Perbarui → admin & penyakit juga dipaksa di-set (agar tidak null)
                artikelController.updateFull(editingId, adminIdLogin, penyakitId, judul, konten, status);
                JOptionPane.showMessageDialog(this, "Artikel berhasil diperbarui.");
            }
            dispose();

        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Validasi", JOptionPane.WARNING_MESSAGE);
        } catch (RuntimeException ex) {
            JOptionPane.showMessageDialog(this, "Gagal menyimpan: " + ex.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private static String nv(String s){ return s==null ? "" : s; }
    
    private void formComponentAdded(java.awt.event.ContainerEvent evt) {//GEN-FIRST:event_formComponentAdded
        // TODO add your handling code here:
    }//GEN-LAST:event_formComponentAdded

    private void KeObat1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_KeObat1ActionPerformed
        A_Obat a_Obat = new A_Obat();
        a_Obat.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_KeObat1ActionPerformed

    private void KeArtikel1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_KeArtikel1ActionPerformed
        A_Artikel a_Artikel = new A_Artikel();
        a_Artikel.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_KeArtikel1ActionPerformed

    private void KePenyakit1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_KePenyakit1ActionPerformed
        A_Penyakit a_Penyakit = new A_Penyakit();
        a_Penyakit.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_KePenyakit1ActionPerformed

    private void KeMain1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_KeMain1ActionPerformed
        A_Main main = new A_Main();
        main.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_KeMain1ActionPerformed

    private void keAnjuranObatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_keAnjuranObatActionPerformed
        A_Obat a_Obat = new A_Obat();
        a_Obat.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_keAnjuranObatActionPerformed

    private void NamaPenyakitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NamaPenyakitActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_NamaPenyakitActionPerformed

    private void SimpanArtikelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SimpanArtikelActionPerformed
        dispose();
    }//GEN-LAST:event_SimpanArtikelActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
//            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
//        java.awt.EventQueue.invokeLater(() -> new Main().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> ComboArtikel;
    private javax.swing.JTextField JudulArtikel;
    private javax.swing.JButton KeArtikel1;
    private javax.swing.JButton KeMain1;
    private javax.swing.JButton KeObat1;
    private javax.swing.JButton KePenyakit1;
    private javax.swing.JTextArea KontenArtikel;
    private javax.swing.JComboBox<model.Penyakit> NamaPenyakit;
    private javax.swing.JButton SimpanArtikel;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JButton keAnjuranObat;
    // End of variables declaration//GEN-END:variables
}
